var pulseALL = {
	downlaodPulseAllData : function() {
		var formatedPulseAllListArray = [];
		$.ajax({
			async : false,
			contentType : "application/json",
			url : 'cityGridView',
			 type:'POST', 
			 cache: false,
             beforeSend: function (request) {
             request.setRequestHeader("x-content-type-options", "nosniff");
              },
			dataType : "json",
			success : function(pulseAllJsonData) {
				$.each(pulseAllJsonData, function(index, aPulse) {
					formatedPulseAllListArray.push(aPulse);
				});
			},
			
				
				error:function(errorResponse,xhr){ 
					if(errorResponse.status==403)
						{
						commonAlert("Alert !", "Session expired");
						
						}else{
							if("undefined"==(errorResponse.responseText).trim()){
								commonAlert("Alert !", "Bad Request. Please relogin again.");
							}else{
							$('#ExceptionIssue').html(errorResponse.responseText);
							$('#ExceptionIssue').show();
							}
						}
					
			 	
	       	 }
				
		        
		});
		return formatedPulseAllListArray;
	},

	drawPulseAllChart : function(formatedPulseAllJsonData) {
		var ExternalAssigned, CTSAssigned, EmailAlertsTemp, x_axisLabel;
		var tic;
		var y_axisValue;
		var sumLableValue = [];
		var EmailAlerts = [];
		var maxvalue = 0;
		var numberOfTicks = 4;
		var fndMax = 0;
		var interval;
		var xArray = [];

		x_axisLabel = formatedPulseAllJsonData[formatedPulseAllJsonData.length - 1]
		for (var i = 0, j = formatedPulseAllJsonData.length - 1; i < j; i++) {
			if (i == formatedPulseAllJsonData.length - 1) {
			} else {
				xArray[i] = formatedPulseAllJsonData[i];
				maxvalue = Math.max.apply(Math, formatedPulseAllJsonData[i]);
				if (fndMax <= maxvalue) {
					fndMax = maxvalue;
				}
			}

			if (i == 0) {
				ExternalAssigned = formatedPulseAllJsonData[i];
			}
			if (i == 1) {
				CTSAssigned = formatedPulseAllJsonData[i];
			}
			if (i == 2) {
				EmailAlertsTemp = formatedPulseAllJsonData[i];
			}
		}

		/*var originalvalue = fndMax;
		fndMax -= fndMax % (100);
		var diff = originalvalue - fndMax;
		if(originalvalue<=100){
				if(diff<=5){
					fndMax+=5
				}else
					fndMax += diff+10;
	       }else{
			   fndMax +=diff+200 ;
	       }
		tic = fndMax / (numberOfTicks);
		numberOfTicks++;*/

		for (var i = 0; i < EmailAlertsTemp.length; i++) {
			if (EmailAlertsTemp[i] <= (CTSAssigned[i] + ExternalAssigned[i])) {
				EmailAlerts[i] = 0;
			} else {
				EmailAlerts[i] = EmailAlertsTemp[i]
						- (CTSAssigned[i] + ExternalAssigned[i]);
			}
		}

		for (var i = 0; i < ExternalAssigned.length; i++) {
			sumLableValue[i] = ExternalAssigned[i] + CTSAssigned[i];
			if (fndMax <= sumLableValue[i])  {
				fndMax = sumLableValue[i];
			}

		}
		
		var originalvalue = fndMax;
		fndMax -= fndMax % (100);
		var diff = originalvalue - fndMax;
		if(originalvalue<=100){
				if(diff<=5){
					fndMax+=5
				}else
					fndMax += diff+10;
	       }else{
	    	   if(diff<50)
			   fndMax +=diff+70;
	    	   else{
	    		   fndMax +=diff+100; 
	    	   }
	       }
		tic = fndMax / (numberOfTicks);
		numberOfTicks++;
		ticks = x_axisLabel;
		types = [ 'CTS Assigned', 'External Assigned', 'EmailAlerts' ];
    
		plot3 = jQuery.jqplot('pulseAll-chart', [ ExternalAssigned,
				CTSAssigned, EmailAlerts ], {
			title : 'Pulse Tickets/Emails',
			seriesColors : [ "#FEC28C", "#85FE8C", "#90AAFF" ],
			animate : !$.jqplot.use_excanvas,
			stackSeries : true,
			grid : {
				drawBorder : false,
				shadow : false,
				background : 'rgba(0,0,0,0)',
				borderColor : 'black'
			},
			seriesDefaults : {
				shadow : false,
				renderer : $.jqplot.BarRenderer,
				rendererOptions : {
					//barWidth : 30,
					barMargin: 10,
					smooth : true,
					animation : {
						show : true
					},

				},
				pointLabels : {
					show : true,
					stackedValue : true,
					formatString : '%d',

				}
			},
			series : [ {
				lineJoin : 'round',
				pointLabels : {
					show : false,
					labels : ExternalAssigned,

					ypadding : -5,
					escapeHTML : false
				},

			},

			{
				
				xaxis : 'xaxis',
				yaxis : 'yaxis',
				renderer : $.jqplot.BarRenderer,
				rendererOptions : {
                        // barpadding:-50,
				},
				pointLabels : {
					show : true,

					labels : sumLableValue,
					location : 'outside',
					xpadding : -20,
					ypadding : 1,
					escapeHTML : false
				}
			},

			{
				//disableStack: true,
				xaxis : 'xaxis',
				yaxis : 'yaxis',
				renderer : $.jqplot.BarRenderer,
				rendererOptions : {
					//barWidth : 20,
					fillToZero : false,
				},
				pointLabels : {
					show : true,
					location : 'outside',
					labels : EmailAlertsTemp,
					xpadding : 0,
					ypadding : -4,
					escapeHTML : false
				}
			}, ],
			highlighter : {
				show : false,
				showTooltip : false
			},
			cursor : {
				style : 'default',
				show : true
			},
			legend : {
				show : true,
				renderer : $.jqplot.EnhancedLegendRenderer,
				placement : 'outside',
				labels : types,
				rendererOptions : {
					numberRows : 1,
				},
				location : 'nw',
				border : 'none'
			},
			axesDefaults : {
				tickRenderer : $.jqplot.CanvasAxisTickRenderer,
				tickOptions : {
					angle : -60,
					fontSize : '11px'
				},
				rendererOptions : {
					drawBaseline : true,
					baselineColor : '#000000',
					baselineWidth : 1,
				}
			},
			axes : {
				xaxis : {
					renderer : $.jqplot.CategoryAxisRenderer,
					tickRenderer : jQuery.jqplot.CanvasAxisTickRenderer,
					ticks : x_axisLabel,
					tickOptions : {
						showGridline : false,
						markSize : 10,
						markColor : 'red',
						textColor : "#000000",
					},
				},
				yaxis : {
					min : 0,
					tickInterval : tic,
					numberTicks : 5,
					Max : fndMax,
					tickOptions : {
						formatString : '%d',
						showGridline : false,
						markSize : 10
					}
				}
			},
		});
		
		
		$("#pulseAll-chart").on(
				'jqplotDataClick',
				function(ev, seriesIndex, pointIndex, data) {
					var dateclick;
					var mnth;
					dateclick = x_axisLabel[pointIndex];
					mnth = pointIndex + 1;
					if (mnth < 9) {
						mnth = "0" + mnth;
					}
					$('#info3').html('datevalue: ' + dateclick);
					// header("X-XSS-Protection: 0");
					 var f = document.createElement('form');
					 f.action='DayController';
					 f.method='POST';
					 f.target='DayController';
              
					 var i=document.createElement('input');
					 i.type='hidden';
					 i.name='selectedValue';
					 i.value=dateclick;
					 f.appendChild(i);
					 var j=document.createElement('input');
					 j.type='hidden';
					 j.name='date';
					 j.value=mnth;
					 f.appendChild(j);

					 document.body.appendChild(f);
					 f.submit();
					//window.location = 'DayController?selectedValue='
							//+ data.selectedDate + '&pwd=' + data.SelectedMonth;
				});
	}
};

$(window).on('resize', function(event, ui) {
	if (plot3) {
		plot3.replot({
			resetAxes : true
		});
	}
	location.reload();
});

	���

function drawTable(data) {
	drawRowHead(data[3]);
	for (var i = data.length-1; i>=0 ;  i--) {
		if (i == 0) {
			drawRow(data[i],
					'<span class="chart-legend chart-legend-exa"></span>','CTS Assigned')
			
		}
		if (i == 1) {
			drawRow(data[i],
					'<span class="chart-legend chart-legend-ctsa"></span>','External Assigned')
		}
		if (i == 2) {
			drawRow(data[i],
					'<span class="chart-legend chart-legend-ema"></span>','Email Alert')
		}

	}
}

function drawRow(rowData, nameHeader,type) {
	var row = $("<tr/>")
	$("#chart-table").append(row); // this will append tr element to table...
	// keep its reference for a while since we
	// will add cels into it
	row.append("<th>" + nameHeader + "</th>");
	for (var i = 0; i < rowData.length; i++) {
		row
				.append($("<td data-container='body' data-toggle='tooltip' data-placement='bottom' title='"
						+ type
						+ ": "
						+ rowData[i]
						+ "'>"
						+ rowData[i]
						+ "</td>"));
	}
}

function drawRowHead(rowData) {
	var row = $("<tr/>")
	$("#chart-table").append(row); // this will append tr element to table...
	// keep its reference for a while since we
	// will add cels into it
	row.append("<th><span></span></th>");
	for (var i = 0; i < rowData.length; i++) {
		row.append($("<th title='" + rowData[i] + "'><span>" + rowData[i]
				+ "</span></th>"));
	}
}
