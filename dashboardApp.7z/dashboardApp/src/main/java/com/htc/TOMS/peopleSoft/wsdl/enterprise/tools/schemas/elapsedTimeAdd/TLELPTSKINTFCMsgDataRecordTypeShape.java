
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TL_ELPTSK_INTFCMsgDataRecord_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TL_ELPTSK_INTFCMsgDataRecord_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BADGE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}BADGE_ID_TypeShape"/>
 *         &lt;element name="EMPLID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}EMPLID_TypeShape"/>
 *         &lt;element name="EMPL_RCD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}EMPL_RCD_TypeShape"/>
 *         &lt;element name="DUR" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}DUR_TypeShape"/>
 *         &lt;element name="SEQNUM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}SEQNUM_TypeShape"/>
 *         &lt;element name="DELETE_DATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}DELETE_DATE_TypeShape"/>
 *         &lt;element name="TASK_ELEMENT_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TASK_ELEMENT_CD_TypeShape"/>
 *         &lt;element name="TASK_ELEMENT_VAL" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TASK_ELEMENT_VAL_TypeShape" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}AUDIT_ACTN_TypeShape" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TL_ELPTSK_INTFCMsgDataRecord_TypeShape", propOrder = {
    "badgeid",
    "emplid",
    "emplrcd",
    "dur",
    "seqnum",
    "deletedate",
    "taskelementcd",
    "taskelementval",
    "auditactn"
})
public class TLELPTSKINTFCMsgDataRecordTypeShape {

    @XmlElement(name = "BADGE_ID", required = true)
    protected BADGEIDTypeShape badgeid;
    @XmlElement(name = "EMPLID", required = true)
    protected EMPLIDTypeShape emplid;
    @XmlElement(name = "EMPL_RCD", required = true)
    protected EMPLRCDTypeShape emplrcd;
    @XmlElement(name = "DUR", required = true)
    protected DURTypeShape dur;
    @XmlElement(name = "SEQNUM", required = true)
    protected SEQNUMTypeShape seqnum;
    @XmlElement(name = "DELETE_DATE", required = true)
    protected DELETEDATETypeShape deletedate;
    @XmlElement(name = "TASK_ELEMENT_CD", required = true)
    protected TASKELEMENTCDTypeShape taskelementcd;
    @XmlElement(name = "TASK_ELEMENT_VAL")
    protected TASKELEMENTVALTypeShape taskelementval;
    @XmlElement(name = "AUDIT_ACTN")
    protected AUDITACTNTypeShape auditactn;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    /**
     * Gets the value of the badgeid property.
     * 
     * @return
     *     possible object is
     *     {@link BADGEIDTypeShape }
     *     
     */
    public BADGEIDTypeShape getBADGEID() {
        return badgeid;
    }

    /**
     * Sets the value of the badgeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BADGEIDTypeShape }
     *     
     */
    public void setBADGEID(BADGEIDTypeShape value) {
        this.badgeid = value;
    }

    /**
     * Gets the value of the emplid property.
     * 
     * @return
     *     possible object is
     *     {@link EMPLIDTypeShape }
     *     
     */
    public EMPLIDTypeShape getEMPLID() {
        return emplid;
    }

    /**
     * Sets the value of the emplid property.
     * 
     * @param value
     *     allowed object is
     *     {@link EMPLIDTypeShape }
     *     
     */
    public void setEMPLID(EMPLIDTypeShape value) {
        this.emplid = value;
    }

    /**
     * Gets the value of the emplrcd property.
     * 
     * @return
     *     possible object is
     *     {@link EMPLRCDTypeShape }
     *     
     */
    public EMPLRCDTypeShape getEMPLRCD() {
        return emplrcd;
    }

    /**
     * Sets the value of the emplrcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link EMPLRCDTypeShape }
     *     
     */
    public void setEMPLRCD(EMPLRCDTypeShape value) {
        this.emplrcd = value;
    }

    /**
     * Gets the value of the dur property.
     * 
     * @return
     *     possible object is
     *     {@link DURTypeShape }
     *     
     */
    public DURTypeShape getDUR() {
        return dur;
    }

    /**
     * Sets the value of the dur property.
     * 
     * @param value
     *     allowed object is
     *     {@link DURTypeShape }
     *     
     */
    public void setDUR(DURTypeShape value) {
        this.dur = value;
    }

    /**
     * Gets the value of the seqnum property.
     * 
     * @return
     *     possible object is
     *     {@link SEQNUMTypeShape }
     *     
     */
    public SEQNUMTypeShape getSEQNUM() {
        return seqnum;
    }

    /**
     * Sets the value of the seqnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link SEQNUMTypeShape }
     *     
     */
    public void setSEQNUM(SEQNUMTypeShape value) {
        this.seqnum = value;
    }

    /**
     * Gets the value of the deletedate property.
     * 
     * @return
     *     possible object is
     *     {@link DELETEDATETypeShape }
     *     
     */
    public DELETEDATETypeShape getDELETEDATE() {
        return deletedate;
    }

    /**
     * Sets the value of the deletedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DELETEDATETypeShape }
     *     
     */
    public void setDELETEDATE(DELETEDATETypeShape value) {
        this.deletedate = value;
    }

    /**
     * Gets the value of the taskelementcd property.
     * 
     * @return
     *     possible object is
     *     {@link TASKELEMENTCDTypeShape }
     *     
     */
    public TASKELEMENTCDTypeShape getTASKELEMENTCD() {
        return taskelementcd;
    }

    /**
     * Sets the value of the taskelementcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link TASKELEMENTCDTypeShape }
     *     
     */
    public void setTASKELEMENTCD(TASKELEMENTCDTypeShape value) {
        this.taskelementcd = value;
    }

    /**
     * Gets the value of the taskelementval property.
     * 
     * @return
     *     possible object is
     *     {@link TASKELEMENTVALTypeShape }
     *     
     */
    public TASKELEMENTVALTypeShape getTASKELEMENTVAL() {
        return taskelementval;
    }

    /**
     * Sets the value of the taskelementval property.
     * 
     * @param value
     *     allowed object is
     *     {@link TASKELEMENTVALTypeShape }
     *     
     */
    public void setTASKELEMENTVAL(TASKELEMENTVALTypeShape value) {
        this.taskelementval = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public AUDITACTNTypeShape getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public void setAUDITACTN(AUDITACTNTypeShape value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
