
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Transaction_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Transaction_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="TL_ELP_INTFC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TL_ELP_INTFCMsgDataRecord_TypeShape" minOccurs="0"/>
 *         &lt;element name="PSCAMA" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}PSCAMAMsgDataRecord_TypeShape"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Transaction_TypeShape", propOrder = {

})
public class TransactionTypeShape {

    @XmlElement(name = "TL_ELP_INTFC")
    protected TLELPINTFCMsgDataRecordTypeShape tlelpintfc;
    @XmlElement(name = "PSCAMA", required = true)
    protected PSCAMAMsgDataRecordTypeShape pscama;
    
    
    

    public TransactionTypeShape(TLELPINTFCMsgDataRecordTypeShape tlelpintfc, PSCAMAMsgDataRecordTypeShape pscama) {
		super();
		this.tlelpintfc = tlelpintfc;
		this.pscama = pscama;
	}

    
	public TransactionTypeShape() {
		super();
	}


	/**
     * Gets the value of the tlelpintfc property.
     * 
     * @return
     *     possible object is
     *     {@link TLELPINTFCMsgDataRecordTypeShape }
     *     
     */
    public TLELPINTFCMsgDataRecordTypeShape getTLELPINTFC() {
        return tlelpintfc;
    }

    /**
     * Sets the value of the tlelpintfc property.
     * 
     * @param value
     *     allowed object is
     *     {@link TLELPINTFCMsgDataRecordTypeShape }
     *     
     */
    public void setTLELPINTFC(TLELPINTFCMsgDataRecordTypeShape value) {
        this.tlelpintfc = value;
    }

    /**
     * Gets the value of the pscama property.
     * 
     * @return
     *     possible object is
     *     {@link PSCAMAMsgDataRecordTypeShape }
     *     
     */
    public PSCAMAMsgDataRecordTypeShape getPSCAMA() {
        return pscama;
    }

    /**
     * Sets the value of the pscama property.
     * 
     * @param value
     *     allowed object is
     *     {@link PSCAMAMsgDataRecordTypeShape }
     *     
     */
    public void setPSCAMA(PSCAMAMsgDataRecordTypeShape value) {
        this.pscama = value;
    }

}
