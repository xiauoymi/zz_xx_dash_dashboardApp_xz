@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;
