
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.enterprise.tools.schemas.elapsed_time_add package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ELAPSEDTIMEADD_QNAME = new QName("http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1", "ELAPSED_TIME_ADD");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.enterprise.tools.schemas.elapsed_time_add
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ELAPSEDTIMEADDTypeShape }
     * 
     */
    public ELAPSEDTIMEADDTypeShape createELAPSEDTIMEADDTypeShape() {
        return new ELAPSEDTIMEADDTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesImageRefFieldType }
     * 
     */
    public FieldTypesImageRefFieldType createFieldTypesImageRefFieldType() {
        return new FieldTypesImageRefFieldType();
    }

    /**
     * Create an instance of {@link EMPLIDTypeShape }
     * 
     */
    public EMPLIDTypeShape createEMPLIDTypeShape() {
        return new EMPLIDTypeShape();
    }

    /**
     * Create an instance of {@link PROCESSINSTANCETypeShape }
     * 
     */
    public PROCESSINSTANCETypeShape createPROCESSINSTANCETypeShape() {
        return new PROCESSINSTANCETypeShape();
    }

    /**
     * Create an instance of {@link TLQUANTITYTypeShape }
     * 
     */
    public TLQUANTITYTypeShape createTLQUANTITYTypeShape() {
        return new TLQUANTITYTypeShape();
    }

    /**
     * Create an instance of {@link TLCOMMENTSTypeShape }
     * 
     */
    public TLCOMMENTSTypeShape createTLCOMMENTSTypeShape() {
        return new TLCOMMENTSTypeShape();
    }

    /**
     * Create an instance of {@link OPRIDTypeShape }
     * 
     */
    public OPRIDTypeShape createOPRIDTypeShape() {
        return new OPRIDTypeShape();
    }

    /**
     * Create an instance of {@link BILLABLEINDTypeShape }
     * 
     */
    public BILLABLEINDTypeShape createBILLABLEINDTypeShape() {
        return new BILLABLEINDTypeShape();
    }

    /**
     * Create an instance of {@link COMPRATECDTypeShape }
     * 
     */
    public COMPRATECDTypeShape createCOMPRATECDTypeShape() {
        return new COMPRATECDTypeShape();
    }

    /**
     * Create an instance of {@link DURTypeShape }
     * 
     */
    public DURTypeShape createDURTypeShape() {
        return new DURTypeShape();
    }

    /**
     * Create an instance of {@link STATETypeShape }
     * 
     */
    public STATETypeShape createSTATETypeShape() {
        return new STATETypeShape();
    }

    /**
     * Create an instance of {@link OVERRIDERATETypeShape }
     * 
     */
    public OVERRIDERATETypeShape createOVERRIDERATETypeShape() {
        return new OVERRIDERATETypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesDateFieldType }
     * 
     */
    public FieldTypesDateFieldType createFieldTypesDateFieldType() {
        return new FieldTypesDateFieldType();
    }

    /**
     * Create an instance of {@link LOCALITYTypeShape }
     * 
     */
    public LOCALITYTypeShape createLOCALITYTypeShape() {
        return new LOCALITYTypeShape();
    }

    /**
     * Create an instance of {@link TRCTypeShape }
     * 
     */
    public TRCTypeShape createTRCTypeShape() {
        return new TRCTypeShape();
    }

    /**
     * Create an instance of {@link COUNTRYTypeShape }
     * 
     */
    public COUNTRYTypeShape createCOUNTRYTypeShape() {
        return new COUNTRYTypeShape();
    }

    /**
     * Create an instance of {@link TASKELEMENTVALTypeShape }
     * 
     */
    public TASKELEMENTVALTypeShape createTASKELEMENTVALTypeShape() {
        return new TASKELEMENTVALTypeShape();
    }

    /**
     * Create an instance of {@link DELETEDATETypeShape }
     * 
     */
    public DELETEDATETypeShape createDELETEDATETypeShape() {
        return new DELETEDATETypeShape();
    }

    /**
     * Create an instance of {@link EMPLRCDTypeShape }
     * 
     */
    public EMPLRCDTypeShape createEMPLRCDTypeShape() {
        return new EMPLRCDTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesTypeShape }
     * 
     */
    public FieldTypesTypeShape createFieldTypesTypeShape() {
        return new FieldTypesTypeShape();
    }

    /**
     * Create an instance of {@link TASKPRFLTMPLTIDTypeShape }
     * 
     */
    public TASKPRFLTMPLTIDTypeShape createTASKPRFLTMPLTIDTypeShape() {
        return new TASKPRFLTMPLTIDTypeShape();
    }

    /**
     * Create an instance of {@link TCDSUPERVISRIDTypeShape }
     * 
     */
    public TCDSUPERVISRIDTypeShape createTCDSUPERVISRIDTypeShape() {
        return new TCDSUPERVISRIDTypeShape();
    }

    /**
     * Create an instance of {@link SEQNUMTypeShape }
     * 
     */
    public SEQNUMTypeShape createSEQNUMTypeShape() {
        return new SEQNUMTypeShape();
    }

    /**
     * Create an instance of {@link ACTIONDTTMTypeShape }
     * 
     */
    public ACTIONDTTMTypeShape createACTIONDTTMTypeShape() {
        return new ACTIONDTTMTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesNumberFieldType }
     * 
     */
    public FieldTypesNumberFieldType createFieldTypesNumberFieldType() {
        return new FieldTypesNumberFieldType();
    }

    /**
     * Create an instance of {@link TLELPTSKINTFCMsgDataRecordTypeShape }
     * 
     */
    public TLELPTSKINTFCMsgDataRecordTypeShape createTLELPTSKINTFCMsgDataRecordTypeShape() {
        return new TLELPTSKINTFCMsgDataRecordTypeShape();
    }

    /**
     * Create an instance of {@link TASKELEMENTCDTypeShape }
     * 
     */
    public TASKELEMENTCDTypeShape createTASKELEMENTCDTypeShape() {
        return new TASKELEMENTCDTypeShape();
    }

    /**
     * Create an instance of {@link TLELPINTFCMsgDataRecordTypeShape }
     * 
     */
    public TLELPINTFCMsgDataRecordTypeShape createTLELPINTFCMsgDataRecordTypeShape() {
        return new TLELPINTFCMsgDataRecordTypeShape();
    }

    /**
     * Create an instance of {@link ADDDELETEINDTypeShape }
     * 
     */
    public ADDDELETEINDTypeShape createADDDELETEINDTypeShape() {
        return new ADDDELETEINDTypeShape();
    }

    /**
     * Create an instance of {@link BASELANGUAGECDTypeShape }
     * 
     */
    public BASELANGUAGECDTypeShape createBASELANGUAGECDTypeShape() {
        return new BASELANGUAGECDTypeShape();
    }

    /**
     * Create an instance of {@link MSGNODENAMETypeShape }
     * 
     */
    public MSGNODENAMETypeShape createMSGNODENAMETypeShape() {
        return new MSGNODENAMETypeShape();
    }

    /**
     * Create an instance of {@link AUDITACTNTypeShape }
     * 
     */
    public AUDITACTNTypeShape createAUDITACTNTypeShape() {
        return new AUDITACTNTypeShape();
    }

    /**
     * Create an instance of {@link TCDIDTypeShape }
     * 
     */
    public TCDIDTypeShape createTCDIDTypeShape() {
        return new TCDIDTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesPSCAMATypeShape }
     * 
     */
    public FieldTypesPSCAMATypeShape createFieldTypesPSCAMATypeShape() {
        return new FieldTypesPSCAMATypeShape();
    }

    /**
     * Create an instance of {@link OVERRIDERSNCDTypeShape }
     * 
     */
    public OVERRIDERSNCDTypeShape createOVERRIDERSNCDTypeShape() {
        return new OVERRIDERSNCDTypeShape();
    }

    /**
     * Create an instance of {@link MsgDataTypeShape }
     * 
     */
    public MsgDataTypeShape createMsgDataTypeShape() {
        return new MsgDataTypeShape();
    }

    /**
     * Create an instance of {@link PSCAMAMsgDataRecordTypeShape }
     * 
     */
    public PSCAMAMsgDataRecordTypeShape createPSCAMAMsgDataRecordTypeShape() {
        return new PSCAMAMsgDataRecordTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesTLELPTSKINTFCTypeShape }
     * 
     */
    public FieldTypesTLELPTSKINTFCTypeShape createFieldTypesTLELPTSKINTFCTypeShape() {
        return new FieldTypesTLELPTSKINTFCTypeShape();
    }

    /**
     * Create an instance of {@link TransactionTypeShape }
     * 
     */
    public TransactionTypeShape createTransactionTypeShape() {
        return new TransactionTypeShape();
    }

    /**
     * Create an instance of {@link TASKPROFILEIDTypeShape }
     * 
     */
    public TASKPROFILEIDTypeShape createTASKPROFILEIDTypeShape() {
        return new TASKPROFILEIDTypeShape();
    }

    /**
     * Create an instance of {@link PUBLISHRULEIDTypeShape }
     * 
     */
    public PUBLISHRULEIDTypeShape createPUBLISHRULEIDTypeShape() {
        return new PUBLISHRULEIDTypeShape();
    }

    /**
     * Create an instance of {@link LANGUAGECDTypeShape }
     * 
     */
    public LANGUAGECDTypeShape createLANGUAGECDTypeShape() {
        return new LANGUAGECDTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesTimeFieldType }
     * 
     */
    public FieldTypesTimeFieldType createFieldTypesTimeFieldType() {
        return new FieldTypesTimeFieldType();
    }

    /**
     * Create an instance of {@link CURRENCYCDTypeShape }
     * 
     */
    public CURRENCYCDTypeShape createCURRENCYCDTypeShape() {
        return new CURRENCYCDTypeShape();
    }

    /**
     * Create an instance of {@link BADGEIDTypeShape }
     * 
     */
    public BADGEIDTypeShape createBADGEIDTypeShape() {
        return new BADGEIDTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesTLELPINTFCTypeShape }
     * 
     */
    public FieldTypesTLELPINTFCTypeShape createFieldTypesTLELPINTFCTypeShape() {
        return new FieldTypesTLELPINTFCTypeShape();
    }

    /**
     * Create an instance of {@link FieldTypesCharFieldType }
     * 
     */
    public FieldTypesCharFieldType createFieldTypesCharFieldType() {
        return new FieldTypesCharFieldType();
    }

    /**
     * Create an instance of {@link FieldTypesDateTimeFieldType }
     * 
     */
    public FieldTypesDateTimeFieldType createFieldTypesDateTimeFieldType() {
        return new FieldTypesDateTimeFieldType();
    }

    /**
     * Create an instance of {@link MSGSEQFLGTypeShape }
     * 
     */
    public MSGSEQFLGTypeShape createMSGSEQFLGTypeShape() {
        return new MSGSEQFLGTypeShape();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ELAPSEDTIMEADDTypeShape }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1", name = "ELAPSED_TIME_ADD")
    public JAXBElement<ELAPSEDTIMEADDTypeShape> createELAPSEDTIMEADD(ELAPSEDTIMEADDTypeShape value) {
        return new JAXBElement<ELAPSEDTIMEADDTypeShape>(_ELAPSEDTIMEADD_QNAME, ELAPSEDTIMEADDTypeShape.class, null, value);
    }

}
