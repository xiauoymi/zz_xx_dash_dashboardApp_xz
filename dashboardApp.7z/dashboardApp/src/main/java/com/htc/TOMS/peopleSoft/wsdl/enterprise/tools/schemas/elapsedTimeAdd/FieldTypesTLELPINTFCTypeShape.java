
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FieldTypesTL_ELP_INTFC_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FieldTypesTL_ELP_INTFC_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BADGE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="EMPLID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="EMPL_RCD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType"/>
 *         &lt;element name="DUR" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesDateFieldType"/>
 *         &lt;element name="SEQNUM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType"/>
 *         &lt;element name="DELETE_DATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesDateFieldType"/>
 *         &lt;element name="ADD_DELETE_IND" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="TCD_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="TRC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="TL_QUANTITY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType" minOccurs="0"/>
 *         &lt;element name="CURRENCY_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="OVERRIDE_RATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType" minOccurs="0"/>
 *         &lt;element name="COMP_RATECD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="BILLABLE_IND" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="TCD_SUPERVISR_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="OPRID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="OVERRIDE_RSN_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="ACTION_DTTM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesDateTimeFieldType" minOccurs="0"/>
 *         &lt;element name="TASK_PROFILE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="TASK_PRFL_TMPLT_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="COUNTRY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="STATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="LOCALITY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="TL_COMMENTS" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FieldTypesTL_ELP_INTFC_TypeShape", propOrder = {
    "badgeid",
    "emplid",
    "emplrcd",
    "dur",
    "seqnum",
    "deletedate",
    "adddeleteind",
    "tcdid",
    "trc",
    "tlquantity",
    "currencycd",
    "overriderate",
    "compratecd",
    "billableind",
    "tcdsupervisrid",
    "oprid",
    "overridersncd",
    "actiondttm",
    "taskprofileid",
    "taskprfltmpltid",
    "country",
    "state",
    "locality",
    "tlcomments",
    "auditactn"
})
public class FieldTypesTLELPINTFCTypeShape {

    @XmlElement(name = "BADGE_ID", required = true)
    protected FieldTypesCharFieldType badgeid;
    @XmlElement(name = "EMPLID", required = true)
    protected FieldTypesCharFieldType emplid;
    @XmlElement(name = "EMPL_RCD", required = true)
    protected FieldTypesNumberFieldType emplrcd;
    
    

    
    
    
	@XmlElement(name = "DUR", required = true)
    protected FieldTypesDateFieldType dur;
    @XmlElement(name = "SEQNUM", required = true)
    protected FieldTypesNumberFieldType seqnum;
    @XmlElement(name = "DELETE_DATE", required = true)
    protected FieldTypesDateFieldType deletedate;
    @XmlElement(name = "ADD_DELETE_IND", required = true)
    protected FieldTypesCharFieldType adddeleteind;
    @XmlElement(name = "TCD_ID")
    protected FieldTypesCharFieldType tcdid;
    @XmlElement(name = "TRC")
    protected FieldTypesCharFieldType trc;
    @XmlElement(name = "TL_QUANTITY")
    protected FieldTypesNumberFieldType tlquantity;
    @XmlElement(name = "CURRENCY_CD")
    protected FieldTypesCharFieldType currencycd;
    @XmlElement(name = "OVERRIDE_RATE")
    protected FieldTypesNumberFieldType overriderate;
    @XmlElement(name = "COMP_RATECD")
    protected FieldTypesCharFieldType compratecd;
    @XmlElement(name = "BILLABLE_IND")
    protected FieldTypesCharFieldType billableind;
    @XmlElement(name = "TCD_SUPERVISR_ID")
    protected FieldTypesCharFieldType tcdsupervisrid;
    @XmlElement(name = "OPRID")
    protected FieldTypesCharFieldType oprid;
    @XmlElement(name = "OVERRIDE_RSN_CD")
    protected FieldTypesCharFieldType overridersncd;
    @XmlElement(name = "ACTION_DTTM")
    protected FieldTypesDateTimeFieldType actiondttm;
    @XmlElement(name = "TASK_PROFILE_ID")
    protected FieldTypesCharFieldType taskprofileid;
    @XmlElement(name = "TASK_PRFL_TMPLT_ID")
    protected FieldTypesCharFieldType taskprfltmpltid;
    @XmlElement(name = "COUNTRY")
    protected FieldTypesCharFieldType country;
    @XmlElement(name = "STATE")
    protected FieldTypesCharFieldType state;
    @XmlElement(name = "LOCALITY")
    protected FieldTypesCharFieldType locality;
    @XmlElement(name = "TL_COMMENTS")
    protected FieldTypesCharFieldType tlcomments;
    @XmlElement(name = "AUDIT_ACTN")
    protected FieldTypesCharFieldType auditactn;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    
    
    
    
    public FieldTypesTLELPINTFCTypeShape() {
		super();
	}

	public FieldTypesTLELPINTFCTypeShape(FieldTypesCharFieldType badgeid, FieldTypesCharFieldType emplid,
			FieldTypesNumberFieldType emplrcd, FieldTypesDateFieldType dur, FieldTypesNumberFieldType seqnum,
			FieldTypesDateFieldType deletedate, FieldTypesCharFieldType adddeleteind, FieldTypesCharFieldType tcdid,
			FieldTypesCharFieldType trc, FieldTypesNumberFieldType tlquantity, FieldTypesCharFieldType currencycd,
			FieldTypesNumberFieldType overriderate, FieldTypesCharFieldType compratecd,
			FieldTypesCharFieldType billableind, FieldTypesCharFieldType tcdsupervisrid, FieldTypesCharFieldType oprid,
			FieldTypesCharFieldType overridersncd, FieldTypesDateTimeFieldType actiondttm,
			FieldTypesCharFieldType taskprofileid, FieldTypesCharFieldType taskprfltmpltid,
			FieldTypesCharFieldType country, FieldTypesCharFieldType state, FieldTypesCharFieldType locality,
			FieldTypesCharFieldType tlcomments, FieldTypesCharFieldType auditactn, String clazz) {
		super();
		this.badgeid = badgeid;
		this.emplid = emplid;
		this.emplrcd = emplrcd;
		this.dur = dur;
		this.seqnum = seqnum;
		this.deletedate = deletedate;
		this.adddeleteind = adddeleteind;
		this.tcdid = tcdid;
		this.trc = trc;
		this.tlquantity = tlquantity;
		this.currencycd = currencycd;
		this.overriderate = overriderate;
		this.compratecd = compratecd;
		this.billableind = billableind;
		this.tcdsupervisrid = tcdsupervisrid;
		this.oprid = oprid;
		this.overridersncd = overridersncd;
		this.actiondttm = actiondttm;
		this.taskprofileid = taskprofileid;
		this.taskprfltmpltid = taskprfltmpltid;
		this.country = country;
		this.state = state;
		this.locality = locality;
		this.tlcomments = tlcomments;
		this.auditactn = auditactn;
		this.clazz = clazz;
	}
    
    /**
     * Gets the value of the badgeid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getBADGEID() {
        return badgeid;
    }

    /**
     * Sets the value of the badgeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setBADGEID(FieldTypesCharFieldType value) {
        this.badgeid = value;
    }

    /**
     * Gets the value of the emplid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getEMPLID() {
        return emplid;
    }

    /**
     * Sets the value of the emplid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setEMPLID(FieldTypesCharFieldType value) {
        this.emplid = value;
    }

    /**
     * Gets the value of the emplrcd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getEMPLRCD() {
        return emplrcd;
    }

    /**
     * Sets the value of the emplrcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setEMPLRCD(FieldTypesNumberFieldType value) {
        this.emplrcd = value;
    }

    /**
     * Gets the value of the dur property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public FieldTypesDateFieldType getDUR() {
        return dur;
    }

    /**
     * Sets the value of the dur property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public void setDUR(FieldTypesDateFieldType value) {
        this.dur = value;
    }

    /**
     * Gets the value of the seqnum property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getSEQNUM() {
        return seqnum;
    }

    /**
     * Sets the value of the seqnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setSEQNUM(FieldTypesNumberFieldType value) {
        this.seqnum = value;
    }

    /**
     * Gets the value of the deletedate property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public FieldTypesDateFieldType getDELETEDATE() {
        return deletedate;
    }

    /**
     * Sets the value of the deletedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public void setDELETEDATE(FieldTypesDateFieldType value) {
        this.deletedate = value;
    }

    /**
     * Gets the value of the adddeleteind property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getADDDELETEIND() {
        return adddeleteind;
    }

    /**
     * Sets the value of the adddeleteind property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setADDDELETEIND(FieldTypesCharFieldType value) {
        this.adddeleteind = value;
    }

    /**
     * Gets the value of the tcdid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTCDID() {
        return tcdid;
    }

    /**
     * Sets the value of the tcdid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTCDID(FieldTypesCharFieldType value) {
        this.tcdid = value;
    }

    /**
     * Gets the value of the trc property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTRC() {
        return trc;
    }

    /**
     * Sets the value of the trc property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTRC(FieldTypesCharFieldType value) {
        this.trc = value;
    }

    /**
     * Gets the value of the tlquantity property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getTLQUANTITY() {
        return tlquantity;
    }

    /**
     * Sets the value of the tlquantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setTLQUANTITY(FieldTypesNumberFieldType value) {
        this.tlquantity = value;
    }

    /**
     * Gets the value of the currencycd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getCURRENCYCD() {
        return currencycd;
    }

    /**
     * Sets the value of the currencycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setCURRENCYCD(FieldTypesCharFieldType value) {
        this.currencycd = value;
    }

    /**
     * Gets the value of the overriderate property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getOVERRIDERATE() {
        return overriderate;
    }

    /**
     * Sets the value of the overriderate property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setOVERRIDERATE(FieldTypesNumberFieldType value) {
        this.overriderate = value;
    }

    /**
     * Gets the value of the compratecd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getCOMPRATECD() {
        return compratecd;
    }

    /**
     * Sets the value of the compratecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setCOMPRATECD(FieldTypesCharFieldType value) {
        this.compratecd = value;
    }

    /**
     * Gets the value of the billableind property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getBILLABLEIND() {
        return billableind;
    }

    /**
     * Sets the value of the billableind property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setBILLABLEIND(FieldTypesCharFieldType value) {
        this.billableind = value;
    }

    /**
     * Gets the value of the tcdsupervisrid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTCDSUPERVISRID() {
        return tcdsupervisrid;
    }

    /**
     * Sets the value of the tcdsupervisrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTCDSUPERVISRID(FieldTypesCharFieldType value) {
        this.tcdsupervisrid = value;
    }

    /**
     * Gets the value of the oprid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getOPRID() {
        return oprid;
    }

    /**
     * Sets the value of the oprid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setOPRID(FieldTypesCharFieldType value) {
        this.oprid = value;
    }

    /**
     * Gets the value of the overridersncd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getOVERRIDERSNCD() {
        return overridersncd;
    }

    /**
     * Sets the value of the overridersncd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setOVERRIDERSNCD(FieldTypesCharFieldType value) {
        this.overridersncd = value;
    }

    /**
     * Gets the value of the actiondttm property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesDateTimeFieldType }
     *     
     */
    public FieldTypesDateTimeFieldType getACTIONDTTM() {
        return actiondttm;
    }

    /**
     * Sets the value of the actiondttm property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesDateTimeFieldType }
     *     
     */
    public void setACTIONDTTM(FieldTypesDateTimeFieldType value) {
        this.actiondttm = value;
    }

    /**
     * Gets the value of the taskprofileid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTASKPROFILEID() {
        return taskprofileid;
    }

    /**
     * Sets the value of the taskprofileid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTASKPROFILEID(FieldTypesCharFieldType value) {
        this.taskprofileid = value;
    }

    /**
     * Gets the value of the taskprfltmpltid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTASKPRFLTMPLTID() {
        return taskprfltmpltid;
    }

    /**
     * Sets the value of the taskprfltmpltid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTASKPRFLTMPLTID(FieldTypesCharFieldType value) {
        this.taskprfltmpltid = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getCOUNTRY() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setCOUNTRY(FieldTypesCharFieldType value) {
        this.country = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getSTATE() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setSTATE(FieldTypesCharFieldType value) {
        this.state = value;
    }

    /**
     * Gets the value of the locality property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getLOCALITY() {
        return locality;
    }

    /**
     * Sets the value of the locality property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setLOCALITY(FieldTypesCharFieldType value) {
        this.locality = value;
    }

    /**
     * Gets the value of the tlcomments property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTLCOMMENTS() {
        return tlcomments;
    }

    /**
     * Sets the value of the tlcomments property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTLCOMMENTS(FieldTypesCharFieldType value) {
        this.tlcomments = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setAUDITACTN(FieldTypesCharFieldType value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
