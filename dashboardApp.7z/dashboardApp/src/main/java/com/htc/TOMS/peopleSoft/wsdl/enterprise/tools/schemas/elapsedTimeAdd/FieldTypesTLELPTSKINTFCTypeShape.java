
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FieldTypesTL_ELPTSK_INTFC_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FieldTypesTL_ELPTSK_INTFC_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BADGE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="EMPLID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="EMPL_RCD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType"/>
 *         &lt;element name="DUR" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesDateFieldType"/>
 *         &lt;element name="SEQNUM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType"/>
 *         &lt;element name="DELETE_DATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesDateFieldType"/>
 *         &lt;element name="TASK_ELEMENT_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType"/>
 *         &lt;element name="TASK_ELEMENT_VAL" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FieldTypesTL_ELPTSK_INTFC_TypeShape", propOrder = {
    "badgeid",
    "emplid",
    "emplrcd",
    "dur",
    "seqnum",
    "deletedate",
    "taskelementcd",
    "taskelementval",
    "auditactn"
})
public class FieldTypesTLELPTSKINTFCTypeShape {

    @XmlElement(name = "BADGE_ID", required = true)
    protected FieldTypesCharFieldType badgeid;
    
    
    

	@XmlElement(name = "EMPLID", required = true)
    protected FieldTypesCharFieldType emplid;
    @XmlElement(name = "EMPL_RCD", required = true)
    protected FieldTypesNumberFieldType emplrcd;
    @XmlElement(name = "DUR", required = true)
    protected FieldTypesDateFieldType dur;
    @XmlElement(name = "SEQNUM", required = true)
    protected FieldTypesNumberFieldType seqnum;
    @XmlElement(name = "DELETE_DATE", required = true)
    protected FieldTypesDateFieldType deletedate;
    @XmlElement(name = "TASK_ELEMENT_CD", required = true)
    protected FieldTypesCharFieldType taskelementcd;
    @XmlElement(name = "TASK_ELEMENT_VAL")
    protected FieldTypesCharFieldType taskelementval;
    @XmlElement(name = "AUDIT_ACTN")
    protected FieldTypesCharFieldType auditactn;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    
    

    public FieldTypesTLELPTSKINTFCTypeShape() {
		super();
	}



	public FieldTypesTLELPTSKINTFCTypeShape(FieldTypesCharFieldType badgeid, FieldTypesCharFieldType emplid,
			FieldTypesNumberFieldType emplrcd, FieldTypesDateFieldType dur, FieldTypesNumberFieldType seqnum,
			FieldTypesDateFieldType deletedate, FieldTypesCharFieldType taskelementcd,
			FieldTypesCharFieldType taskelementval, FieldTypesCharFieldType auditactn, String clazz) {
		super();
		this.badgeid = badgeid;
		this.emplid = emplid;
		this.emplrcd = emplrcd;
		this.dur = dur;
		this.seqnum = seqnum;
		this.deletedate = deletedate;
		this.taskelementcd = taskelementcd;
		this.taskelementval = taskelementval;
		this.auditactn = auditactn;
		this.clazz = clazz;
	}
    
    
    
    /**
     * Gets the value of the badgeid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getBADGEID() {
        return badgeid;
    }

    /**
     * Sets the value of the badgeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setBADGEID(FieldTypesCharFieldType value) {
        this.badgeid = value;
    }

    /**
     * Gets the value of the emplid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getEMPLID() {
        return emplid;
    }

    /**
     * Sets the value of the emplid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setEMPLID(FieldTypesCharFieldType value) {
        this.emplid = value;
    }

    /**
     * Gets the value of the emplrcd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getEMPLRCD() {
        return emplrcd;
    }

    /**
     * Sets the value of the emplrcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setEMPLRCD(FieldTypesNumberFieldType value) {
        this.emplrcd = value;
    }

    /**
     * Gets the value of the dur property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public FieldTypesDateFieldType getDUR() {
        return dur;
    }

    /**
     * Sets the value of the dur property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public void setDUR(FieldTypesDateFieldType value) {
        this.dur = value;
    }

    /**
     * Gets the value of the seqnum property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getSEQNUM() {
        return seqnum;
    }

    /**
     * Sets the value of the seqnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setSEQNUM(FieldTypesNumberFieldType value) {
        this.seqnum = value;
    }

    /**
     * Gets the value of the deletedate property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public FieldTypesDateFieldType getDELETEDATE() {
        return deletedate;
    }

    /**
     * Sets the value of the deletedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesDateFieldType }
     *     
     */
    public void setDELETEDATE(FieldTypesDateFieldType value) {
        this.deletedate = value;
    }

    /**
     * Gets the value of the taskelementcd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTASKELEMENTCD() {
        return taskelementcd;
    }

    /**
     * Sets the value of the taskelementcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTASKELEMENTCD(FieldTypesCharFieldType value) {
        this.taskelementcd = value;
    }

    /**
     * Gets the value of the taskelementval property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getTASKELEMENTVAL() {
        return taskelementval;
    }

    /**
     * Sets the value of the taskelementval property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setTASKELEMENTVAL(FieldTypesCharFieldType value) {
        this.taskelementval = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setAUDITACTN(FieldTypesCharFieldType value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
