
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for TL_QUANTITY_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TL_QUANTITY_TypeShape">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1>TL_QUANTITY_TypeDef">
 *       &lt;attribute name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TL_QUANTITY_TypeShape", propOrder = {
    "value"
})
public class TLQUANTITYTypeShape {

    @XmlValue
    protected BigDecimal value;
    @XmlAttribute(name = "IsChanged")
    protected String isChanged;

    
    
    public TLQUANTITYTypeShape() {
		super();
	}

	public TLQUANTITYTypeShape(BigDecimal value) {
		super();
		this.value = value;
	}

	/**
     * TL_QUANTITY is a number of length 20 with a decimal position of 6
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValue(BigDecimal value) {
        this.value = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsChanged(String value) {
        this.isChanged = value;
    }

}
