
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ADD_DELETE_IND_TypeDef.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ADD_DELETE_IND_TypeDef">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="D"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ADD_DELETE_IND_TypeDef")
@XmlEnum
public enum ADDDELETEINDTypeDef {

    A,
    D;

    public String value() {
        return name();
    }

    public static ADDDELETEINDTypeDef fromValue(String v) {
        return valueOf(v);
    }

}
