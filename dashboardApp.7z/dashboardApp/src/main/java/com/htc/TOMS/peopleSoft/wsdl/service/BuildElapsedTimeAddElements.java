package com.htc.TOMS.peopleSoft.wsdl.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.htc.TOMS.peopleSoft.wsdl.enterprise.services.elapsedTimeAdd.ELAPSEDTIMEADD;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.services.elapsedTimeAdd.ELAPSEDTIMEADDPortType;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.ADDDELETEINDTypeDef;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.ADDDELETEINDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.AUDITACTNTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.BADGEIDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.BASELANGUAGECDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.BILLABLEINDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.DELETEDATETypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.DURTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.EMPLIDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.EMPLRCDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesCharFieldType;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesDateFieldType;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesDateTimeFieldType;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesNumberFieldType;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesPSCAMATypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesTLELPINTFCTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesTLELPTSKINTFCTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.FieldTypesTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.LANGUAGECDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.MSGNODENAMETypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.MSGSEQFLGTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.MsgDataTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.OVERRIDERATETypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.PROCESSINSTANCETypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.PSCAMAMsgDataRecordTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.PUBLISHRULEIDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.SEQNUMTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TASKELEMENTCDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TASKELEMENTVALTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TCDIDTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TLELPINTFCMsgDataRecordTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TLELPTSKINTFCMsgDataRecordTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TLQUANTITYTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TRCTypeShape;
import com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd.TransactionTypeShape;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;

/**
 * @author gayathria
 *
 */
public class BuildElapsedTimeAddElements {


	private static final Logger LOGGER = Logger.getLogger(BuildElapsedTimeAddElements.class);


	/**
	 * @Purpose Send Payroll Record To PeopleSoft
	 * @param getModAgentActivities
	 * @param agentId
	 * @param dateUnderReport
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String sendPayrollRecordToPeopleSoft(Map<String, List<?>> getModAgentActivities, String agentId, String dateUnderReport) {

		LOGGER.info("Inside sendPayrollRecordToPeopleSoft(Map<String, List<?>> getModAgentActivities)");

		String status ="";
		try {
			List<String> psoftColumnNamesList = (List<String>) getModAgentActivities.get(DashboardConstants.psoftColumnNames);
			List<List<String>> reportList = (List<List<String>>) getModAgentActivities.get(DashboardConstants.psoftColumnValues);


			MsgDataTypeShape dataTypeShape = new MsgDataTypeShape(gendrateTransaction_TypeShape(psoftColumnNamesList, 
					reportList));

			ELAPSEDTIMEADD elapsedTimeAdd = new ELAPSEDTIMEADD();
			ELAPSEDTIMEADDPortType elapsedTimeAddPortType = elapsedTimeAdd.getELAPSEDTIMEADDPort();
			elapsedTimeAddPortType.elapsedTIMEADD(buildElapsedTimeAddFields(), dataTypeShape); 

			status="Success : Payroll record sent to PS on "+new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()) +"for the Agent - "+agentId+" Date Under Report - " +dateUnderReport ;		

		} catch (Exception exception) {

			status="Failure : Payroll record not sent to PS on "+new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()) +"for the Agent - "+agentId+" Date Under Report - " +dateUnderReport;			

			LOGGER.error(status+"\n"+exception.getMessage(), exception);			

		}
		LOGGER.info(status);
		LOGGER.info("Exit sendPayrollRecordToPeopleSoft(Map<String, List<?>> getModAgentActivities)");
		return status ;
	}
	/**
	 * @param psoftColumnNamesList
	 * @param reportList
	 * @return List of TransactionType Shape
	 */
	public List<TransactionTypeShape> gendrateTransaction_TypeShape(List<String> psoftColumnNamesList, List<List<String>> reportList) {
		LOGGER.info("Inside sendPayrollRecordToPeopleSoft gendrateTransaction_TypeShape(List<String> psoftColumnNamesList, List<List<String>> reportList)");
		ArrayList<TransactionTypeShape> transaction_TypeShapes = new ArrayList<TransactionTypeShape>();

		for (List<String> record : reportList) {
			Map<String, String> payrollData = new HashMap<String, String>();

			for (int i = 0; i < psoftColumnNamesList.size(); i++) {
				payrollData.put(psoftColumnNamesList.get(i), record.get(i));

			}

			transaction_TypeShapes.add(new TransactionTypeShape(gendrateTL_ELP_INTFCMsgDataRecord_TypeShape(payrollData),
					gendratePSCAMATrasData()));

		}
		LOGGER.info("Exit sendPayrollRecordToPeopleSoft gendrateTransaction_TypeShape(List<String> psoftColumnNamesList, List<List<String>> reportList)");
		return transaction_TypeShapes;
	}

	/**
	 * Setting value for TL_ELP_INTFC
	 * @param payrollData
	 * @return
	 */
	private TLELPINTFCMsgDataRecordTypeShape gendrateTL_ELP_INTFCMsgDataRecord_TypeShape(Map<String, String> payrollData) {
		LOGGER.info("Inside gendrateTL_ELP_INTFCMsgDataRecord_TypeShape(Map<String, String> payrollData)");
		TLELPINTFCMsgDataRecordTypeShape msgDataTL_ELP_INTFC_TypeShape = new TLELPINTFCMsgDataRecordTypeShape();
		msgDataTL_ELP_INTFC_TypeShape.setBADGEID(new BADGEIDTypeShape());
		msgDataTL_ELP_INTFC_TypeShape.setEMPLID(new EMPLIDTypeShape(payrollData.get("EMPID")));
		msgDataTL_ELP_INTFC_TypeShape.setEMPLRCD(new EMPLRCDTypeShape(new BigInteger("0")));		
		msgDataTL_ELP_INTFC_TypeShape.setDUR(new DURTypeShape(ApplicationUtilities.stringToUtilDate(payrollData.get("DATE"), "yyyy-MM-dd")));		
		msgDataTL_ELP_INTFC_TypeShape.setSEQNUM(new SEQNUMTypeShape(new BigInteger(payrollData.get("SEQ"))));
		msgDataTL_ELP_INTFC_TypeShape.setDELETEDATE(new DELETEDATETypeShape());
		msgDataTL_ELP_INTFC_TypeShape.setADDDELETEIND(new ADDDELETEINDTypeShape(ADDDELETEINDTypeDef.fromValue("A")));
		msgDataTL_ELP_INTFC_TypeShape.setTCDID(new TCDIDTypeShape("MONET01"));
		msgDataTL_ELP_INTFC_TypeShape.setTRC(new TRCTypeShape(payrollData.get("CODE")));
		msgDataTL_ELP_INTFC_TypeShape.setTLQUANTITY(new TLQUANTITYTypeShape(new BigDecimal(!payrollData.get("TOTAL").equalsIgnoreCase("--") ? payrollData.get("TOTAL") : "0")));
		msgDataTL_ELP_INTFC_TypeShape.setOVERRIDERATE(new OVERRIDERATETypeShape(new BigDecimal("0")));
		msgDataTL_ELP_INTFC_TypeShape.setBILLABLEIND(new BILLABLEINDTypeShape("N"));
		msgDataTL_ELP_INTFC_TypeShape.setClazz("R");

		msgDataTL_ELP_INTFC_TypeShape.getTLELPTSKINTFCAndPSCAMA().add(gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(payrollData.get("EMPID")
				,payrollData.get("DATE")
				,"1"
				,"BUP"
				,payrollData.get("BUP")));
		msgDataTL_ELP_INTFC_TypeShape.getTLELPTSKINTFCAndPSCAMA().add(gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(payrollData.get("EMPID")
				,payrollData.get("DATE")
				,"2"
				,"PRJ"
				,payrollData.get("PRJ")));
		msgDataTL_ELP_INTFC_TypeShape.getTLELPTSKINTFCAndPSCAMA().add(gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(payrollData.get("EMPID")
				,payrollData.get("DATE")
				,"3"
				,"ACT"
				,payrollData.get("ACT")));


		msgDataTL_ELP_INTFC_TypeShape.getTLELPTSKINTFCAndPSCAMA().add(gendratePSCAMATrasData());
		LOGGER.info("Exit gendrateTL_ELP_INTFCMsgDataRecord_TypeShape(Map<String, String> payrollData)");
		return msgDataTL_ELP_INTFC_TypeShape;

	}



	/**
	 * @return FieldTypesTypeShape
	 */
	public FieldTypesTypeShape buildElapsedTimeAddFields() {
		LOGGER.info("Inside buildElapsedTimeAddFields()");
		BuildElapsedTimeAddElements gendElapsedTimeAddEle = new BuildElapsedTimeAddElements();
		LOGGER.info("Exit buildElapsedTimeAddFields()");
		return new FieldTypesTypeShape(gendElapsedTimeAddEle.gendrateTotalElapsedInterfaceObj(),
				gendElapsedTimeAddEle.getFieldTypesTL_ELPTSK_INTFC_TypeShapeObj(),
				gendElapsedTimeAddEle.gendratePSCAMAElementType());
	}

	/**
	 * Setting value for TL_ELP_INTFC
	 * @return FieldTypesTLELPINTFCTypeShape
	 */
	public FieldTypesTLELPINTFCTypeShape gendrateTotalElapsedInterfaceObj() {
		LOGGER.info("Inside & Exit gendrateTotalElapsedInterfaceObj()");
		return new FieldTypesTLELPINTFCTypeShape(new FieldTypesCharFieldType("CHAR"), 
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesDateFieldType("DATE"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesDateFieldType("DATE"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesDateTimeFieldType("DATETIME"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"), 
				"R");
	}

	/**
	 * @return FieldTypesTLELPTSKINTFCTypeShape
	 */
	public FieldTypesTLELPTSKINTFCTypeShape getFieldTypesTL_ELPTSK_INTFC_TypeShapeObj() {
		LOGGER.info("Inside & Exit getFieldTypesTL_ELPTSK_INTFC_TypeShapeObj()");
		return new FieldTypesTLELPTSKINTFCTypeShape(new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesDateFieldType("DATE"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesDateFieldType("DATE"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"), 
				"R");

	}

	/**
	 * @return FieldTypesPSCAMATypeShape
	 */
	public FieldTypesPSCAMATypeShape gendratePSCAMAElementType() {
		LOGGER.info("Inside and Exit gendratePSCAMAElementType() ");
		return new FieldTypesPSCAMATypeShape(
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesNumberFieldType("NUMBER"),
				new FieldTypesCharFieldType("CHAR"),
				new FieldTypesCharFieldType("CHAR"), "R");

	}

	/**
	 * @return PSCAMAMsgDataRecordTypeShape
	 */
	public PSCAMAMsgDataRecordTypeShape gendratePSCAMATrasData() {
		LOGGER.info("Inside gendratePSCAMATrasData() ");
		PSCAMAMsgDataRecordTypeShape PSCAMA_msgData = new PSCAMAMsgDataRecordTypeShape();

		LANGUAGECDTypeShape cd_TypeShape = new LANGUAGECDTypeShape();
		cd_TypeShape.setIsChanged("Y");
		PSCAMA_msgData.setLANGUAGECD(cd_TypeShape);
		PSCAMA_msgData.setAUDITACTN(new AUDITACTNTypeShape());
		BASELANGUAGECDTypeShape base_LANGUAGE_CD_TypeShape = new BASELANGUAGECDTypeShape();
		base_LANGUAGE_CD_TypeShape.setIsChanged("Y");
		PSCAMA_msgData.setBASELANGUAGECD(base_LANGUAGE_CD_TypeShape);
		PSCAMA_msgData.setMSGSEQFLG(new MSGSEQFLGTypeShape());
		PSCAMA_msgData.setPROCESSINSTANCE(new PROCESSINSTANCETypeShape(
				new BigInteger("0")));
		PSCAMA_msgData.setPUBLISHRULEID(new PUBLISHRULEIDTypeShape());
		PSCAMA_msgData.setMSGNODENAME(new MSGNODENAMETypeShape());
		PSCAMA_msgData.setClazz("R");
		LOGGER.info("Exit gendratePSCAMATrasData() ");
		return PSCAMA_msgData;

	}

	/**
	 * Setting value for TL_ELPTSK_INTFC
	 * @param emplId
	 * @param dur
	 * @param seq
	 * @param taskElementCode
	 * @param taskElementValue
	 * @return
	 */
	private TLELPTSKINTFCMsgDataRecordTypeShape gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(String emplId, String dur, String seq, String taskElementCode,String taskElementValue) {
		LOGGER.info("Inside gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(String emplId, String dur, String seq, String taskElementCode,String taskElementValue) ");
		TLELPTSKINTFCMsgDataRecordTypeShape dataRecord_TypeShape = new TLELPTSKINTFCMsgDataRecordTypeShape();
		dataRecord_TypeShape.setBADGEID(new BADGEIDTypeShape(""));
		dataRecord_TypeShape.setEMPLID(new EMPLIDTypeShape(emplId));
		dataRecord_TypeShape.setEMPLRCD(new EMPLRCDTypeShape(
				new BigInteger("0")));		
		dataRecord_TypeShape.setDUR(new DURTypeShape(ApplicationUtilities.stringToUtilDate(dur,"yyyy-MM-dd")));		
		dataRecord_TypeShape
		.setSEQNUM(new SEQNUMTypeShape(new BigInteger(seq)));
		dataRecord_TypeShape.setDELETEDATE(new DELETEDATETypeShape());
		dataRecord_TypeShape.setTASKELEMENTCD(new TASKELEMENTCDTypeShape(
				taskElementCode));
		dataRecord_TypeShape.setTASKELEMENTVAL(new TASKELEMENTVALTypeShape(
				taskElementValue));
		dataRecord_TypeShape.setClazz("R");
		LOGGER.info("Exit gendrateTL_ELPTSK_INTFCMsgDataRecord_TypeShape(String emplId, String dur, String seq, String taskElementCode,String taskElementValue) ");
		return dataRecord_TypeShape;
	}


}
