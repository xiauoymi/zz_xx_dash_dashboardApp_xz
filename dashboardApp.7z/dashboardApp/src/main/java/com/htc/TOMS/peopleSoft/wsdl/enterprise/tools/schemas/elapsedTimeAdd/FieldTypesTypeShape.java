
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FieldTypes_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FieldTypes_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="TL_ELP_INTFC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesTL_ELP_INTFC_TypeShape"/>
 *         &lt;element name="TL_ELPTSK_INTFC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesTL_ELPTSK_INTFC_TypeShape"/>
 *         &lt;element name="PSCAMA" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesPSCAMA_TypeShape"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FieldTypes_TypeShape", propOrder = {

})
public class FieldTypesTypeShape {

    @XmlElement(name = "TL_ELP_INTFC", required = true)
    protected FieldTypesTLELPINTFCTypeShape tlelpintfc;
    @XmlElement(name = "TL_ELPTSK_INTFC", required = true)
    protected FieldTypesTLELPTSKINTFCTypeShape tlelptskintfc;
    @XmlElement(name = "PSCAMA", required = true)
    protected FieldTypesPSCAMATypeShape pscama;



    public FieldTypesTypeShape(FieldTypesTLELPINTFCTypeShape tlelpintfc,
			FieldTypesTLELPTSKINTFCTypeShape tlelptskintfc, FieldTypesPSCAMATypeShape pscama) {
		super();
		this.tlelpintfc = tlelpintfc;
		this.tlelptskintfc = tlelptskintfc;
		this.pscama = pscama;
	}

	public FieldTypesTypeShape() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
     * Gets the value of the tlelpintfc property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesTLELPINTFCTypeShape }
     *     
     */
    public FieldTypesTLELPINTFCTypeShape getTLELPINTFC() {
        return tlelpintfc;
    }

    /**
     * Sets the value of the tlelpintfc property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesTLELPINTFCTypeShape }
     *     
     */
    public void setTLELPINTFC(FieldTypesTLELPINTFCTypeShape value) {
        this.tlelpintfc = value;
    }

    /**
     * Gets the value of the tlelptskintfc property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesTLELPTSKINTFCTypeShape }
     *     
     */
    public FieldTypesTLELPTSKINTFCTypeShape getTLELPTSKINTFC() {
        return tlelptskintfc;
    }

    /**
     * Sets the value of the tlelptskintfc property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesTLELPTSKINTFCTypeShape }
     *     
     */
    public void setTLELPTSKINTFC(FieldTypesTLELPTSKINTFCTypeShape value) {
        this.tlelptskintfc = value;
    }

    /**
     * Gets the value of the pscama property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesPSCAMATypeShape }
     *     
     */
    public FieldTypesPSCAMATypeShape getPSCAMA() {
        return pscama;
    }

    /**
     * Sets the value of the pscama property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesPSCAMATypeShape }
     *     
     */
    public void setPSCAMA(FieldTypesPSCAMATypeShape value) {
        this.pscama = value;
    }

}
