
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ELAPSED_TIME_ADD_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ELAPSED_TIME_ADD_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FieldTypes" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypes_TypeShape"/>
 *         &lt;element name="MsgData" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}MsgData_TypeShape"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ELAPSED_TIME_ADD_TypeShape", propOrder = {
    "fieldTypes",
    "msgData"
})
public class ELAPSEDTIMEADDTypeShape {

    @XmlElement(name = "FieldTypes", required = true)
    protected FieldTypesTypeShape fieldTypes;
    @XmlElement(name = "MsgData", required = true)
    protected MsgDataTypeShape msgData;

    /**
     * Gets the value of the fieldTypes property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesTypeShape }
     *     
     */
    public FieldTypesTypeShape getFieldTypes() {
        return fieldTypes;
    }

    /**
     * Sets the value of the fieldTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesTypeShape }
     *     
     */
    public void setFieldTypes(FieldTypesTypeShape value) {
        this.fieldTypes = value;
    }

    /**
     * Gets the value of the msgData property.
     * 
     * @return
     *     possible object is
     *     {@link MsgDataTypeShape }
     *     
     */
    public MsgDataTypeShape getMsgData() {
        return msgData;
    }

    /**
     * Sets the value of the msgData property.
     * 
     * @param value
     *     allowed object is
     *     {@link MsgDataTypeShape }
     *     
     */
    public void setMsgData(MsgDataTypeShape value) {
        this.msgData = value;
    }

}
