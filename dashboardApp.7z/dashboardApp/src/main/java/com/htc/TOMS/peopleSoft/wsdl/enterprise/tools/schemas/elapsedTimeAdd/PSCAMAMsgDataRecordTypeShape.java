
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PSCAMAMsgDataRecord_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PSCAMAMsgDataRecord_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LANGUAGE_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}LANGUAGE_CD_TypeShape" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}AUDIT_ACTN_TypeShape" minOccurs="0"/>
 *         &lt;element name="BASE_LANGUAGE_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}BASE_LANGUAGE_CD_TypeShape" minOccurs="0"/>
 *         &lt;element name="MSG_SEQ_FLG" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}MSG_SEQ_FLG_TypeShape" minOccurs="0"/>
 *         &lt;element name="PROCESS_INSTANCE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}PROCESS_INSTANCE_TypeShape" minOccurs="0"/>
 *         &lt;element name="PUBLISH_RULE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}PUBLISH_RULE_ID_TypeShape" minOccurs="0"/>
 *         &lt;element name="MSGNODENAME" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}MSGNODENAME_TypeShape" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PSCAMAMsgDataRecord_TypeShape", propOrder = {
    "languagecd",
    "auditactn",
    "baselanguagecd",
    "msgseqflg",
    "processinstance",
    "publishruleid",
    "msgnodename"
})
public class PSCAMAMsgDataRecordTypeShape {

    @XmlElement(name = "LANGUAGE_CD")
    protected LANGUAGECDTypeShape languagecd;
    @XmlElement(name = "AUDIT_ACTN")
    protected AUDITACTNTypeShape auditactn;
    @XmlElement(name = "BASE_LANGUAGE_CD")
    protected BASELANGUAGECDTypeShape baselanguagecd;
    @XmlElement(name = "MSG_SEQ_FLG")
    protected MSGSEQFLGTypeShape msgseqflg;
    @XmlElement(name = "PROCESS_INSTANCE")
    protected PROCESSINSTANCETypeShape processinstance;
    @XmlElement(name = "PUBLISH_RULE_ID")
    protected PUBLISHRULEIDTypeShape publishruleid;
    @XmlElement(name = "MSGNODENAME")
    protected MSGNODENAMETypeShape msgnodename;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    /**
     * Gets the value of the languagecd property.
     * 
     * @return
     *     possible object is
     *     {@link LANGUAGECDTypeShape }
     *     
     */
    public LANGUAGECDTypeShape getLANGUAGECD() {
        return languagecd;
    }

    /**
     * Sets the value of the languagecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link LANGUAGECDTypeShape }
     *     
     */
    public void setLANGUAGECD(LANGUAGECDTypeShape value) {
        this.languagecd = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public AUDITACTNTypeShape getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public void setAUDITACTN(AUDITACTNTypeShape value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the baselanguagecd property.
     * 
     * @return
     *     possible object is
     *     {@link BASELANGUAGECDTypeShape }
     *     
     */
    public BASELANGUAGECDTypeShape getBASELANGUAGECD() {
        return baselanguagecd;
    }

    /**
     * Sets the value of the baselanguagecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link BASELANGUAGECDTypeShape }
     *     
     */
    public void setBASELANGUAGECD(BASELANGUAGECDTypeShape value) {
        this.baselanguagecd = value;
    }

    /**
     * Gets the value of the msgseqflg property.
     * 
     * @return
     *     possible object is
     *     {@link MSGSEQFLGTypeShape }
     *     
     */
    public MSGSEQFLGTypeShape getMSGSEQFLG() {
        return msgseqflg;
    }

    /**
     * Sets the value of the msgseqflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link MSGSEQFLGTypeShape }
     *     
     */
    public void setMSGSEQFLG(MSGSEQFLGTypeShape value) {
        this.msgseqflg = value;
    }

    /**
     * Gets the value of the processinstance property.
     * 
     * @return
     *     possible object is
     *     {@link PROCESSINSTANCETypeShape }
     *     
     */
    public PROCESSINSTANCETypeShape getPROCESSINSTANCE() {
        return processinstance;
    }

    /**
     * Sets the value of the processinstance property.
     * 
     * @param value
     *     allowed object is
     *     {@link PROCESSINSTANCETypeShape }
     *     
     */
    public void setPROCESSINSTANCE(PROCESSINSTANCETypeShape value) {
        this.processinstance = value;
    }

    /**
     * Gets the value of the publishruleid property.
     * 
     * @return
     *     possible object is
     *     {@link PUBLISHRULEIDTypeShape }
     *     
     */
    public PUBLISHRULEIDTypeShape getPUBLISHRULEID() {
        return publishruleid;
    }

    /**
     * Sets the value of the publishruleid property.
     * 
     * @param value
     *     allowed object is
     *     {@link PUBLISHRULEIDTypeShape }
     *     
     */
    public void setPUBLISHRULEID(PUBLISHRULEIDTypeShape value) {
        this.publishruleid = value;
    }

    /**
     * Gets the value of the msgnodename property.
     * 
     * @return
     *     possible object is
     *     {@link MSGNODENAMETypeShape }
     *     
     */
    public MSGNODENAMETypeShape getMSGNODENAME() {
        return msgnodename;
    }

    /**
     * Sets the value of the msgnodename property.
     * 
     * @param value
     *     allowed object is
     *     {@link MSGNODENAMETypeShape }
     *     
     */
    public void setMSGNODENAME(MSGNODENAMETypeShape value) {
        this.msgnodename = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
