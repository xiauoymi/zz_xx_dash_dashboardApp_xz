
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FieldTypesPSCAMA_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FieldTypesPSCAMA_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LANGUAGE_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="BASE_LANGUAGE_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="MSG_SEQ_FLG" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="PROCESS_INSTANCE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesNumberFieldType" minOccurs="0"/>
 *         &lt;element name="PUBLISH_RULE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *         &lt;element name="MSGNODENAME" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}FieldTypesCharFieldType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FieldTypesPSCAMA_TypeShape", propOrder = {
    "languagecd",
    "auditactn",
    "baselanguagecd",
    "msgseqflg",
    "processinstance",
    "publishruleid",
    "msgnodename"
})
public class FieldTypesPSCAMATypeShape {

    @XmlElement(name = "LANGUAGE_CD")
    protected FieldTypesCharFieldType languagecd;
    @XmlElement(name = "AUDIT_ACTN")
    protected FieldTypesCharFieldType auditactn;
    @XmlElement(name = "BASE_LANGUAGE_CD")
    protected FieldTypesCharFieldType baselanguagecd;
    @XmlElement(name = "MSG_SEQ_FLG")
    protected FieldTypesCharFieldType msgseqflg;
    @XmlElement(name = "PROCESS_INSTANCE")
    protected FieldTypesNumberFieldType processinstance;
    @XmlElement(name = "PUBLISH_RULE_ID")
    protected FieldTypesCharFieldType publishruleid;
    @XmlElement(name = "MSGNODENAME")
    protected FieldTypesCharFieldType msgnodename;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    
    
    
    public FieldTypesPSCAMATypeShape() {
		super();
	}

	public FieldTypesPSCAMATypeShape(FieldTypesCharFieldType languagecd, FieldTypesCharFieldType auditactn,
			FieldTypesCharFieldType baselanguagecd, FieldTypesCharFieldType msgseqflg,
			FieldTypesNumberFieldType processinstance, FieldTypesCharFieldType publishruleid,
			FieldTypesCharFieldType msgnodename, String clazz) {
		super();
		this.languagecd = languagecd;
		this.auditactn = auditactn;
		this.baselanguagecd = baselanguagecd;
		this.msgseqflg = msgseqflg;
		this.processinstance = processinstance;
		this.publishruleid = publishruleid;
		this.msgnodename = msgnodename;
		this.clazz = clazz;
	}

	/**
     * Gets the value of the languagecd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getLANGUAGECD() {
        return languagecd;
    }

    /**
     * Sets the value of the languagecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setLANGUAGECD(FieldTypesCharFieldType value) {
        this.languagecd = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setAUDITACTN(FieldTypesCharFieldType value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the baselanguagecd property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getBASELANGUAGECD() {
        return baselanguagecd;
    }

    /**
     * Sets the value of the baselanguagecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setBASELANGUAGECD(FieldTypesCharFieldType value) {
        this.baselanguagecd = value;
    }

    /**
     * Gets the value of the msgseqflg property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getMSGSEQFLG() {
        return msgseqflg;
    }

    /**
     * Sets the value of the msgseqflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setMSGSEQFLG(FieldTypesCharFieldType value) {
        this.msgseqflg = value;
    }

    /**
     * Gets the value of the processinstance property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public FieldTypesNumberFieldType getPROCESSINSTANCE() {
        return processinstance;
    }

    /**
     * Sets the value of the processinstance property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesNumberFieldType }
     *     
     */
    public void setPROCESSINSTANCE(FieldTypesNumberFieldType value) {
        this.processinstance = value;
    }

    /**
     * Gets the value of the publishruleid property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getPUBLISHRULEID() {
        return publishruleid;
    }

    /**
     * Sets the value of the publishruleid property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setPUBLISHRULEID(FieldTypesCharFieldType value) {
        this.publishruleid = value;
    }

    /**
     * Gets the value of the msgnodename property.
     * 
     * @return
     *     possible object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public FieldTypesCharFieldType getMSGNODENAME() {
        return msgnodename;
    }

    /**
     * Sets the value of the msgnodename property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldTypesCharFieldType }
     *     
     */
    public void setMSGNODENAME(FieldTypesCharFieldType value) {
        this.msgnodename = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
