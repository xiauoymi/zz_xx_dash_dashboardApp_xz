
package com.htc.TOMS.peopleSoft.wsdl.enterprise.tools.schemas.elapsedTimeAdd;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TL_ELP_INTFCMsgDataRecord_TypeShape complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TL_ELP_INTFCMsgDataRecord_TypeShape">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BADGE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}BADGE_ID_TypeShape"/>
 *         &lt;element name="EMPLID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}EMPLID_TypeShape"/>
 *         &lt;element name="EMPL_RCD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}EMPL_RCD_TypeShape"/>
 *         &lt;element name="DUR" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}DUR_TypeShape"/>
 *         &lt;element name="SEQNUM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}SEQNUM_TypeShape"/>
 *         &lt;element name="DELETE_DATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}DELETE_DATE_TypeShape"/>
 *         &lt;element name="ADD_DELETE_IND" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}ADD_DELETE_IND_TypeShape"/>
 *         &lt;element name="TCD_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TCD_ID_TypeShape" minOccurs="0"/>
 *         &lt;element name="TRC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TRC_TypeShape" minOccurs="0"/>
 *         &lt;element name="TL_QUANTITY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TL_QUANTITY_TypeShape" minOccurs="0"/>
 *         &lt;element name="CURRENCY_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}CURRENCY_CD_TypeShape" minOccurs="0"/>
 *         &lt;element name="OVERRIDE_RATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}OVERRIDE_RATE_TypeShape" minOccurs="0"/>
 *         &lt;element name="COMP_RATECD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}COMP_RATECD_TypeShape" minOccurs="0"/>
 *         &lt;element name="BILLABLE_IND" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}BILLABLE_IND_TypeShape" minOccurs="0"/>
 *         &lt;element name="TCD_SUPERVISR_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TCD_SUPERVISR_ID_TypeShape" minOccurs="0"/>
 *         &lt;element name="OPRID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}OPRID_TypeShape" minOccurs="0"/>
 *         &lt;element name="OVERRIDE_RSN_CD" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}OVERRIDE_RSN_CD_TypeShape" minOccurs="0"/>
 *         &lt;element name="ACTION_DTTM" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}ACTION_DTTM_TypeShape" minOccurs="0"/>
 *         &lt;element name="TASK_PROFILE_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TASK_PROFILE_ID_TypeShape" minOccurs="0"/>
 *         &lt;element name="TASK_PRFL_TMPLT_ID" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TASK_PRFL_TMPLT_ID_TypeShape" minOccurs="0"/>
 *         &lt;element name="COUNTRY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}COUNTRY_TypeShape" minOccurs="0"/>
 *         &lt;element name="STATE" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}STATE_TypeShape" minOccurs="0"/>
 *         &lt;element name="LOCALITY" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}LOCALITY_TypeShape" minOccurs="0"/>
 *         &lt;element name="TL_COMMENTS" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TL_COMMENTS_TypeShape" minOccurs="0"/>
 *         &lt;element name="AUDIT_ACTN" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}AUDIT_ACTN_TypeShape" minOccurs="0"/>
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0">
 *           &lt;element name="TL_ELPTSK_INTFC" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}TL_ELPTSK_INTFCMsgDataRecord_TypeShape"/>
 *           &lt;element name="PSCAMA" type="{http://xmlns.oracle.com/Enterprise/Tools/schemas/ELAPSED_TIME_ADD.VERSION_1}PSCAMAMsgDataRecord_TypeShape" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/sequence>
 *       &lt;attribute name="class" use="required" type="{http://www.w3.org/2001/XMLSchema}string" fixed="R" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TL_ELP_INTFCMsgDataRecord_TypeShape", propOrder = {
    "badgeid",
    "emplid",
    "emplrcd",
    "dur",
    "seqnum",
    "deletedate",
    "adddeleteind",
    "tcdid",
    "trc",
    "tlquantity",
    "currencycd",
    "overriderate",
    "compratecd",
    "billableind",
    "tcdsupervisrid",
    "oprid",
    "overridersncd",
    "actiondttm",
    "taskprofileid",
    "taskprfltmpltid",
    "country",
    "state",
    "locality",
    "tlcomments",
    "auditactn",
    "tlelptskintfcAndPSCAMA"
})
public class TLELPINTFCMsgDataRecordTypeShape {

    @XmlElement(name = "BADGE_ID", required = true)
    protected BADGEIDTypeShape badgeid;
    @XmlElement(name = "EMPLID", required = true)
    protected EMPLIDTypeShape emplid;
    @XmlElement(name = "EMPL_RCD", required = true)
    protected EMPLRCDTypeShape emplrcd;
    @XmlElement(name = "DUR", required = true)
    protected DURTypeShape dur;
    @XmlElement(name = "SEQNUM", required = true)
    protected SEQNUMTypeShape seqnum;
    @XmlElement(name = "DELETE_DATE", required = true)
    protected DELETEDATETypeShape deletedate;
    @XmlElement(name = "ADD_DELETE_IND", required = true)
    protected ADDDELETEINDTypeShape adddeleteind;
    @XmlElement(name = "TCD_ID")
    protected TCDIDTypeShape tcdid;
    @XmlElement(name = "TRC")
    protected TRCTypeShape trc;
    @XmlElement(name = "TL_QUANTITY")
    protected TLQUANTITYTypeShape tlquantity;
    @XmlElement(name = "CURRENCY_CD")
    protected CURRENCYCDTypeShape currencycd;
    @XmlElement(name = "OVERRIDE_RATE")
    protected OVERRIDERATETypeShape overriderate;
    @XmlElement(name = "COMP_RATECD")
    protected COMPRATECDTypeShape compratecd;
    @XmlElement(name = "BILLABLE_IND")
    protected BILLABLEINDTypeShape billableind;
    @XmlElement(name = "TCD_SUPERVISR_ID")
    protected TCDSUPERVISRIDTypeShape tcdsupervisrid;
    @XmlElement(name = "OPRID")
    protected OPRIDTypeShape oprid;
    @XmlElement(name = "OVERRIDE_RSN_CD")
    protected OVERRIDERSNCDTypeShape overridersncd;
    @XmlElement(name = "ACTION_DTTM")
    protected ACTIONDTTMTypeShape actiondttm;
    @XmlElement(name = "TASK_PROFILE_ID")
    protected TASKPROFILEIDTypeShape taskprofileid;
    @XmlElement(name = "TASK_PRFL_TMPLT_ID")
    protected TASKPRFLTMPLTIDTypeShape taskprfltmpltid;
    @XmlElement(name = "COUNTRY")
    protected COUNTRYTypeShape country;
    @XmlElement(name = "STATE")
    protected STATETypeShape state;
    @XmlElement(name = "LOCALITY")
    protected LOCALITYTypeShape locality;
    @XmlElement(name = "TL_COMMENTS")
    protected TLCOMMENTSTypeShape tlcomments;
    @XmlElement(name = "AUDIT_ACTN")
    protected AUDITACTNTypeShape auditactn;
    @XmlElements({
        @XmlElement(name = "TL_ELPTSK_INTFC", type = TLELPTSKINTFCMsgDataRecordTypeShape.class),
        @XmlElement(name = "PSCAMA", type = PSCAMAMsgDataRecordTypeShape.class)
    })
    protected List<Object> tlelptskintfcAndPSCAMA;
    @XmlAttribute(name = "class", required = true)
    protected String clazz;

    /**
     * Gets the value of the badgeid property.
     * 
     * @return
     *     possible object is
     *     {@link BADGEIDTypeShape }
     *     
     */
    public BADGEIDTypeShape getBADGEID() {
        return badgeid;
    }

    /**
     * Sets the value of the badgeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BADGEIDTypeShape }
     *     
     */
    public void setBADGEID(BADGEIDTypeShape value) {
        this.badgeid = value;
    }

    /**
     * Gets the value of the emplid property.
     * 
     * @return
     *     possible object is
     *     {@link EMPLIDTypeShape }
     *     
     */
    public EMPLIDTypeShape getEMPLID() {
        return emplid;
    }

    /**
     * Sets the value of the emplid property.
     * 
     * @param value
     *     allowed object is
     *     {@link EMPLIDTypeShape }
     *     
     */
    public void setEMPLID(EMPLIDTypeShape value) {
        this.emplid = value;
    }

    /**
     * Gets the value of the emplrcd property.
     * 
     * @return
     *     possible object is
     *     {@link EMPLRCDTypeShape }
     *     
     */
    public EMPLRCDTypeShape getEMPLRCD() {
        return emplrcd;
    }

    /**
     * Sets the value of the emplrcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link EMPLRCDTypeShape }
     *     
     */
    public void setEMPLRCD(EMPLRCDTypeShape value) {
        this.emplrcd = value;
    }

    /**
     * Gets the value of the dur property.
     * 
     * @return
     *     possible object is
     *     {@link DURTypeShape }
     *     
     */
    public DURTypeShape getDUR() {
        return dur;
    }

    /**
     * Sets the value of the dur property.
     * 
     * @param value
     *     allowed object is
     *     {@link DURTypeShape }
     *     
     */
    public void setDUR(DURTypeShape value) {
        this.dur = value;
    }

    /**
     * Gets the value of the seqnum property.
     * 
     * @return
     *     possible object is
     *     {@link SEQNUMTypeShape }
     *     
     */
    public SEQNUMTypeShape getSEQNUM() {
        return seqnum;
    }

    /**
     * Sets the value of the seqnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link SEQNUMTypeShape }
     *     
     */
    public void setSEQNUM(SEQNUMTypeShape value) {
        this.seqnum = value;
    }

    /**
     * Gets the value of the deletedate property.
     * 
     * @return
     *     possible object is
     *     {@link DELETEDATETypeShape }
     *     
     */
    public DELETEDATETypeShape getDELETEDATE() {
        return deletedate;
    }

    /**
     * Sets the value of the deletedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DELETEDATETypeShape }
     *     
     */
    public void setDELETEDATE(DELETEDATETypeShape value) {
        this.deletedate = value;
    }

    /**
     * Gets the value of the adddeleteind property.
     * 
     * @return
     *     possible object is
     *     {@link ADDDELETEINDTypeShape }
     *     
     */
    public ADDDELETEINDTypeShape getADDDELETEIND() {
        return adddeleteind;
    }

    /**
     * Sets the value of the adddeleteind property.
     * 
     * @param value
     *     allowed object is
     *     {@link ADDDELETEINDTypeShape }
     *     
     */
    public void setADDDELETEIND(ADDDELETEINDTypeShape value) {
        this.adddeleteind = value;
    }

    /**
     * Gets the value of the tcdid property.
     * 
     * @return
     *     possible object is
     *     {@link TCDIDTypeShape }
     *     
     */
    public TCDIDTypeShape getTCDID() {
        return tcdid;
    }

    /**
     * Sets the value of the tcdid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCDIDTypeShape }
     *     
     */
    public void setTCDID(TCDIDTypeShape value) {
        this.tcdid = value;
    }

    /**
     * Gets the value of the trc property.
     * 
     * @return
     *     possible object is
     *     {@link TRCTypeShape }
     *     
     */
    public TRCTypeShape getTRC() {
        return trc;
    }

    /**
     * Sets the value of the trc property.
     * 
     * @param value
     *     allowed object is
     *     {@link TRCTypeShape }
     *     
     */
    public void setTRC(TRCTypeShape value) {
        this.trc = value;
    }

    /**
     * Gets the value of the tlquantity property.
     * 
     * @return
     *     possible object is
     *     {@link TLQUANTITYTypeShape }
     *     
     */
    public TLQUANTITYTypeShape getTLQUANTITY() {
        return tlquantity;
    }

    /**
     * Sets the value of the tlquantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link TLQUANTITYTypeShape }
     *     
     */
    public void setTLQUANTITY(TLQUANTITYTypeShape value) {
        this.tlquantity = value;
    }

    /**
     * Gets the value of the currencycd property.
     * 
     * @return
     *     possible object is
     *     {@link CURRENCYCDTypeShape }
     *     
     */
    public CURRENCYCDTypeShape getCURRENCYCD() {
        return currencycd;
    }

    /**
     * Sets the value of the currencycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link CURRENCYCDTypeShape }
     *     
     */
    public void setCURRENCYCD(CURRENCYCDTypeShape value) {
        this.currencycd = value;
    }

    /**
     * Gets the value of the overriderate property.
     * 
     * @return
     *     possible object is
     *     {@link OVERRIDERATETypeShape }
     *     
     */
    public OVERRIDERATETypeShape getOVERRIDERATE() {
        return overriderate;
    }

    /**
     * Sets the value of the overriderate property.
     * 
     * @param value
     *     allowed object is
     *     {@link OVERRIDERATETypeShape }
     *     
     */
    public void setOVERRIDERATE(OVERRIDERATETypeShape value) {
        this.overriderate = value;
    }

    /**
     * Gets the value of the compratecd property.
     * 
     * @return
     *     possible object is
     *     {@link COMPRATECDTypeShape }
     *     
     */
    public COMPRATECDTypeShape getCOMPRATECD() {
        return compratecd;
    }

    /**
     * Sets the value of the compratecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link COMPRATECDTypeShape }
     *     
     */
    public void setCOMPRATECD(COMPRATECDTypeShape value) {
        this.compratecd = value;
    }

    /**
     * Gets the value of the billableind property.
     * 
     * @return
     *     possible object is
     *     {@link BILLABLEINDTypeShape }
     *     
     */
    public BILLABLEINDTypeShape getBILLABLEIND() {
        return billableind;
    }

    /**
     * Sets the value of the billableind property.
     * 
     * @param value
     *     allowed object is
     *     {@link BILLABLEINDTypeShape }
     *     
     */
    public void setBILLABLEIND(BILLABLEINDTypeShape value) {
        this.billableind = value;
    }

    /**
     * Gets the value of the tcdsupervisrid property.
     * 
     * @return
     *     possible object is
     *     {@link TCDSUPERVISRIDTypeShape }
     *     
     */
    public TCDSUPERVISRIDTypeShape getTCDSUPERVISRID() {
        return tcdsupervisrid;
    }

    /**
     * Sets the value of the tcdsupervisrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCDSUPERVISRIDTypeShape }
     *     
     */
    public void setTCDSUPERVISRID(TCDSUPERVISRIDTypeShape value) {
        this.tcdsupervisrid = value;
    }

    /**
     * Gets the value of the oprid property.
     * 
     * @return
     *     possible object is
     *     {@link OPRIDTypeShape }
     *     
     */
    public OPRIDTypeShape getOPRID() {
        return oprid;
    }

    /**
     * Sets the value of the oprid property.
     * 
     * @param value
     *     allowed object is
     *     {@link OPRIDTypeShape }
     *     
     */
    public void setOPRID(OPRIDTypeShape value) {
        this.oprid = value;
    }

    /**
     * Gets the value of the overridersncd property.
     * 
     * @return
     *     possible object is
     *     {@link OVERRIDERSNCDTypeShape }
     *     
     */
    public OVERRIDERSNCDTypeShape getOVERRIDERSNCD() {
        return overridersncd;
    }

    /**
     * Sets the value of the overridersncd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OVERRIDERSNCDTypeShape }
     *     
     */
    public void setOVERRIDERSNCD(OVERRIDERSNCDTypeShape value) {
        this.overridersncd = value;
    }

    /**
     * Gets the value of the actiondttm property.
     * 
     * @return
     *     possible object is
     *     {@link ACTIONDTTMTypeShape }
     *     
     */
    public ACTIONDTTMTypeShape getACTIONDTTM() {
        return actiondttm;
    }

    /**
     * Sets the value of the actiondttm property.
     * 
     * @param value
     *     allowed object is
     *     {@link ACTIONDTTMTypeShape }
     *     
     */
    public void setACTIONDTTM(ACTIONDTTMTypeShape value) {
        this.actiondttm = value;
    }

    /**
     * Gets the value of the taskprofileid property.
     * 
     * @return
     *     possible object is
     *     {@link TASKPROFILEIDTypeShape }
     *     
     */
    public TASKPROFILEIDTypeShape getTASKPROFILEID() {
        return taskprofileid;
    }

    /**
     * Sets the value of the taskprofileid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TASKPROFILEIDTypeShape }
     *     
     */
    public void setTASKPROFILEID(TASKPROFILEIDTypeShape value) {
        this.taskprofileid = value;
    }

    /**
     * Gets the value of the taskprfltmpltid property.
     * 
     * @return
     *     possible object is
     *     {@link TASKPRFLTMPLTIDTypeShape }
     *     
     */
    public TASKPRFLTMPLTIDTypeShape getTASKPRFLTMPLTID() {
        return taskprfltmpltid;
    }

    /**
     * Sets the value of the taskprfltmpltid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TASKPRFLTMPLTIDTypeShape }
     *     
     */
    public void setTASKPRFLTMPLTID(TASKPRFLTMPLTIDTypeShape value) {
        this.taskprfltmpltid = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link COUNTRYTypeShape }
     *     
     */
    public COUNTRYTypeShape getCOUNTRY() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link COUNTRYTypeShape }
     *     
     */
    public void setCOUNTRY(COUNTRYTypeShape value) {
        this.country = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link STATETypeShape }
     *     
     */
    public STATETypeShape getSTATE() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link STATETypeShape }
     *     
     */
    public void setSTATE(STATETypeShape value) {
        this.state = value;
    }

    /**
     * Gets the value of the locality property.
     * 
     * @return
     *     possible object is
     *     {@link LOCALITYTypeShape }
     *     
     */
    public LOCALITYTypeShape getLOCALITY() {
        return locality;
    }

    /**
     * Sets the value of the locality property.
     * 
     * @param value
     *     allowed object is
     *     {@link LOCALITYTypeShape }
     *     
     */
    public void setLOCALITY(LOCALITYTypeShape value) {
        this.locality = value;
    }

    /**
     * Gets the value of the tlcomments property.
     * 
     * @return
     *     possible object is
     *     {@link TLCOMMENTSTypeShape }
     *     
     */
    public TLCOMMENTSTypeShape getTLCOMMENTS() {
        return tlcomments;
    }

    /**
     * Sets the value of the tlcomments property.
     * 
     * @param value
     *     allowed object is
     *     {@link TLCOMMENTSTypeShape }
     *     
     */
    public void setTLCOMMENTS(TLCOMMENTSTypeShape value) {
        this.tlcomments = value;
    }

    /**
     * Gets the value of the auditactn property.
     * 
     * @return
     *     possible object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public AUDITACTNTypeShape getAUDITACTN() {
        return auditactn;
    }

    /**
     * Sets the value of the auditactn property.
     * 
     * @param value
     *     allowed object is
     *     {@link AUDITACTNTypeShape }
     *     
     */
    public void setAUDITACTN(AUDITACTNTypeShape value) {
        this.auditactn = value;
    }

    /**
     * Gets the value of the tlelptskintfcAndPSCAMA property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tlelptskintfcAndPSCAMA property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTLELPTSKINTFCAndPSCAMA().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TLELPTSKINTFCMsgDataRecordTypeShape }
     * {@link PSCAMAMsgDataRecordTypeShape }
     * 
     * 
     */
    public List<Object> getTLELPTSKINTFCAndPSCAMA() {
        if (tlelptskintfcAndPSCAMA == null) {
            tlelptskintfcAndPSCAMA = new ArrayList<Object>();
        }
        return this.tlelptskintfcAndPSCAMA;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        if (clazz == null) {
            return "R";
        } else {
            return clazz;
        }
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

}
