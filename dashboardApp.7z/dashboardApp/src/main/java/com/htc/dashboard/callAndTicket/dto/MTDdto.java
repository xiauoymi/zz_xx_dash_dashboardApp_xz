package com.htc.dashboard.callAndTicket.dto;

public class MTDdto {

	String userId=null;
	String authType=null;
	String remedyIds=null;
	String mtdGroupID=null;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	public String getRemedyIds() {
		return remedyIds;
	}
	public void setRemedyIds(String remedyIds) {
		this.remedyIds = remedyIds;
	}
	public String getMtdGroupID() {
		return mtdGroupID;
	}
	public void setMtdGroupID(String mtdGroupID) {
		this.mtdGroupID = mtdGroupID;
	}



}
