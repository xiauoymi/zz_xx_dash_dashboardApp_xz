package com.htc.dashboard.callAndTicket.dto;

public class TotalContactsDTO {

	private String clientName;
	private String month;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
}






