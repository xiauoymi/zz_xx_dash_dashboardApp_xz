package com.htc.dashboard.callAndTicket.dto;

import java.util.ArrayList;
import java.util.List;

public class SLACallSummaryDTO {

	List<String> callsAbandoned =new ArrayList<>();
	List<String> callsOffered =new ArrayList<>();
	List<String> avgTalkTimeList =new ArrayList<>();
	List<String> callsAnswered =new ArrayList<>();
	public List<String> getCallsAbandoned() {
		return callsAbandoned;
	}
	public void setCallsAbandoned(List<String> callsAbandoned) {
		this.callsAbandoned = callsAbandoned;
	}
	public List<String> getCallsOffered() {
		return callsOffered;
	}
	public void setCallsOffered(List<String> callsOffered) {
		this.callsOffered = callsOffered;
	}
	public List<String> getAvgTalkTimeList() {
		return avgTalkTimeList;
	}
	public void setAvgTalkTimeList(List<String> avgTalkTimeList) {
		this.avgTalkTimeList = avgTalkTimeList;
	}
	public List<String> getCallsAnswered() {
		return callsAnswered;
	}
	public void setCallsAnswered(List<String> callsAnswered) {
		this.callsAnswered = callsAnswered;
	}

}
