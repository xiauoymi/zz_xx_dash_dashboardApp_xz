package com.htc.dashboard.agent.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.dashboard.agent.dao.AgentDeskDisplayDAO;
import com.htc.dashboard.agent.dto.AgentDeskDisplayDTO;
import com.htc.utility.DashboardConstants;
/*
 * HTC_Offshore
 * purpose: return  AgentDeskDisplay DataSet
 * */
@Controller
public class AgentDeskDisplayController {

	private static final Logger logger = Logger
			.getLogger(AgentDeskDisplayController.class);

	@Autowired
	private AgentDeskDisplayDAO agentDeskDisplayDAO;

	@RequestMapping(value = "/agentDeskDisplay", method = RequestMethod.POST)
	public String getAgentDeskDisplay(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {

		String userName = (String) session.getAttribute("username");
		AgentDeskDisplayDTO agentDeskDisDTO= new AgentDeskDisplayDTO();
		Map<String, List<?>> agentDeskDispalyMap = null;
		if(userName != null && !("".equals(userName))){
			agentDeskDisDTO.setuserName(userName);
			try {
				agentDeskDispalyMap = agentDeskDisplayDAO
						.agentDeskDisplayTableCall(agentDeskDisDTO);
				logger.info("agentValue----"+agentDeskDispalyMap);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			model.addAttribute(DashboardConstants.AGENTDESKDISPALYMAP,
					agentDeskDispalyMap);
			return "dashboardApp/agent/AgentDesktopDisplay";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/csdAgentDeskAjaxAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> ajaxAgentDesk(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		String userName = (String) session.getAttribute("username");
		AgentDeskDisplayDTO agentDeskDisDTO= new AgentDeskDisplayDTO();
		Map<String, List<?>> agentDeskDispalyMap = null;
		agentDeskDisDTO.setuserName(userName);
		try {
			agentDeskDispalyMap = agentDeskDisplayDAO
					.agentDeskDisplayTableCall(agentDeskDisDTO);
			logger.info("AutorefereshagentValue----"+agentDeskDispalyMap);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return agentDeskDispalyMap;
	}

}
