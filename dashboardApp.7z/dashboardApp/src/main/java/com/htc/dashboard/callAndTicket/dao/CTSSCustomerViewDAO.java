package com.htc.dashboard.callAndTicket.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.htc.dashboard.callAndTicket.dto.CTITableDTO;
import com.htc.dashboard.callAndTicket.dto.ProblemTicketDetail;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;
import com.htc.dashboard.callAndTicket.dto.IncidentDTO;
import com.htc.utility.QueryBuilder;

@Repository
public class CTSSCustomerViewDAO {

	private DataSource dataSource;
	Connection connection = null;
	Statement statement = null;
	PreparedStatement prepareStatement = null;
	ResultSet resultSet = null;
	CallableStatement callableStatement = null;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	public List<List<String>> ctssCustomerViewTreeSelect(String groupList) throws SQLException, NamingException {
		List<List<String>> ctssCustomerTreeList =new  ArrayList<List<String>>();

		String query = "";
		List<String> ctssCustomerNodeLabelList = new ArrayList<String>();
		List<String> ctssCustomerNodeNameList = new ArrayList<String>();


		try {
			connection = dataSource.getConnection();
			query=QueryBuilder.getCustomerViewTreeSelect(groupList);
			statement  = connection.createStatement();
			resultSet  = statement.executeQuery(query);

			while(resultSet.next()){
				String nodeName = resultSet.getString("node_name").replaceAll(DashboardConstants.REMOVED_LABEL_NAME,"");

				ctssCustomerNodeNameList.add(nodeName);

				ctssCustomerNodeLabelList.add(resultSet.getString("node_label"));
			}
			ctssCustomerTreeList.add(ctssCustomerNodeNameList);
			ctssCustomerTreeList.add(ctssCustomerNodeLabelList);

		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != prepareStatement)
					prepareStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return ctssCustomerTreeList;
	}


	public List<String> ctssCustomerViewCallSLAPerformanceToday(String clientName) throws SQLException, NamingException {

		List<String> tableDetails = new ArrayList<String>(); 

		String  day = DashboardConstants.TODAY;

		String query = "";


		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_db_SD_CustomerView_SLAPerformance;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,day);
			callableStatement.setString(2,clientName);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				String cap = resultSet.getString("Calls Abandoned Pct");
				String flr = resultSet.getString("First Level Resolution");
				String asa = resultSet.getString("Avg speed to answer");
				String dba = resultSet.getString("DBA%");

				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(cap);
				}
				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(flr);
				}
				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(asa);
				}
				if(dba==null||dba.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(dba);
				}


			}

		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	
	


	public List<String> ctssCustomerViewCallSLAPerformanceCurrentMonth(String clientName) throws SQLException, NamingException {

		List<String> tableDetails = new ArrayList<String>(); 

		String  day = DashboardConstants.CURRENT_MONTH;		
		String query = "";


		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_db_SD_CustomerView_SLAPerformance;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,day);
			callableStatement.setString(2,clientName);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				String cap = resultSet.getString("Calls Abandoned Pct");
				String flr = resultSet.getString("First Level Resolution");
				String asa = resultSet.getString("Avg speed to answer");
				String dba = resultSet.getString("DBA%");

				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(cap);
				}
				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(flr);
				}
				if(cap==null||cap.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(asa);
				}
				if(dba==null||dba.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(dba);
				}
			}
		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}

	

	public List<String> ctssCallSummaryToday(String clientName) throws SQLException, NamingException {

		List<String> tableDetails = new ArrayList<String>(); 

		String  day = DashboardConstants.TODAY;

		String query = "";


		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_db_SD_CustomerView_CallSummary;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,day);
			callableStatement.setString(2,clientName);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				String callsOffered = resultSet.getString("Calls Offered");
				String callsAnswered = resultSet.getString("Calls Answered");
				String avgTalkTime = resultSet.getString("Avg Talk time");
				String callsAbaodoned = resultSet.getString("Calls Abandoned");

				if(callsOffered==null||callsOffered.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsOffered);
				}
				if(callsAnswered==null||callsAnswered.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsAnswered);
				}
				if(avgTalkTime==null||avgTalkTime.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(avgTalkTime);
				}
				if(callsAbaodoned==null||callsAbaodoned.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsAbaodoned);
				}

			}

		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}




	public List<String> ctssCallSummaryCurrentMonth(String clientName) throws SQLException, NamingException {

		List<String> tableDetails = new ArrayList<String>(); 

		String  day = DashboardConstants.CURRENT_MONTH;

		String query = "";


		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_db_SD_CustomerView_CallSummary;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,day);
			callableStatement.setString(2,clientName);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				String callsOffered = resultSet.getString("Calls Offered");
				String callsAnswered = resultSet.getString("Calls Answered");
				String avgTalkTime = resultSet.getString("Avg Talk time");
				String callsAbaodoned = resultSet.getString("Calls Abandoned");

				if(callsOffered==null||callsOffered.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsOffered);
				}
				if(callsAnswered==null||callsAnswered.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsAnswered);
				}
				if(avgTalkTime==null||avgTalkTime.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(avgTalkTime);
				}
				if(callsAbaodoned==null||callsAbaodoned.equals("")){
					tableDetails.add(DashboardConstants.SPACE);
				}else{
					tableDetails.add(callsAbaodoned);
				}
			}

		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	public List<CTITableDTO> loadCTITableCurrentMonthCreated(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.CURRENT_MONTH;
		String  type = DashboardConstants.TYPE_CREATED;

		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}



	public List<CTITableDTO> loadCTITablePreviousMonthCreated(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.PREVIOUS_MONTH;
		String  type = DashboardConstants.TYPE_CREATED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}




	public List<CTITableDTO> loadCTITableTodayCreated(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.TODAY;
		String  type = DashboardConstants.TYPE_CREATED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	public List<CTITableDTO> loadCTITableCurrentMonthResolved(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.CURRENT_MONTH;
		String  type = DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}



	public List<CTITableDTO> loadCTITablePreviousMonthResolved(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.PREVIOUS_MONTH;
		String  type = DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}



	public List<CTITableDTO> loadCTITableTodayResolved(String clientName) throws SQLException, NamingException {


		List<CTITableDTO> tableDetails = new ArrayList<CTITableDTO>(); 

		String  day = DashboardConstants.TODAY;
		String  type = DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_CTIs;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				CTITableDTO object = new CTITableDTO();
				object.setCatagory(resultSet.getString("Category"));
				object.setType(resultSet.getString("Type"));
				object.setItem(resultSet.getString("Item"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setCount(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}

	public List<IncidentDTO> loadIncidentActive(String clientName) throws SQLException, NamingException {


		List<IncidentDTO> tableDetails = new ArrayList<IncidentDTO>(); 

		String type=DashboardConstants.TYPE_ACTIVE; 
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_Incidents;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,"");
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				IncidentDTO object = new IncidentDTO();

				object.setAssignGroup(resultSet.getString("assigned_group"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setTotal(resultSet.getString("cnt"));
				object.setAvgAge(resultSet.getString("WI_AGE"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	public List<IncidentDTO> loadIncidentCurrentMonthResolved(String clientName) throws SQLException, NamingException {



		List<IncidentDTO> tableDetails = new ArrayList<IncidentDTO>(); 

		String  day = DashboardConstants.CURRENT_MONTH;
		String type=DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_Incidents;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				IncidentDTO object = new IncidentDTO();

				object.setAssignGroup(resultSet.getString("assigned_group"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setTotal(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	public List<IncidentDTO> loadIncidentPreviousMonthResolved(String clientName) throws SQLException, NamingException {



		List<IncidentDTO> tableDetails = new ArrayList<IncidentDTO>(); 

		String  day = DashboardConstants.PREVIOUS_MONTH;
		String type=DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_Incidents;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				IncidentDTO object = new IncidentDTO();

				object.setAssignGroup(resultSet.getString("assigned_group"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setTotal(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}



	public List<IncidentDTO> loadIncidentTodayResolved(String clientName) throws SQLException, NamingException {



		List<IncidentDTO> tableDetails = new ArrayList<IncidentDTO>(); 

		String  day = DashboardConstants.TODAY;
		String type=DashboardConstants.TYPE_RESOLVED;
		String query = "";

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_Get_Top5_Incidents;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,clientName);
			callableStatement.setString(2,day);
			callableStatement.setString(3,type);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				IncidentDTO object = new IncidentDTO();

				object.setAssignGroup(resultSet.getString("assigned_group"));
				object.setUrgent(resultSet.getString("Urgent"));
				object.setHigh(resultSet.getString("High"));
				object.setMedium(resultSet.getString("Medium"));
				object.setStandard(resultSet.getString("Standard"));
				object.setTotal(resultSet.getString("cnt"));
				tableDetails.add(object);
			}

		}
		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tableDetails;
	}


	public List<ProblemTicketDetail> top5CTIProblemTicketDetails(String selectOption, String month, String tabletype,String category, String type, String item, String headerInfo) throws SQLException {

		String query="";
		List<ProblemTicketDetail> tableDetails=new ArrayList<ProblemTicketDetail>();
		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_Get_CTIs_PT_List;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,selectOption);
			callableStatement.setString(2,month);
			callableStatement.setString(3,tabletype);
			callableStatement.setString(4,category);
			callableStatement.setString(5,type);
			callableStatement.setString(6,item);
			callableStatement.setString(7,headerInfo);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				ProblemTicketDetail object = new ProblemTicketDetail();
				object.setAssignedGroup(resultSet.getString("ASSIGNED GROUP"));
				object.setAssignee(resultSet.getString("ASSIGNEE"));
				object.setCategory(resultSet.getString("CATEGORY"));
				object.setCreatedDate(resultSet.getString("CREATED DATE"));
				object.setItem(resultSet.getString("ITEM"));
				object.setPriority(resultSet.getString("PRIORITY"));
				String resolvedDate = resultSet.getString("RESOLVED DATE");
				if(resolvedDate==null||"".equals(resolvedDate)){
					object.setResolvedDate("-");
				}else{
					object.setResolvedDate(resolvedDate);
				}

				object.setStatus(resultSet.getString("STATUS"));
				object.setSummary(resultSet.getString("SUMMARY"));
				object.setTicket(resultSet.getString("TICKET"));
				object.setType(resultSet.getString("TYPE"));

				tableDetails.add(object);
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tableDetails;
	}


	public List<ProblemTicketDetail> incidentProblemTicket(String selectOption,String incidenttype, String selectmon, String headerInfo,String assignedGroup) throws SQLException {
		String query="";
		List<ProblemTicketDetail> tableDetails=new ArrayList<ProblemTicketDetail>();
		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_Get_Incidents_PT_List;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,selectOption);
			callableStatement.setString(2,selectmon);
			callableStatement.setString(3,incidenttype);
			callableStatement.setString(4,assignedGroup);
			callableStatement.setString(5,headerInfo);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				ProblemTicketDetail object = new ProblemTicketDetail();
				object.setAssignedGroup(resultSet.getString("ASSIGNED GROUP"));
				object.setAssignee(resultSet.getString("ASSIGNEE"));
				object.setCategory(resultSet.getString("CATEGORY"));
				object.setCreatedDate(resultSet.getString("CREATED DATE"));
				object.setItem(resultSet.getString("ITEM"));
				object.setPriority(resultSet.getString("PRIORITY"));
				String resolvedDate = resultSet.getString("RESOLVED DATE");
				if(resolvedDate==null||"".equals(resolvedDate)){
					object.setResolvedDate("-");
				}else{
					object.setResolvedDate(resolvedDate);
				}

				object.setStatus(resultSet.getString("STATUS"));
				object.setSummary(resultSet.getString("SUMMARY"));
				object.setTicket(resultSet.getString("TICKET"));
				object.setType(resultSet.getString("TYPE"));

				tableDetails.add(object);
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tableDetails;
	}
}
