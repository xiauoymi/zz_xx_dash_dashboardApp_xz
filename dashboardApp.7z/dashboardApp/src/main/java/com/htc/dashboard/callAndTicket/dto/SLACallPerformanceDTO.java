package com.htc.dashboard.callAndTicket.dto;

import java.util.ArrayList;
import java.util.List;

public class SLACallPerformanceDTO {
	List<String> callsAbandonedPct =new ArrayList<>();
	List<String> firstLevelResolution =new ArrayList<>();
	List<String> avgSpeedToAnswer =new ArrayList<>();
	List<String> dsa =new ArrayList<>();
	
	public List<String> getDsa() {
		return dsa;
	}
	public void setDsa(List<String> dsa) {
		this.dsa = dsa;
	}
	public List<String> getCallsAbandonedPct() {
		return callsAbandonedPct;
	}
	public void setCallsAbandonedPct(List<String> callsAbandonedPct) {
		this.callsAbandonedPct = callsAbandonedPct;
	}
	public List<String> getFirstLevelResolution() {
		return firstLevelResolution;
	}
	public void setFirstLevelResolution(List<String> firstLevelResolution) {
		this.firstLevelResolution = firstLevelResolution;
	}
	public List<String> getAvgSpeedToAnswer() {
		return avgSpeedToAnswer;
	}
	public void setAvgSpeedToAnswer(List<String> avgSpeedToAnswer) {
		this.avgSpeedToAnswer = avgSpeedToAnswer;
	}


}
