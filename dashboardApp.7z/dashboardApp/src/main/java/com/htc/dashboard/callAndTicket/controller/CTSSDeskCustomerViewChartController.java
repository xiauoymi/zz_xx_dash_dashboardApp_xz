package com.htc.dashboard.callAndTicket.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.dashboard.callAndTicket.dao.CTSSCustomerViewChartDAO;
import com.htc.utility.ApplicationUtilities;

/*
 * HTC_Offshore
 * purpose: return  CTSSDeskCustomerView ChartRelated DataSet
 * */ 

@Controller
public class CTSSDeskCustomerViewChartController {

	@Autowired
	private CTSSCustomerViewChartDAO ctssCutomerChartDAO;

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/callsummaryChart", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	List getPulseAlert(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		String month="";
		String CTSSClientName="";
		String CallSummary=request.getParameter("CallSummary");
		String type=request.getParameter("type");
		List chartData = null;
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
				CTSSClientName=(String)session.getAttribute("CTSSClintName");
				month = ApplicationUtilities.currentMonth_year();
				try {
					chartData = ctssCutomerChartDAO.CTSSCustomerViewChart(CTSSClientName,month,CallSummary,type);
				} catch (SQLException e) {
					throw new Exception(e.getMessage());
				}
		}
		return chartData;
	}
}
