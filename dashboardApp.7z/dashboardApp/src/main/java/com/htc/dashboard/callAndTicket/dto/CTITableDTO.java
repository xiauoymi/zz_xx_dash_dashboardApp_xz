package com.htc.dashboard.callAndTicket.dto;

public class CTITableDTO {
	String catagory ="";
	String type="";
	String item="";
	String urgent="";
	String high="";
	String medium="";
	String standard="";
	String count="";

	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getUrgent() {
		return urgent;
	}
	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getMedium() {
		return medium;
	}
	public void setMedium(String medium) {
		this.medium = medium;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}

	@Override
	public String toString() {
		return "CTITableDTO [catagory=" + catagory + ", type=" + type
				+ ", item=" + item + ", urgent=" + urgent + ", high=" + high
				+ ", medium=" + medium + ", standard=" + standard + ", count="
				+ count + "]";
	}



}
