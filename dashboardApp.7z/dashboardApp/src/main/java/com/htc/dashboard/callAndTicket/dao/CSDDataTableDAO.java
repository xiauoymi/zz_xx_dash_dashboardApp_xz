package com.htc.dashboard.callAndTicket.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.htc.dashboard.callAndTicket.dto.DashboardHomeDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

@Repository
public class CSDDataTableDAO {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Map<String, List<?>> csdDataTableCall(
			DashboardHomeDTO dashBoardHomeDTO) throws SQLException,
			NamingException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;

		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<String> reportDescriptionList = new ArrayList<String>();
		Map<String, List<?>> csdDataTableMap = new HashMap<String, List<?>>();
		Object[] values = null;

		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_SDDateTable;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, dashBoardHomeDTO.getMonth());
			resultSet = callableStatement.executeQuery();

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else {
						values[i - 1] = resultSet.getObject(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			csdDataTableMap.put(DashboardConstants.COMBINEDSDDT, reportList);
			csdDataTableMap.put(DashboardConstants.COMBINEDSDDTABLECOLUMNS,
					reportDescriptionList);
		}

		finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return csdDataTableMap;
	}

	public Map<String, List<?>> csdDataTableByAppIdCall(
			DashboardHomeDTO dashBoardHomeDTO) throws SQLException,
			NamingException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;

		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<String> reportDescriptionList = new ArrayList<String>();
		Map<String, List<?>> csdDataTableMap = new HashMap<String, List<?>>();
		Object[] values = null;

		try {
			connection = dataSource.getConnection();

			query = StoredProcedureConstants.sp_SDDateTable_by_AppID;
			callableStatement = connection.prepareCall(query);

			callableStatement.setString(1, dashBoardHomeDTO.getMonth());

			resultSet = callableStatement.executeQuery();

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else {
						values[i - 1] = resultSet.getObject(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			csdDataTableMap.put(DashboardConstants.COMBINEDSDDT, reportList);
			csdDataTableMap.put(DashboardConstants.COMBINEDSDDTABLECOLUMNS,
					reportDescriptionList);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csdDataTableMap;
	}
}
