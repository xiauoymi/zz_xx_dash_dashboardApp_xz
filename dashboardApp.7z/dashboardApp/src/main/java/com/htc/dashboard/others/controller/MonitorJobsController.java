package com.htc.dashboard.others.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.htc.dashboard.others.dao.MonitorEtlJobsDAO;

@Controller
public class MonitorJobsController {

	@Autowired
	private MonitorEtlJobsDAO monitorDao;

	@RequestMapping(value = "/Monitor", method = RequestMethod.POST)
	public String monitorHref(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {
		String jobValidationFlag = request.getParameter("jobMonitor");
		if (jobValidationFlag == null) {
			jobValidationFlag = "SDM1";
		}
		Map<String, List<?>> map = null;
		try {
			map = monitorDao.monitorJobs(jobValidationFlag);
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		}

		request.setAttribute("etlMonitor", map);
		request.setAttribute("validation",
				jobValidationFlag.substring(0, jobValidationFlag.length() - 1));
		return "dashboardApp/others/MonitorEtlJobs";

	}

	@RequestMapping(value = "/Monitor2", method = RequestMethod.POST)
	public String monitorHref2(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {
		String jobValidationFlag = request.getParameter("jobMonitor");
		Map<String, List<?>> map = null;
		if (jobValidationFlag == null) {
			jobValidationFlag = "SDM2";
		}
		try {
			map = monitorDao.monitorJobs(jobValidationFlag);
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		request.setAttribute("etlMonitor", map);
		request.setAttribute("validation",
				jobValidationFlag.substring(0, jobValidationFlag.length() - 1));
		return "dashboardApp/others/Monitor2";
	}

	@RequestMapping(value = "/MonitorAjaxrefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> monitorJobs(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		String jobValidationFlag = request.getParameter("jobMonitor");
		Map<String, List<?>> map = null;
		try {
			map = monitorDao.monitorJobs(jobValidationFlag);
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}
}
