package com.htc.dashboard.agent.dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.utility.StoredProcedureConstants;



public class CSDAgentDisplayBoardDAO {

	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	DataSource dataSourceRemedy;

	public void setDataSourceRemedy(DataSource marqueHistoryRecentRemedy) {
		this.dataSourceRemedy = marqueHistoryRecentRemedy;
	}

	public Map<String, List<?>> csdDisplayLeftStoreProcedure( LoginDetailDTO loginDTO) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Top;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, loginDTO.getUserName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if (null == getColumnVal) {
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}



			csClientMap.put("columnname",
					reportDescriptionList);
			csClientMap.put("columnvalues", reportList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}
	
	



	public Map<String, List<?>> csdDisplayMiddletStoreProcedure( LoginDetailDTO loginDTO) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Bottom;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,  loginDTO.getUserName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if (null == getColumnVal) {
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}



			csClientMap.put("columnname",
					reportDescriptionList);
			csClientMap.put("columnvalues", reportList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}

	public Map<String, List<?>> csdDisplayRightStoreProcedure() throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Side;
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if (null == getColumnVal) {
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}



			csClientMap.put("columnname",
					reportDescriptionList);
			csClientMap.put("columnvalues", reportList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}

	public Map<String, List<?>> csdDisplayMarqueeProcedure() throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		try {
			connection = dataSourceRemedy.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Historical;
			callableStatement = connection.prepareCall(query);
			callableStatement.setInt(1, 18000);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				String getColumnVal = resultSet
						.getString("symonmsg");
				reportList.add(getColumnVal);
			}

			csClientMap.put("columnvalues", reportList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}

	public Map<String, List<?>> csdDisplayRecentMarqueeProcedure() throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<String> reportList = new ArrayList<String>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		try {
			connection = dataSourceRemedy.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Recent;
			callableStatement = connection.prepareCall(query);
			callableStatement.setInt(1, 180);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				String getColumnVal = resultSet
						.getString("symonmsg");
				reportList.add(getColumnVal);
			}

			csClientMap.put("columnvalues", reportList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}
	
	public Map<String, List<?>> csdDisplayUpperMiddletStoreProcedure(String username) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> csClientMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_Caretech_Service_Desk_Agent_Display_Board_Middle;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, username);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if (null == getColumnVal) {
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}

			csClientMap.put("columnname",
					reportDescriptionList);
			csClientMap.put("columnvalues", reportList);

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return csClientMap;
	}

}
