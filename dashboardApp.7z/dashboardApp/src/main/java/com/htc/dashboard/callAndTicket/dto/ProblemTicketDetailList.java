package com.htc.dashboard.callAndTicket.dto;

import java.util.ArrayList;
import java.util.List;

public class ProblemTicketDetailList {
	List<ProblemTicketDetail> objectList=new ArrayList<ProblemTicketDetail>();

	public List<ProblemTicketDetail> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<ProblemTicketDetail> objectList) {
		this.objectList = objectList;
	}


}
