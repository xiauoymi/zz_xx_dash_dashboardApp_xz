package com.htc.dashboard.callAndTicket.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.htc.utility.StoredProcedureConstants;

public class CTSSCustomerViewChartDAO {

	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List CTSSCustomerViewChart(String CTSSClientName,String month,String CallSummary,String type) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Float> reportList = new ArrayList();

		List<String> reportDescriptionList = new ArrayList<String>();
		List cellList = new ArrayList<>();
		List ctssChart=new ArrayList<>() ;
		try {
			connection = dataSource.getConnection();

			if(type.equals("SLAP"))
				query =StoredProcedureConstants.sp_CustomerView_SLAPerformance_Chart;
			else
				query =StoredProcedureConstants.sp_CustomerView_CallSummary_Chart;

			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, CTSSClientName);
			callableStatement.setString(2, month);
			callableStatement.setString(3, CallSummary);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				cellList.add(resultSet.getString(reportDescriptionList.get(0)));

				reportList.add(resultSet.getFloat(reportDescriptionList.get(1)));

			}
			ctssChart.add(reportList);
			ctssChart.add(cellList);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ctssChart;
	}
	
	
}	