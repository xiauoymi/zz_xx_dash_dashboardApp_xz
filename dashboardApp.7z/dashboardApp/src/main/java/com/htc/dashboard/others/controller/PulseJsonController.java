package com.htc.dashboard.others.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.others.dao.PulseEmailAlertDAO;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  PulseEmailAlertByAll & PulseEmailAlertByClient  Ajax DataSet
 * */

@Controller
public class PulseJsonController {

	@Autowired
	private PulseEmailAlertDAO pulseAllEmailAlertdao;

	@RequestMapping(value = "/cityGridView", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getPulseAlert(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String yymm = "";
		if (session.getAttribute("yymm") != null) {
			yymm = (String) session.getAttribute("yymm");
		}
		try {
			map = pulseAllEmailAlertdao.pulseTicketEmailAlertAll(yymm);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}

		return map;
	}

	@RequestMapping(value = "/Day", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getPulseAllDay(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		String yymmdd = "";
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		if (session.getAttribute(DashboardConstants.pulseYear) != null) {
			yymmdd = (String) session
					.getAttribute(DashboardConstants.pulseYear);
			try {
				map = pulseAllEmailAlertdao.pulseTicketEmailAlertDay(yymmdd);
			} catch (SQLException | NamingException e) {
				throw new Exception(e.getMessage());
			}
		}
		return map;
	}

	@RequestMapping(value = "/ByClient", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getPulseAllByClient(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		String yymmdd = "";
		String client = (String) session
				.getAttribute(DashboardConstants.ClientName);
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		if (session.getAttribute(DashboardConstants.datePicker) != null) {
			yymmdd = (String) session
					.getAttribute(DashboardConstants.datePicker);
			try {
				map = pulseAllEmailAlertdao.pulseAllByClient(yymmdd, client);
			} catch (SQLException | NamingException e) {
				throw new Exception(e.getMessage());
			}
		}
		return map;
	}

	@RequestMapping(value = "/PABCEmailAlerts", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, List<?>> getPABCEmailAlert(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year;
		year = (String) session.getAttribute(DashboardConstants.datePicker);
		remedyId = (String) session.getAttribute(DashboardConstants.ClientName);
		try {
			map = pulseAllEmailAlertdao.emailAlert(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@RequestMapping(value = "/EmailAlerts", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, List<?>> getEmailAlert(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year;
		year = (String) session.getAttribute(DashboardConstants.pulseYear);
		remedyId = (String) session.getAttribute("remedyid");
		try {
			map = pulseAllEmailAlertdao.emailAlert(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@RequestMapping(value = "/PABCExternalAssigned", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getPABCCTSANDEmail(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year;
		year = (String) session.getAttribute(DashboardConstants.datePicker);
		remedyId = (String) session.getAttribute(DashboardConstants.ClientName);
		try {
			map = pulseAllEmailAlertdao.ctsAndExternalAssigned(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@RequestMapping(value = "/ExternalAssigned", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, List<?>> CTSANDEmail(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year;
		year = (String) session.getAttribute(DashboardConstants.pulseYear);
		remedyId = (String) session.getAttribute("remedyid");
		try {
			map = pulseAllEmailAlertdao.ctsAndExternalAssigned(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@RequestMapping(value = "/PABCCTSAssigned", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getPABCExternalAssigned(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year = null;
		year = (String) session.getAttribute(DashboardConstants.datePicker);
		remedyId = (String) session.getAttribute(DashboardConstants.ClientName);
		try {
			map = pulseAllEmailAlertdao.ctsAndExternalAssigned(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@RequestMapping(value = "/CTSAssigned", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getExternalAssigned(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String remedyId = null;
		String year = null;
		year = (String) session.getAttribute(DashboardConstants.pulseYear);
		remedyId = (String) session.getAttribute("remedyid");
		try {
			map = pulseAllEmailAlertdao.ctsAndExternalAssigned(year, remedyId);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/Monthly Chart", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getProvisionDisplayBoardMonthly(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String value = null;
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		loginDTO.setGroupList((List<Integer>) session
				.getAttribute(DashboardConstants.GROUP_IDS));
		value = (String) request.getParameter("value");
		try {
			map = pulseAllEmailAlertdao
					.provisionDisplayBoardMonthAndDate(value);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/Weekly Chart", method = RequestMethod.POST, consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public @ResponseBody
	Map<String, List<?>> getProvisionDisplayBoardWeekly(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		String value = null;
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		loginDTO.setGroupList((List<Integer>) session
				.getAttribute(DashboardConstants.GROUP_IDS));
		value = (String) request.getParameter("value");
		try {
			map = pulseAllEmailAlertdao
					.provisionDisplayBoardMonthAndDate(value);
		} catch (SQLException | NamingException e) {
			throw new Exception(e.getMessage());
		}
		return map;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/Today Chart", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> getProvisionDisplayBoardToDay(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		loginDTO.setGroupList((List<Integer>) session
				.getAttribute(DashboardConstants.GROUP_IDS));
		try {
			map = pulseAllEmailAlertdao.provisionDisplayBoardDay();
		} catch (SQLException | NamingException e) {

			throw new Exception(e.getMessage());
		}
		return map;
	}
}
