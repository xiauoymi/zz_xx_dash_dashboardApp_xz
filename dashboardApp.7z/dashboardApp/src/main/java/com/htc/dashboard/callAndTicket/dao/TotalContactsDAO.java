package com.htc.dashboard.callAndTicket.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.naming.NamingException;

import org.springframework.stereotype.Repository;

import com.htc.dashboard.callAndTicket.dto.TotalContactsDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

@Repository
public class TotalContactsDAO {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Map<String, List<?>> totalContactsTableCall(TotalContactsDTO ldto,
			String queryFlag) throws SQLException, NamingException {

		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<String> reportDescriptionList = new ArrayList<String>();
		Map<String, List<?>> totalContactsTableMap = new HashMap<String, List<?>>();
		Object[] values = null;

		try {
			connection = dataSource.getConnection();
			if ("TCTabble".equals(queryFlag)) {
				query = StoredProcedureConstants.TotalContacts;
			} else if ("TCByAppClient".equals(queryFlag)) {
				query = StoredProcedureConstants.TotalContactsBYApplicationClient;
			} else if ("TCYearly".equals(queryFlag)) {
				query = StoredProcedureConstants.TotalContacts_Yearly;
			} else {
			}

			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, ldto.getMonth());
			resultSet = callableStatement.executeQuery();

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else {
						values[i - 1] = resultSet.getObject(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			totalContactsTableMap.put(DashboardConstants.COMBINEDSDDT,
					reportList);
			totalContactsTableMap.put(
					DashboardConstants.COMBINEDSDDTABLECOLUMNS,
					reportDescriptionList);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return totalContactsTableMap;
	}
}
