package com.htc.dashboard.callAndTicket.controller;

/*
 * HTC_Offshore
 * purpose: return  TotalContactsTable  DataSet
 * */
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.callAndTicket.dao.TotalContactsDAO;
import com.htc.dashboard.callAndTicket.dto.TotalContactsDTO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;

@Controller
public class TotalContactsTableController {

	private static final Logger logger = Logger.getLogger(TotalContactsTableController.class);
	@Autowired
	private TotalContactsDAO totalContactDAO;


	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/totalContactsTable", method = RequestMethod.POST)
	public String getTotalContactsTable(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {

		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String queryFlag = "TCTabble";
			String today = "";
			Map<String, List<?>> totalContactsTableMap = null;
			TotalContactsDTO totalContactsDTO = new TotalContactsDTO();
			String month = request.getParameter("options");
			String validationFlag = request.getParameter("validationflag");
			if(validationFlag==null)
				validationFlag="20";
			session.setAttribute("validationFlag", validationFlag);
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			if (null == month) {
				month = ApplicationUtilities.month_year(today);
			}
			totalContactsDTO.setMonth(month);
			try {
				logger.info("Procedure info Month"+totalContactsDTO.getMonth()+"Validation flg"+queryFlag);
				totalContactsTableMap = totalContactDAO.totalContactsTableCall(totalContactsDTO, queryFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			session.setAttribute("datePicker", month);
			if (null != totalContactsTableMap && !totalContactsTableMap.isEmpty()) {
				model.addAttribute(DashboardConstants.COMBINEDSDDTMAP, totalContactsTableMap);
			}
			return "dashboardApp/callAndTicket/TotalContactsTable";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/totalContactsByAppClient", method = RequestMethod.POST)
	public String getTotalContactsByAppClient(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String queryFlag = "TCByAppClient";
			String today = "";
			Map<String, List<?>> totalContactsTableMap = null;
			TotalContactsDTO totalContactsDTO = new TotalContactsDTO();
			String validationFlag = request.getParameter("validationflag");
			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			if (null == month) {
				month = ApplicationUtilities.month_year(today);
			}
			totalContactsDTO.setMonth(month);
			try {
				logger.info("Procedure info Month"+totalContactsDTO.getMonth()+"Validation flg"+queryFlag);
				totalContactsTableMap = totalContactDAO.totalContactsTableCall(totalContactsDTO, queryFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			session.setAttribute("datePicker", month);
			if (null != totalContactsTableMap && !totalContactsTableMap.isEmpty()) {
				model.addAttribute(DashboardConstants.COMBINEDSDDTMAP, totalContactsTableMap);
			}
			return "dashboardApp/callAndTicket/TotalContactsTable";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/totalContactsYearly", method = RequestMethod.POST)
	public String getTotalContactsYearly(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String queryFlag = "TCYearly";
			String today = "";
			Map<String, List<?>> totalContactsTableMap = null;
			TotalContactsDTO totalContactsDTO = new TotalContactsDTO();
			String validationFlag = request.getParameter("validationflag");
			session.setAttribute("validationFlag", validationFlag);
			String year = request.getParameter("options");
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			if (null == year) {
				year = ApplicationUtilities.month_year(today).substring(0, 4);
			}
			totalContactsDTO.setMonth(year);
			try {
				logger.info("Procedure info Month"+totalContactsDTO.getMonth()+"Validation flg"+queryFlag);
				totalContactsTableMap = totalContactDAO.totalContactsTableCall(totalContactsDTO, queryFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			session.setAttribute("datePicker", year);
			if (null != totalContactsTableMap && !totalContactsTableMap.isEmpty()) {
				model.addAttribute(DashboardConstants.COMBINEDSDDTMAP, totalContactsTableMap);
			}
			return "dashboardApp/callAndTicket/TotalContactsTable";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
}
