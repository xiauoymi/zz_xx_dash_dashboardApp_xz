package com.htc.dashboard.callAndTicket.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.callAndTicket.dao.CTSSCustomerViewDAO;
import com.htc.dashboard.callAndTicket.dto.DashboardHomeDTO;
import com.htc.dashboard.callAndTicket.dto.CTITableDTO;
import com.htc.dashboard.callAndTicket.dto.CTITableDTOTransferable;
import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;
import com.htc.dashboard.callAndTicket.dto.IncidentDTO;
import com.htc.dashboard.callAndTicket.dto.IncidentTransferable;
import com.htc.dashboard.callAndTicket.dto.ProblemTicketDetail;
import com.htc.dashboard.callAndTicket.dto.ProblemTicketDetailList;
import com.htc.dashboard.callAndTicket.dto.ProblemTicketRequestTypeDTO;
import com.htc.dashboard.callAndTicket.dto.SLACallPerformanceDTO;
import com.htc.dashboard.callAndTicket.dto.SLACallSummaryDTO;

/*
 * HTC_Offshore
 * purpose: return  CTSSDeskCustomerview DataSet
 * */

@Controller
public class CTSSDeskCustomerview {

	private static final Logger logger = Logger.getLogger(CSDDataTableController.class);
	@Autowired
	private CTSSCustomerViewDAO ctssCutomerDAO;


	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ctsServiceDeskCustomerView", method = RequestMethod.POST)
	public String getCTSSCustomerView(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String groupList="";
			List<List<String>> ctssCustomerTreeList = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			QueryBuilder querybuilder =new QueryBuilder();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			try {
				groupList=querybuilder.dashboardCTSSGroupData(loginDTO);
				ctssCustomerTreeList=ctssCutomerDAO.ctssCustomerViewTreeSelect(groupList);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			model.addAttribute(DashboardConstants.CTSSDCUSTOMER_VIEW_TREE_SELECT,ctssCustomerTreeList);
			return "dashboardApp/callAndTicket/CTSSDeskCustomerView";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/loadSLACallPerformanceTable", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadSLACallPerformanceTable(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			String client = (String)request.getParameter("clientname");

			session.setAttribute("CTSSClintName", client);
			List<String> callsAbandonedPct =new ArrayList<>();
			List<String> firstLevelResolution =new ArrayList<>();
			List<String> avgSpeedToAnswer =new ArrayList<>();
			List<String> dsa =new ArrayList<>();

			List<String> ctssCustomerTreeListToday = null;
			List<String> ctssCustomerTreeListCurrentMonth = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);
			SLACallPerformanceDTO object=new SLACallPerformanceDTO();

			try {
				ctssCustomerTreeListToday=ctssCutomerDAO.ctssCustomerViewCallSLAPerformanceToday(client);
				ctssCustomerTreeListCurrentMonth=ctssCutomerDAO.ctssCustomerViewCallSLAPerformanceCurrentMonth(client);

				if(ctssCustomerTreeListToday.size()==0){
					for(int i=0;i<ctssCustomerTreeListCurrentMonth.size();i++){
						ctssCustomerTreeListToday.add(DashboardConstants.SPACE);
					}
				}
				if(ctssCustomerTreeListCurrentMonth.size()==0){
					for(int i=0;i<ctssCustomerTreeListToday.size();i++){
						ctssCustomerTreeListCurrentMonth.add(DashboardConstants.SPACE);
					}
				}

				for(int i=0;i<ctssCustomerTreeListCurrentMonth.size();i++){
					if(i==0){
						callsAbandonedPct.add(ctssCustomerTreeListToday.get(i));
						callsAbandonedPct.add(ctssCustomerTreeListCurrentMonth.get(i));
					}
					if(i==1){
						firstLevelResolution.add(ctssCustomerTreeListToday.get(i));
						firstLevelResolution.add(ctssCustomerTreeListCurrentMonth.get(i));
					}
					if(i==2){
						avgSpeedToAnswer.add(ctssCustomerTreeListToday.get(i));
						avgSpeedToAnswer.add(ctssCustomerTreeListCurrentMonth.get(i));
					}
					if(i==3){
						dsa.add(ctssCustomerTreeListToday.get(i));
						dsa.add(ctssCustomerTreeListCurrentMonth.get(i));
					}
				}


				object.setCallsAbandonedPct(callsAbandonedPct);
				object.setFirstLevelResolution(firstLevelResolution);
				object.setAvgSpeedToAnswer(avgSpeedToAnswer);
				object.setDsa(dsa);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/loaCallSummary", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCallSummary(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			List<String> callsAbandonedList =new ArrayList<>();
			List<String> callsOfferedList =new ArrayList<>();
			List<String> avgTalkTimeList =new ArrayList<>();
			List<String> callsAnsweredList =new ArrayList<>();



			List<String> callSummaryListToday = null;
			List<String> callSummaryListCurrentMonth = null;

			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);
			SLACallSummaryDTO object=new SLACallSummaryDTO();

			try {
				callSummaryListToday=ctssCutomerDAO.ctssCallSummaryToday(client);
				callSummaryListCurrentMonth=ctssCutomerDAO.ctssCallSummaryCurrentMonth(client);


				if(callSummaryListToday.size()==0){
					for(int i=0;i<callSummaryListCurrentMonth.size();i++){
						callSummaryListToday.add(DashboardConstants.SPACE);
					}
				}
				if(callSummaryListCurrentMonth.size()==0){
					for(int i=0;i<callSummaryListToday.size();i++){
						callSummaryListCurrentMonth.add(DashboardConstants.SPACE);
					}
				}


				for(int i=0;i<callSummaryListToday.size();i++){
					if(i==0){
						callsOfferedList.add(callSummaryListToday.get(i));
						callsOfferedList.add(callSummaryListCurrentMonth.get(i));

					}
					if(i==1){
						callsAnsweredList.add(callSummaryListToday.get(i));
						callsAnsweredList.add(callSummaryListCurrentMonth.get(i));
					}
					if(i==2){
						avgTalkTimeList.add(callSummaryListToday.get(i));
						avgTalkTimeList.add(callSummaryListCurrentMonth.get(i));
					}
					if(i==3){
						callsAbandonedList.add(callSummaryListToday.get(i));
						callsAbandonedList.add(callSummaryListCurrentMonth.get(i));
					}
				}

				object.setCallsAbandoned(callsAbandonedList);
				object.setCallsOffered(callsOfferedList);
				object.setAvgTalkTimeList(avgTalkTimeList);
				object.setCallsAnswered(callsAnsweredList);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}



	@RequestMapping(value = "/loadCTITableCurrentMonthCreated", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITableCurrentMonthCreated(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITableCurrentMonthCreated(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/loadCTITablePreviousMonthCreated", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITablePreviousMonthCreated(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITablePreviousMonthCreated(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/loadCTITableTodayCreated", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITableTodayCreated(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITableTodayCreated(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/loadCTITableCurrentMonthResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITableCurrentMonthResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITableCurrentMonthResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/loadCTITablePreviousMonthResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITablePreviousMonthResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITablePreviousMonthResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
	@RequestMapping(value = "/loadCTITableTodayResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadCTITableTodayResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			CTITableDTOTransferable object=new CTITableDTOTransferable();
			List<CTITableDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadCTITableTodayResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}



	@RequestMapping(value = "/loadIncidentActive", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadIncidentActive(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			IncidentTransferable object=new IncidentTransferable();
			List<IncidentDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadIncidentActive(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/loadIncidentCurrentMonthResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadIncidentCurrentMonthResolvedResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			IncidentTransferable object=new IncidentTransferable();
			List<IncidentDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadIncidentCurrentMonthResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/loadIncidentPreviousMonthResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadIncidentPreviousMonthResolvedResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			IncidentTransferable object=new IncidentTransferable();
			List<IncidentDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadIncidentPreviousMonthResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/loadIncidentTodayResolved", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public String loadIncidentTodayResolvedResolved(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String client = (String)request.getParameter("clientname");

			IncidentTransferable object=new IncidentTransferable();
			List<IncidentDTO> tableDetail=null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.loadIncidentTodayResolved(client);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			String obj = new Gson().toJson(object);
			return obj;
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/top5CTIProblemTicketDetails", method = RequestMethod.POST )
	public String top5CTIProblemTicketDetails(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		String userName = (String) session.getAttribute("username");
		String jsonObj="";
		if(userName != null && !("".equals(userName))){
			String selectOption = (String)request.getParameter("selectOption");
			String tabletype = (String)request.getParameter("tabletype");
			String month = (String)request.getParameter("month");
			String headerInfo = (String)request.getParameter("headerInfo");
			String category  = (String)request.getParameter("category");
			String type  = (String)request.getParameter("type");
			String item  = (String)request.getParameter("item");


			selectOption = selectOption.toUpperCase();
			month = month.toUpperCase();
			tabletype = tabletype.toUpperCase();
			category  = category.toUpperCase();
			type  = type.toUpperCase();
			item  = item.toUpperCase();
			headerInfo = headerInfo.toUpperCase();


			ProblemTicketRequestTypeDTO objectType=new ProblemTicketRequestTypeDTO();
			objectType.setClientName(selectOption);
			objectType.setPriority(headerInfo);
			objectType.setCategory(category);
			objectType.setType(type);
			objectType.setItem(item);
			objectType.setCreatedMonth(month);
			objectType.setCtiType(DashboardConstants.YES);



			ProblemTicketDetailList object=new ProblemTicketDetailList();
			List<ProblemTicketDetail> tableDetail = new ArrayList<ProblemTicketDetail>();
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.top5CTIProblemTicketDetails(selectOption,month,tabletype,category,type,item,headerInfo);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}

			jsonObj=new Gson().toJson(object).toString();
			String reqTypeObj = new Gson().toJson(objectType).toString();
			model.addAttribute("requestType",reqTypeObj);
			model.addAttribute("resultData",jsonObj);
			return "dashboardApp/callAndTicket/ProblemTicket";
		}else{
			return "common/UnAuthoriseAccess";
		}

	}


	@RequestMapping(value = "/incidentProblemTicket", method = RequestMethod.POST )
	public String incidentProblemTicket(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		String userName = (String) session.getAttribute("username");
		String jsonObj ="";
		if(userName != null && !("".equals(userName))){
			String selectOption = (String)request.getParameter("selectOption");
			String incidenttype = (String)request.getParameter("incidenttype");
			String selectmon = (String)request.getParameter("selectmon");
			String headerInfo = (String)request.getParameter("headerInfo");
			String assignedGroup  = (String)request.getParameter("assignedGroup");


			selectOption = selectOption.toUpperCase();
			incidenttype = incidenttype.toUpperCase();
			if(selectmon.equals("")||selectmon==null){
				selectmon = "";
			}else{
				selectmon = selectmon.toUpperCase();
			}

			headerInfo  = headerInfo.toUpperCase();
			assignedGroup  = assignedGroup.toUpperCase(); 




			ProblemTicketRequestTypeDTO objectType=new ProblemTicketRequestTypeDTO();
			objectType.setClientName(selectOption);
			objectType.setAssignedGroup(assignedGroup);
			objectType.setStatus(incidenttype);
			objectType.setPriority(headerInfo);
			objectType.setCtiType(DashboardConstants.NO);



			ProblemTicketDetailList object=new ProblemTicketDetailList();
			List<ProblemTicketDetail> tableDetail = new ArrayList<ProblemTicketDetail>();
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			dashBoardHomeDTO.setClientName(userName);

			try {

				tableDetail = ctssCutomerDAO.incidentProblemTicket(selectOption,incidenttype,selectmon,headerInfo,assignedGroup);
				object.setObjectList(tableDetail);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}
			jsonObj=new Gson().toJson(object).toString();
			String reqTypeObj = new Gson().toJson(objectType).toString();
			model.addAttribute("requestType",reqTypeObj);
			model.addAttribute("resultData",jsonObj);
			return "dashboardApp/callAndTicket/ProblemTicket";
		}else{
			return "common/UnAuthoriseAccess";
		}

	}

}
