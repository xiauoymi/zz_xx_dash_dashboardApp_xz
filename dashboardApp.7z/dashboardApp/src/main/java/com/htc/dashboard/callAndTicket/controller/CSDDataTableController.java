package com.htc.dashboard.callAndTicket.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.dashboard.callAndTicket.dao.CSDDataTableDAO;
import com.htc.dashboard.callAndTicket.dto.DashboardHomeDTO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  CSDDataTable DataSet
 * */  

@Controller
public class CSDDataTableController {

	private static final Logger logger = Logger.getLogger(CSDDataTableController.class);
	@Autowired
	private CSDDataTableDAO dashBoardDAO;

	@RequestMapping(value = "/cssDataTable", method = RequestMethod.POST)
	public String getCssDatatable(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {


		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			Map<String, List<?>> csdDataTableMap = null;
			String today = "";
			String month = (String) request.getParameter("options");
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			if (null == month) {
				month = ApplicationUtilities.month_year(today);
			}
			dashBoardHomeDTO.setMonth(month);
			try {
				csdDataTableMap = dashBoardDAO.csdDataTableCall(dashBoardHomeDTO);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}

			session.setAttribute("datePicker", month);
			model.addAttribute(DashboardConstants.COMBINEDSDDTMAP, csdDataTableMap);
			return "dashboardApp/callAndTicket/CombinedServiceDeskDT";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/csdDatatableByAppId", method = RequestMethod.POST)
	public String getCSDDatatableByAppId(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			String today = "";
			Map<String, List<?>> csdDataTableMap = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			session = request.getSession();
			String month = (String) request.getParameter("options");
			if (month == null) {
				month = ApplicationUtilities.month_year(today);
			}
			dashBoardHomeDTO.setMonth(month);
			try {
				logger.info("Procudre Parameter  Month"+dashBoardHomeDTO.getMonth());
				csdDataTableMap = dashBoardDAO.csdDataTableByAppIdCall(dashBoardHomeDTO);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			model.addAttribute(DashboardConstants.COMBINEDSDDTMAP, csdDataTableMap);
			session.setAttribute("datePicker", month);
			return "dashboardApp/callAndTicket/CombinedServiceDeskDTByAppID";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
}
