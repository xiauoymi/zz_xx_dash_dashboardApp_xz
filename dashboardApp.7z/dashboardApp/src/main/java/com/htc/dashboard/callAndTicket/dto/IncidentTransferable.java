package com.htc.dashboard.callAndTicket.dto;

import java.util.ArrayList;
import java.util.List;

public class IncidentTransferable {

	List<IncidentDTO> objectList = new ArrayList<>();

	public List<IncidentDTO> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<IncidentDTO> objectList) {
		this.objectList = objectList;
	}




}
