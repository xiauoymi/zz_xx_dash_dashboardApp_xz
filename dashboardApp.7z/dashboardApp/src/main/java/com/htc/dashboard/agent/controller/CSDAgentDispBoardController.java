package com.htc.dashboard.agent.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.agent.dao.CSDAgentDisplayBoardDAO;
/*
 * HTC_Offshore
 * purpose: return  CSDAgentDispBoard DataSet
 * */
@Controller
public class CSDAgentDispBoardController {

	private static final Logger logger = Logger
			.getLogger(CSDAgentDispBoardController.class);

	@Autowired
	private CSDAgentDisplayBoardDAO csAgentDisplayDAO;

	@Autowired
	private CSDAgentDisplayBoardDAO marqueHistoryRecentRemedy;


	@RequestMapping(value = "/csdAgentDisplayBoard", method = RequestMethod.POST)
	public String getAgentDeskDisplay(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayLeftTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMiddleTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayUpperMiddleTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayRightTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMarque=new HashMap<String, List<?>>();
		Map<String,  Map<String, List<?>>> csDisplayTable=new HashMap<String,  Map<String, List<?>>>();
		Map<String, List<?>> csDisplayRecentMarque=new HashMap<String, List<?>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			loginDTO.setUserName(userName);
			try {
				csDisplayLeftTable=csAgentDisplayDAO.csdDisplayLeftStoreProcedure(loginDTO);
				logger.info("csDisplayLeftTable---"+csDisplayLeftTable);
				csDisplayMiddleTable=csAgentDisplayDAO.csdDisplayMiddletStoreProcedure(loginDTO);
				logger.info("csDisplayMiddleTable---"+csDisplayMiddleTable);
				//upper middle table
				csDisplayUpperMiddleTable=csAgentDisplayDAO.csdDisplayUpperMiddletStoreProcedure(userName);
				logger.info("csDisplayupperMiddleTable---"+csDisplayUpperMiddleTable);
				csDisplayRightTable=csAgentDisplayDAO.csdDisplayRightStoreProcedure();
				logger.info("csDisplayRightTable---"+csDisplayRightTable);
				csDisplayMarque=marqueHistoryRecentRemedy.csdDisplayMarqueeProcedure();
				logger.info("csDisplayMarque---"+csDisplayMarque);
				csDisplayRecentMarque=marqueHistoryRecentRemedy.csdDisplayRecentMarqueeProcedure();
				logger.info("csDisplayRecentMarque---"+csDisplayRecentMarque);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			csDisplayTable.put("csDisplayLeftTable", csDisplayLeftTable);
			csDisplayTable.put("csDisplayMiddleTable", csDisplayMiddleTable);
			csDisplayTable.put("csDisplayUpperMiddleTable", csDisplayUpperMiddleTable);
			csDisplayTable.put("csDisplayRightTable", csDisplayRightTable);
			csDisplayTable.put("csDisplayMarque", csDisplayMarque);
			csDisplayTable.put("csDisplayRecentMarque", csDisplayRecentMarque);
			request.setAttribute("csDisplayTable", csDisplayTable);
			return "dashboardApp/agent/CSD_Agent_Display_Board";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/topTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getTop(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayLeftTable=new HashMap<String, List<?>>();
		Map<String,  Map<String, List<?>>> csDisplayTable=new HashMap<String,  Map<String, List<?>>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		loginDTO.setUserName(userName);
		try {
			csDisplayLeftTable=csAgentDisplayDAO.csdDisplayLeftStoreProcedure(loginDTO);
			logger.info("csDisplayLeftTable---"+csDisplayLeftTable);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayLeftTable", csDisplayLeftTable);
		return csDisplayTable;
	}


	@RequestMapping(value = "/rightTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getSide(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayRightTable=new HashMap<String, List<?>>();
		Map<String,  Map<String, List<?>>> csDisplayTable=new HashMap<String,  Map<String, List<?>>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		loginDTO.setUserName(userName);
		try {
			csDisplayRightTable=csAgentDisplayDAO.csdDisplayRightStoreProcedure();
			logger.info("csDisplayRightTable---"+csDisplayRightTable);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayRightTable", csDisplayRightTable);
		return csDisplayTable;
	}

	@RequestMapping(value = "/middleTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getMiddle(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayMiddleTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMarque=new HashMap<String, List<?>>();
		Map<String,  Map<String, List<?>>> csDisplayTable=new HashMap<String,  Map<String, List<?>>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		loginDTO.setUserName(userName);
		try {
			csDisplayMiddleTable=csAgentDisplayDAO.csdDisplayMiddletStoreProcedure(loginDTO);
			logger.info("csDisplayMiddleTable---"+csDisplayMiddleTable);
			csDisplayMarque=marqueHistoryRecentRemedy.csdDisplayMarqueeProcedure();
			logger.info("csDisplayMarque---"+csDisplayMarque);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayMiddleTable", csDisplayMiddleTable);
		csDisplayTable.put("csDisplayMarque", csDisplayMarque);
		return csDisplayTable;
	}


	@RequestMapping(value = "/recentMarqueAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getRecentMarque(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String,  Map<String, List<?>>> csDisplayTable=new HashMap<String,  Map<String, List<?>>>();
		Map<String, List<?>> csDisplayRecentMarque=new HashMap<String, List<?>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		loginDTO.setUserName(userName);
		try {
			csDisplayRecentMarque=marqueHistoryRecentRemedy.csdDisplayRecentMarqueeProcedure();
			logger.info("csDisplayRecentMarque---"+csDisplayRecentMarque);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayRecentMarque", csDisplayRecentMarque);
		return csDisplayTable;
	}
	
	@RequestMapping(value = "/UpperMiddleTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getUpperMiddleTableAutoRefresh(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> upperMiddleTableAutoRefresh=new HashMap<String, List<?>>();
		Map<String,  Map<String, List<?>>> upperMiddleTableAutoRefreshMap=new HashMap<String,  Map<String, List<?>>>();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		String userName = (String) session.getAttribute("username");
		loginDTO.setUserName(userName);
		try {
			upperMiddleTableAutoRefresh=csAgentDisplayDAO.csdDisplayUpperMiddletStoreProcedure(userName);
			logger.info("upperMiddleTable---"+upperMiddleTableAutoRefresh);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		upperMiddleTableAutoRefreshMap.put("upperMiddleTable", upperMiddleTableAutoRefresh);
		return upperMiddleTableAutoRefreshMap;
	}

}
