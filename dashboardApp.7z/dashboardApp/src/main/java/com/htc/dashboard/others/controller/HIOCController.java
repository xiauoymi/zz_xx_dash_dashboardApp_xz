package com.htc.dashboard.others.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.dashboard.others.dao.HIOC_Table_DAO;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  HIOC  DataSet
 * */

@Controller
public class HIOCController {

	private static final Logger logger = Logger.getLogger(HIOCController.class);

	@Autowired
	private HIOC_Table_DAO hiocDao;

	@RequestMapping(value = "/hiocTable", method = RequestMethod.POST)
	public String getMTDPerQueue(ModelMap model, HttpServletRequest request,
			HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> hiocTableMap = null;
			try {
				hiocTableMap = hiocDao.hiocRecentActTableCall();
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			model.addAttribute(DashboardConstants.HIOCTMAP, hiocTableMap);
			return "dashboardApp/others/HIOCRecentActivityTable";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/hiocTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> getTop(ModelMap model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		Map<String, List<?>> hiocTableMap = null;
		try {
			hiocTableMap = hiocDao.hiocRecentActTableCall();
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		model.addAttribute(DashboardConstants.HIOCTMAP, hiocTableMap);
		return hiocTableMap;
	}

}