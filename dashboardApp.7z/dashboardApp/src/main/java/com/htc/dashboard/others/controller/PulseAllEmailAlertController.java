package com.htc.dashboard.others.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.others.dao.PulseEmailAlertDAO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;


/*
 * HTC_Offshore
 * purpose: return  PulseEmailAlertByAll & PulseEmailAlertByClient  DataSet
 * */

@Controller
public class PulseAllEmailAlertController {

	@Autowired
	private PulseEmailAlertDAO pulseAlertDAO;



	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/pulseall", method = RequestMethod.POST)
	public String getPulseAllEmailAlert(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws SQLException, NamingException,
			IOException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
		if(userName != null && !("".equals(userName))){
			String year = request.getParameter("options");
				if (null == year) {
					year = ApplicationUtilities.mtdMonthYear();
				}
				session.setAttribute(DashboardConstants.datePicker, year);

			return "dashboardApp/others/PulseAll";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/DayController", method = RequestMethod.POST, produces = "application/json")
	public String getPulseAllDay(ModelMap model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response) throws UnsupportedEncodingException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		if(userName != null && !("".equals(userName))){

			String yymmdd = "";
			if (session.getAttribute(DashboardConstants.datePicker) != null) {
				yymmdd = (String) session.getAttribute(DashboardConstants.datePicker);
				yymmdd = yymmdd.substring(0, yymmdd.length() - 2)
						+ request.getParameter("date");
				session.setAttribute(DashboardConstants.pulseYear, yymmdd);
			}
			return "dashboardApp/others/PulseAllDay";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/PABCEmailClient", method = RequestMethod.POST)
	public String getPSBCEmailClient(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws SQLException, NamingException,
			IOException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		String yymmdd = "";
		if(userName != null && !("".equals(userName))){
			if (session.getAttribute(DashboardConstants.datePicker) != null) {
				yymmdd = (String) session.getAttribute(DashboardConstants.datePicker);
				yymmdd = yymmdd.substring(0, yymmdd.length() - 2)
						+ request.getParameter("date");
				session.setAttribute(DashboardConstants.pulseYear, yymmdd);
			}

			return "dashboardApp/others/PABCSingleClient";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/EmailClient", method = RequestMethod.POST)
	public String getSingleClient(ModelMap model, HttpServletRequest request,
			HttpSession session, HttpServletResponse response)
					throws SQLException, NamingException, IOException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		if(userName != null && !("".equals(userName))){
			return "dashboardApp/others/SingleClient";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/provision", method = RequestMethod.POST)
	public String getProvisionDisplayBoard(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws SQLException, NamingException,
			IOException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		if(userName != null && !("".equals(userName))){
			return "dashboardApp/others/ProvisionDisplayBoard";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "static-access" })
	@RequestMapping(value = "/pulseAllByClient", method = RequestMethod.POST)
	public String getpulseAllByClient(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		if(userName != null && !("".equals(userName))){
			List clientGroupList = new ArrayList();
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			String year = request.getParameter("dateoption");

			String clientName = request.getParameter("clientname");
		
			if (null == clientName) {
				try {
					clientGroupList = pulseAlertDAO.getClientGroupList();

				} catch (Exception e) {
					throw new Exception(e.getMessage());
				}
				session.setAttribute(DashboardConstants.ClientName, clientGroupList.get(0));
			} else {
				session.setAttribute(DashboardConstants.ClientName, clientName);
			}

			if (null == year) {
				year = ApplicationUtilities.mtdMonthYear();
			}
			session.setAttribute(DashboardConstants.datePicker, year);
			return "dashboardApp/others/PulseAllByClient";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "static-access" })
	@RequestMapping(value = "/PulseAllToByClient", method = RequestMethod.POST)
	public String getPulseAllToByClient(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		if(userName != null && !("".equals(userName))){
			List clientGroupList = new ArrayList();
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			String year = request.getParameter("dateoption");
			String clientName = request.getParameter("clientname");
			if (null == clientName) {
				try {
					clientGroupList = pulseAlertDAO.getClientGroupList();
				} catch (Exception e) {
					throw new Exception(e.getMessage());
				}
				session.setAttribute(DashboardConstants.ClientName, clientGroupList.get(0));
			} else {
				session.setAttribute(DashboardConstants.ClientName, clientName);
			}

			if (null == year) {
				year = ApplicationUtilities.mtdMonthYear();
			}
			session.setAttribute(DashboardConstants.datePicker, year);
			return "dashboardApp/others/PulseAllToByClient";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ByCLientToPulseAll", method = RequestMethod.POST)
	public String getByClientToPulseAll(ModelMap model,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws SQLException, NamingException,
			IOException {
		String userName = (String) session.getAttribute(DashboardConstants.username);
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
		if(userName != null && !("".equals(userName))){
			String year = request.getParameter("options");
			if (null == year) {
				year = ApplicationUtilities.mtdMonthYear();
			}
			session.setAttribute(DashboardConstants.datePicker, year);
			return "dashboardApp/others/ByCLientToPulseAll";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
}
