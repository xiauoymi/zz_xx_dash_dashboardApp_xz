package com.htc.dashboard.agent.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.dashboard.agent.dto.AgentDeskDisplayDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

public class AgentDeskDisplayDAO {

	DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Map<String, List<?>> agentDeskDisplayTableCall(AgentDeskDisplayDTO agentDeskDisDTO)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> agentDeskDisplayTableMap = new LinkedHashMap<String, List<?>>();
		Object[] values = null;

		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_Agent_Desktop_Display;
			statement = connection.prepareCall(query);
			statement.setString(1, agentDeskDisDTO.getuserName());
			resultSet = statement.executeQuery();

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else {
						values[i - 1] = resultSet.getObject(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			agentDeskDisplayTableMap.put(
					DashboardConstants.AGENTDESKDESKTABLECOLNAME,
					reportDescriptionList);
			agentDeskDisplayTableMap.put(
					DashboardConstants.AGENTDESKDESKTABLECOLVAL, reportList);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return agentDeskDisplayTableMap;
	}



}
