package com.htc.dashboard.others.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

public class PulseEmailAlertDAO {

	static DataSource dataSource;

	@SuppressWarnings("static-access")
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Map<String, List<?>> pulseTicketEmailAlertAll(String var) throws SQLException, NamingException {

		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		String query = "";
		String dateQuery = "";

		List<Integer> pulseAllList0 = new ArrayList<Integer>();
		List<Integer> pulseAllList1 = new ArrayList<>();
		List<Integer> pulseAllList2 = new ArrayList<>();
		List<String> pulseAllList3  = new ArrayList<String>();
		Map<String, List<?>> map    = new HashMap<String, List<?>>();
		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_PulseCharts_All_ByID;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, var);
			psstatemet.setString(2, var);

			resultSet = psstatemet.executeQuery();


			while (resultSet.next()) {
				pulseAllList0.add(resultSet.getInt(DashboardConstants.PULSEALL_CTS_Assigned));
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_External_Assigned));
				pulseAllList2.add(resultSet.getInt(DashboardConstants.PULSEALL_EmailAlerts));
				if (null != resultSet.getString(DashboardConstants.PULSEALL_Create_Date)) {
					dateQuery = resultSet.getString(DashboardConstants.PULSEALL_Create_Date);
					dateQuery = dateQuery.replace(',', '-');
					pulseAllList3.add(dateQuery);
				}
			}

			map.put("a", pulseAllList0);
			map.put("b", pulseAllList1);
			map.put("c", pulseAllList2);
			map.put("d", pulseAllList3);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return map;
	}

	public Map<String, List<?>> pulseTicketEmailAlertDay(String var) throws SQLException, NamingException {
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		String query = "";
		String dateQuery = "";

		List<Integer> pulseAllList0 = new ArrayList<Integer>();
		List<Integer> pulseAllList1 = new ArrayList<Integer>();
		List<Integer> pulseAllList2 = new ArrayList<Integer>();
		List<String> pulseAllList3  = new ArrayList<String>();
		Map<String, List<?>> map    = new HashMap<String, List<?>>();

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_PulseCharts_AllbyClient_ByID;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, var);
			psstatemet.setString(2, var);
			resultSet = psstatemet.executeQuery();
			while (resultSet.next()) {

				pulseAllList0.add(resultSet.getInt(DashboardConstants.PULSEALL_CTS_Assigned));
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_External_Assigned));
				pulseAllList2.add(resultSet.getInt(DashboardConstants.PULSEALL_EmailAlerts));
				if (null != resultSet.getString(DashboardConstants.PULSEALL_RemedyID)) {
					dateQuery = resultSet.getString(DashboardConstants.PULSEALL_RemedyID);
					dateQuery = dateQuery.replace(',', '-');
					pulseAllList3.add(dateQuery);
				}
			}
			map.put("a", pulseAllList0);
			map.put("b", pulseAllList1);
			map.put("c", pulseAllList2);
			map.put("d", pulseAllList3);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return map;
	}
	public Map<String, List<?>> pulseAllByClient(String var, String client)
			throws SQLException, NamingException {

		String query = "";
		String dateQuery = "";
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		List<Integer> pulseAllList0 = new ArrayList<Integer>();
		List<Integer> pulseAllList1 = new ArrayList<Integer>();
		List<Integer> pulseAllList2 = new ArrayList<Integer>();
		List<String> pulseAllList3 = new ArrayList<String>();
		Map<String, List<?>> map = new HashMap<String, List<?>>();

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_PulseCharts_ByClient_ByID;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, var);
			psstatemet.setString(2, var);
			psstatemet.setString(3, client);
			resultSet = psstatemet.executeQuery();
			while (resultSet.next()) {

				pulseAllList0.add(resultSet.getInt(DashboardConstants.PULSEALL_CTS_Assigned));
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_External_Assigned));
				pulseAllList2.add(resultSet.getInt(DashboardConstants.PULSEALL_EmailAlerts));
				if (null != resultSet.getString(DashboardConstants.PULSEALL_Create_Date)) {
					dateQuery = resultSet.getString(DashboardConstants.PULSEALL_Create_Date);
					dateQuery = dateQuery.replace(',', '-');
					pulseAllList3.add(dateQuery);
				}
			}
			map.put("a", pulseAllList0);
			map.put("b", pulseAllList1);
			map.put("c", pulseAllList2);
			map.put("d", pulseAllList3);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return map;
	}	


	public Map<String, List<?>> emailAlert(String year, String remedyID)
			throws SQLException, NamingException {
		String query = "";
		String dateQuery = "";
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		List<Integer> pulseAllList1=new ArrayList<Integer>();
		List<String> pulseAllList3= new ArrayList<String>();
		Map<String,List<?>> map=new HashMap<String,List<?>>();

		try{
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_PulseCharts_ByName;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, year);
			psstatemet.setString(2, year);
			psstatemet.setString(3, remedyID);
			resultSet = psstatemet.executeQuery();
			while (resultSet.next()) {
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_EmailAlerts));

				if(null !=resultSet.getString(DashboardConstants.PULSEALL_RemedyID))
				{
					dateQuery=resultSet.getString(DashboardConstants.PULSEALL_RemedyID);
					dateQuery=dateQuery.replace(',','-');
					pulseAllList3.add(dateQuery);
				}
			}

			map.put("a", pulseAllList1);
			map.put("c", pulseAllList3);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return map;
	}


	public Map<String,List<?>> ctsAndExternalAssigned(String year,String var) throws SQLException,NamingException
	{
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		String query="";
		String dateQuery="";

		List<Integer> pulseAllList1=new ArrayList<>();
		List<Integer> pulseAllList2=new ArrayList<Integer>();
		List<String> pulseAllList3= new ArrayList<String>();
		Map<String,List<?>> map=new HashMap<String,List<?>>();

		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_PulseCharts_ByName;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, year);
			psstatemet.setString(2, year);
			psstatemet.setString(3, var);
			resultSet = psstatemet.executeQuery();

			while (resultSet.next()) {
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_CTS_Assigned));
				pulseAllList2.add(resultSet.getInt(DashboardConstants.PULSEALL_External_Assigned));
				if(null !=resultSet.getString(DashboardConstants.PULSEALL_RemedyID))
				{
					dateQuery=resultSet.getString(DashboardConstants.PULSEALL_RemedyID);
					dateQuery=dateQuery.replace(',','-');
					pulseAllList3.add(dateQuery);
				}
			}

			map.put("a", pulseAllList1);
			map.put("b", pulseAllList2);
			map.put("c", pulseAllList3);
		}
		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return map;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String,List<?>> provisionDisplayBoardDay() throws SQLException,NamingException
	{
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		String query="";
		String dateQuery="";
		String mntsHrs="";
		List pulseAllList1=new ArrayList<>();

		List<String> pulseAllList3= new ArrayList<String>();
		Map<String,List<?>> map=new HashMap<String,List<?>>();
		List<String> minutesHres=new ArrayList<>();

		try
		{
			connection= dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_CTS_Provisioning_Daily;
			psstatemet = connection.prepareStatement(query);
			resultSet = psstatemet.executeQuery();

			while (resultSet.next()) {
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_Minutes));

				mntsHrs=""+resultSet.getInt(DashboardConstants.PULSEALL_Minutes);
				mntsHrs+="("+resultSet.getFloat(DashboardConstants.PULSEALL_HOURS)+" hrs)";
				minutesHres.add(mntsHrs);
				
				if(null !=resultSet.getString(DashboardConstants.PULSEALL_Assigned_Individual))
				{
					dateQuery=resultSet.getString(DashboardConstants.PULSEALL_Assigned_Individual);
					dateQuery=dateQuery.replace(',','-');
					pulseAllList3.add(dateQuery);
				}
			}

			map.put("a", pulseAllList1);
			map.put("b", minutesHres);
			map.put("c", pulseAllList3);
		}
		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return map;
	}


	public Map<String,List<?>> provisionDisplayBoardMonthAndDate(String value) throws SQLException,NamingException
	{
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;
		String mntsHrs="";
		String query="";
		String dateQuery="";

		List<Integer> pulseAllList1=new ArrayList<>();
		List<String> minutesHres=new ArrayList<>();
		List<String> pulseAllList3= new ArrayList<String>();
		Map<String,List<?>> map=new HashMap<String,List<?>>();

		try
		{
			connection= dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_CTS_Provisioning_Weekly_Monthly;
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1, value);
			resultSet = psstatemet.executeQuery();

			while (resultSet.next()) {
				pulseAllList1.add(resultSet.getInt(DashboardConstants.PULSEALL_Minutes));

				mntsHrs=""+resultSet.getInt(DashboardConstants.PULSEALL_Minutes);
				mntsHrs+="("+resultSet.getFloat(DashboardConstants.PULSEALL_HOURS)+" hrs)";
				minutesHres.add(mntsHrs);
				if(null !=resultSet.getString(DashboardConstants.PULSEALL_Assigned_Individual))
				{
					dateQuery=resultSet.getString(DashboardConstants.PULSEALL_Assigned_Individual);
					dateQuery=dateQuery.replace(',','-');
					pulseAllList3.add(dateQuery);
				}
			}

			map.put("a", pulseAllList1);
			map.put("b", minutesHres);
			map.put("c", pulseAllList3);
		}
		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return map;
	}


	@SuppressWarnings("rawtypes")
	public static List getClientGroupList() throws SQLException,
	NamingException {
		Connection connection = null;
		PreparedStatement psstatemet = null;
		ResultSet resultSet = null;

		String query = "";
		List<String> clientList = new ArrayList<String>();
		Map<String, List<?>> clientmap = new HashMap<String, List<?>>();
		try {
			connection = dataSource.getConnection();
			query=StoredProcedureConstants.sp_get_Remedy_IDs;
			psstatemet = connection.prepareStatement(query);
			resultSet = psstatemet.executeQuery();

			while (resultSet.next()) {
				clientList.add(resultSet.getString("Optionvalue"));
			}
			clientmap.put("key", clientList);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return clientList;
	}

}
