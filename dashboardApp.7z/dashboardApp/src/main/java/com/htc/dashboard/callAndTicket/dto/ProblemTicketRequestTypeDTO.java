package com.htc.dashboard.callAndTicket.dto;

public class ProblemTicketRequestTypeDTO {
	public String clientName;
	public String priority;
	public String status;
	public String assignedGroup;
	public String createdMonth;
	public String category;
	public String type;
	public String item;
	public String ctiType;

	public String getCtiType() {
		return ctiType;
	}
	public void setCtiType(String ctiType) {
		this.ctiType = ctiType;
	}
	public String getCreatedMonth() {
		return createdMonth;
	}
	public void setCreatedMonth(String createdMonth) {
		this.createdMonth = createdMonth;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAssignedGroup() {
		return assignedGroup;
	}
	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

}
