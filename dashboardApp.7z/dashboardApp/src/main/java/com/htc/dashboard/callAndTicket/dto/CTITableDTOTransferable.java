package com.htc.dashboard.callAndTicket.dto;

import java.util.ArrayList;
import java.util.List;

public class CTITableDTOTransferable {

	List<CTITableDTO> objectList = new ArrayList<>();

	public List<CTITableDTO> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<CTITableDTO> objectList) {
		this.objectList = objectList;
	}


}
