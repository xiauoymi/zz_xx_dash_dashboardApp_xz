package com.htc.dashboard.callAndTicket.controller;

import java.sql.SQLException;
import java.util.Map;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.dashboard.callAndTicket.dao.MTDAllClientsDAO;
import com.htc.dashboard.callAndTicket.dto.DashboardHomeDTO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;

/*
 * HTC_Offshore
 * purpose: return  MTD  DataSet
 * */

@Controller
public class MTDController {

	private static final Logger logger = Logger.getLogger(MTDController.class);
	@Autowired
	private MTDAllClientsDAO mtdDao;



	@SuppressWarnings({ "unused", "unchecked", "static-access" })
	@RequestMapping(value = "/dailyPerClient", method = RequestMethod.POST)
	public String getDailyPerClient(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			Map<String, List<?>> dailyPerClientMap = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			String builder ="";
			String status="";
			String validationFlag = request.getParameter("validationflag");

			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			QueryBuilder querybuilder =new QueryBuilder();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			dashBoardHomeDTO.setClientName(userName);
			if (null == month) {
				month = ApplicationUtilities.mtdMonthYear();
			}
			session.setAttribute("datePicker", month);
			dashBoardHomeDTO.setMonth(month);
			try {
				builder=querybuilder.dashboardExecutiveGroupData(loginDTO);
				dashBoardHomeDTO.setGroup(builder);
				logger.info("Procedure info Month"+dashBoardHomeDTO.getMonth()+"Validation flg"+validationFlag);
				dailyPerClientMap = mtdDao.mtdAllClientsCall(dashBoardHomeDTO, validationFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			if (null != dailyPerClientMap && !dailyPerClientMap.isEmpty()) {
				model.addAttribute(DashboardConstants.MTDPQTMAP, dailyPerClientMap);
			}
			return "dashboardApp/callAndTicket/MTDAllClients";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	@RequestMapping(value = "/dailyPerQueue", method = RequestMethod.POST)
	public String getDailyPerQueue(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String builder ="";
			Map<String, List<?>> dailyPerQueueMap = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			String validationFlag = request.getParameter("validationflag");
			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			QueryBuilder querybuilder =new QueryBuilder();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			dashBoardHomeDTO.setClientName(userName);
			if (null == month) {
				month = ApplicationUtilities.mtdMonthYear();
			}

			session.setAttribute("datePicker", month);
			dashBoardHomeDTO.setMonth(month);

			try {
				builder=querybuilder.dashboardExecutiveGroupData(loginDTO);
				dashBoardHomeDTO.setGroup(builder);
				logger.info("Procedure info Month"+dashBoardHomeDTO.getMonth()+"Validation flg"+validationFlag);
				dailyPerQueueMap = mtdDao.mtdAllClientsCall(dashBoardHomeDTO, validationFlag);
			}
			catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			if (null != dailyPerQueueMap && !dailyPerQueueMap.isEmpty()) {
				model.addAttribute(DashboardConstants.MTDPQTMAP, dailyPerQueueMap);
			}
			return "dashboardApp/callAndTicket/MTDAllClients";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/mtdAllClients", method = RequestMethod.POST)
	public String getMTDAllClients(ModelMap model, HttpServletRequest request, HttpSession session) throws SQLException, NamingException {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			String validationFlag = request.getParameter("validationflag");
			validationFlag = null;
			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			@SuppressWarnings("unused")
			QueryBuilder querybuilder =new QueryBuilder();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));

			if (null == month) {
				month = ApplicationUtilities.mtdMonthYear();

			}
			session.setAttribute("datePicker", month);

			return "dashboardApp/callAndTicket/MTDAllClients";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	@RequestMapping(value = "/mtdPerClients", method = RequestMethod.POST)
	public String getMTDPerClients(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {

		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String builder ="";
			Map<String, List<?>> mtdPerClientsMap = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			String validationFlag = request.getParameter("validationflag");
			if(validationFlag==null){
				validationFlag="16";
			}
			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			dashBoardHomeDTO.setClientName(userName);
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			QueryBuilder querybuilder =new QueryBuilder();

			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			if (null == month) {
				month = ApplicationUtilities.mtdMonthYear();
			}

			session.setAttribute("datePicker", month);
			dashBoardHomeDTO.setMonth(month);

			try {
				builder=querybuilder.dashboardExecutiveGroupData(loginDTO);
				dashBoardHomeDTO.setGroup(builder);
				logger.info("Procedure info Month"+dashBoardHomeDTO.getMonth()+"Validation flg"+validationFlag);
				mtdPerClientsMap = mtdDao.mtdAllClientsCall(dashBoardHomeDTO, validationFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			if (null != mtdPerClientsMap && !mtdPerClientsMap.isEmpty()) {
				model.addAttribute(DashboardConstants.MTDPQTMAP, mtdPerClientsMap);
			}
			return "dashboardApp/callAndTicket/MTDAllClients";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	@RequestMapping(value = "/mtdPerQueue", method = RequestMethod.POST)
	public String getMTDPerQueue(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			String builder ="";
			Map<String, List<?>> mtdPerQueueMap = null;
			DashboardHomeDTO dashBoardHomeDTO = new DashboardHomeDTO();
			String validationFlag = request.getParameter("validationflag");
			session.setAttribute("validationFlag", validationFlag);
			String month = request.getParameter("options");
			dashBoardHomeDTO.setClientName(userName);
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			QueryBuilder querybuilder =new QueryBuilder();
			loginDTO.setGroupList((List<Integer>)session.getAttribute(DashboardConstants.GROUP_IDS));
			if (null == month) {
				month = ApplicationUtilities.mtdMonthYear();
			}
			session.setAttribute("datePicker", month);
			dashBoardHomeDTO.setMonth(month);

			try {
				builder=querybuilder.dashboardExecutiveGroupData(loginDTO);
				dashBoardHomeDTO.setGroup(builder);
				logger.info("Procedure info Month"+dashBoardHomeDTO.getMonth()+"Validation flg"+validationFlag);
				mtdPerQueueMap = mtdDao.mtdAllClientsCall(dashBoardHomeDTO, validationFlag);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			if (null != mtdPerQueueMap && !mtdPerQueueMap.isEmpty()) {
				model.addAttribute(DashboardConstants.MTDPQTMAP, mtdPerQueueMap);
			}
			return "dashboardApp/callAndTicket/MTDAllClients";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
}