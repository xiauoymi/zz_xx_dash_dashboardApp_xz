package com.htc.dashboard.callAndTicket.dto;

public class IncidentDTO {
	String assignGroup="";
	String urgent="";
	String high="";
	String medium="";
	String standard="";
	String total="";
	String avgAge="";
	public String getAssignGroup() {
		return assignGroup;
	}
	public void setAssignGroup(String assignGroup) {
		this.assignGroup = assignGroup;
	}
	public String getUrgent() {
		return urgent;
	}
	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getMedium() {
		return medium;
	}
	public void setMedium(String medium) {
		this.medium = medium;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getAvgAge() {
		return avgAge;
	}
	public void setAvgAge(String avgAge) {
		this.avgAge = avgAge;
	}





}
