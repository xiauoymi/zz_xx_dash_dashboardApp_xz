package com.htc.dashboard.others.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.dashboard.callAndTicket.controller.MTDController;
import com.htc.dashboard.others.dao.PRActivityTableDAO;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  PRActivityTable  DataSet
 * */

@Controller
public class PRActivityTableController {

	private static final Logger logger = Logger.getLogger(MTDController.class);
	@Autowired
	private PRActivityTableDAO prActivityTableDAO;

	@RequestMapping(value = "/prActivityTable", method = RequestMethod.POST)
	public String getPRActivityTable(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		String userName = (String) session.getAttribute("username");
		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> prActivityTablesMap = null;
			try {
				prActivityTablesMap = prActivityTableDAO.prActivityTableCall();
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			if (null != prActivityTablesMap && !prActivityTablesMap.isEmpty()) {
				model.addAttribute(DashboardConstants.COMBINEDSDDTMAP,
						prActivityTablesMap);
			}
			return "dashboardApp/others/PRActivityTable";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/prTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> getTop(ModelMap model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		Map<String, List<?>> prActivityTablesMap = null;
		try {
			prActivityTablesMap = prActivityTableDAO.prActivityTableCall();
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		if (null != prActivityTablesMap && !prActivityTablesMap.isEmpty()) {
			model.addAttribute(DashboardConstants.COMBINEDSDDTMAP,
					prActivityTablesMap);
		}
		return prActivityTablesMap;
	}

}
