package com.htc.dashboard.agent.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.dashboard.agent.dao.CSDAgentDisplayBoardDAO;
import com.htc.dashboard.agent.dao.CSDDisplayBoardControllerDAO;
/*
 * HTC_Offshore
 * purpose: return  CSDDisplayBoard DataSet
 * */
@Controller
public class CSDDisplayBoardController {

	private static final Logger logger = Logger
			.getLogger(CSDDisplayBoardController.class);

	@Autowired
	private CSDDisplayBoardControllerDAO csDisplayDAO;

	@Autowired
	private CSDAgentDisplayBoardDAO marqueHistoryRecentRemedy;

	@RequestMapping(value = "/csdDisplayBoard", method = RequestMethod.POST)
	public String getAgentDeskDisplay(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		Map<String, List<?>> csDisplayLeftTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMiddleTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayRightTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMarque=new HashMap<String, List<?>>();
		Map<String, Map<String, List<?>>> csDisplayTable=new HashMap<String, Map<String, List<?>>>();
		Map<String, List<?>> csDisplayRecentMarque=new HashMap<String, List<?>>();

		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){

			try {
				csDisplayLeftTable=csDisplayDAO.csdDisplayLeftStoreProcedure();
				logger.info("csDisplayLeftTable-------"+csDisplayLeftTable);
				csDisplayMiddleTable=csDisplayDAO.csdDisplayMiddletStoreProcedure();
				logger.info("csDisplayMiddleTable-------"+csDisplayMiddleTable);
				csDisplayRightTable=csDisplayDAO.csdDisplayRightStoreProcedure();
				csDisplayMarque=marqueHistoryRecentRemedy.csdDisplayMarqueeProcedure();
				csDisplayRecentMarque=marqueHistoryRecentRemedy.csdDisplayRecentMarqueeProcedure();
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			csDisplayTable.put("csDisplayLeftTable", csDisplayLeftTable);
			csDisplayTable.put("csDisplayMiddleTable", csDisplayMiddleTable);
			csDisplayTable.put("csDisplayRightTable", csDisplayRightTable);
			csDisplayTable.put("csDisplayMarque", csDisplayMarque);
			csDisplayTable.put("csDisplayRecentMarque", csDisplayRecentMarque);
			request.setAttribute("csDisplayTable", csDisplayTable);
			return "dashboardApp/agent/CSD_Display_Board";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}


	@RequestMapping(value = "/topAndMiddleAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> topAndMiddle(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayLeftTable=new HashMap<String, List<?>>();
		Map<String, List<?>> csDisplayMiddleTable=new HashMap<String, List<?>>();
		Map<String, Map<String, List<?>>> csDisplayTable=new HashMap<String, Map<String, List<?>>>();

		try {
			csDisplayLeftTable=csDisplayDAO.csdDisplayLeftStoreProcedure();
			logger.info("csDisplayLeftTable-------"+csDisplayLeftTable);
			csDisplayMiddleTable=csDisplayDAO.csdDisplayMiddletStoreProcedure();
			logger.info("csDisplayMiddleTable-------"+csDisplayMiddleTable);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayLeftTable", csDisplayLeftTable);
		csDisplayTable.put("csDisplayMiddleTable", csDisplayMiddleTable);
		return csDisplayTable;
	}



	@RequestMapping(value = "/sideTableAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> side(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayRightTable=new HashMap<String, List<?>>();
		Map<String, Map<String, List<?>>> csDisplayTable=new HashMap<String, Map<String, List<?>>>();

		try {
			csDisplayRightTable=csDisplayDAO.csdDisplayRightStoreProcedure();
			logger.info("csDisplayRightTable-------"+csDisplayRightTable);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayRightTable", csDisplayRightTable);
		return csDisplayTable;
	}

	@RequestMapping(value = "/agentRecentMarqueAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getRecentMarque(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, Map<String, List<?>>> csDisplayTable=new HashMap<String, Map<String, List<?>>>();
		Map<String, List<?>> csDisplayRecentMarque=new HashMap<String, List<?>>();

		try {
			csDisplayRecentMarque=marqueHistoryRecentRemedy.csdDisplayRecentMarqueeProcedure();
			logger.info("csDisplayRecentMarque-------"+csDisplayRecentMarque);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayRecentMarque", csDisplayRecentMarque);
		return csDisplayTable;
	}

	@RequestMapping(value = "/agentHistoryMarqueAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, Map<String, List<?>>> getHistoryMarque(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		Map<String, List<?>> csDisplayMarque=new HashMap<String, List<?>>();
		Map<String, Map<String, List<?>>> csDisplayTable=new HashMap<String, Map<String, List<?>>>();

		try {
			csDisplayMarque=marqueHistoryRecentRemedy.csdDisplayMarqueeProcedure();
			logger.info("csDisplayMarque-------"+csDisplayMarque);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		csDisplayTable.put("csDisplayMarque", csDisplayMarque);
		return csDisplayTable;
	}



}
