package com.htc.dashboard.agent.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.dashboard.agent.dao.SDCallDisplayDAO;
import com.htc.utility.DashboardConstants;


/*
 * HTC_Offshore
 * purpose: return  SDCallDisplay DataSet
 * */
@Controller
public class SDCallDisplayController{


	private static final Logger logger = Logger.getLogger(SDCallDisplayController.class);

	@Autowired
	private SDCallDisplayDAO sdCallDisplayDAO;

	@RequestMapping(value = "/sdCallDisplay", method = RequestMethod.POST)
	public String getSDCallDisplay(ModelMap model, HttpServletRequest request,HttpSession session) throws Exception {

		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			Map<String, List<?>> sdCallDispalyMap=null;
			try{
				sdCallDispalyMap=sdCallDisplayDAO.sdCallDisplayTableCall();
			}catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			model.addAttribute(DashboardConstants.SDCALLDISPLAYMAP, sdCallDispalyMap);
			return "dashboardApp/agent/SDCallDisplay";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
}
