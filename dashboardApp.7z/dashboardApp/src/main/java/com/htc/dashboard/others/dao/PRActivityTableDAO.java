package com.htc.dashboard.others.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.naming.NamingException;

import org.springframework.stereotype.Repository;

import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;

@Repository
public class PRActivityTableDAO {

	private DataSource dataSource;

	public void setDataSourceRemedy(DataSource dataSourceRemedy) {
		this.dataSource = dataSourceRemedy;
	}

	public Map<String, List<?>> prActivityTableCall() throws SQLException,
			NamingException, ParseException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<String> reportDescriptionList = new ArrayList<String>();
		Map<String, List<?>> prActivityTableMap = new HashMap<String, List<?>>();
		Object[] values = null;

		try {

			connection = dataSource.getConnection();
			query = QueryBuilder.getPRATableQuery();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(query);

			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else if ("Date_Time_Created"
							.equalsIgnoreCase(resultSetMetaData
									.getColumnName(i))) {
						String _24HourTime = resultSet.getObject(i).toString();
						SimpleDateFormat _24HourSDF = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");
						SimpleDateFormat _12HourSDF = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss aa");
						Date _24HourDt = _24HourSDF.parse(_24HourTime);
						values[i - 1] = _12HourSDF.format(_24HourDt);
					} else {
						values[i - 1] = resultSet.getObject(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			prActivityTableMap.put(DashboardConstants.COMBINEDSDDTABLECOLUMNS,
					reportDescriptionList);
			prActivityTableMap.put(DashboardConstants.COMBINEDSDDT, reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return prActivityTableMap;
	}
}
