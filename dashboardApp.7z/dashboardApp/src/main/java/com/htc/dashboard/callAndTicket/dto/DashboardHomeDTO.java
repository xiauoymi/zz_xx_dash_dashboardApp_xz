package com.htc.dashboard.callAndTicket.dto;

import java.util.List;

public class DashboardHomeDTO {

	private String clientName;
	private String month;
	private String group;
	private List<Integer> groupList;



	public List<Integer> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<Integer> groupList) {
		this.groupList = groupList;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}


}
