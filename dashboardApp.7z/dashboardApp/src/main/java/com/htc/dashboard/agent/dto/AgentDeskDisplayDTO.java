package com.htc.dashboard.agent.dto;

public class AgentDeskDisplayDTO {
	
	private String userName;

	public String getuserName() {
		return userName;
	}

	public void setuserName(String userName) {
		this.userName = userName;
	}
}






