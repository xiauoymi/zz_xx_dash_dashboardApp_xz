package com.htc.LMSTimesheetAndAdjustMent.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

public class LMSTimsheetAdjustmentDAO {

	DataSource dataSourceLMS;
	private static final Logger logger = Logger.getLogger(LMSTimsheetAdjustmentDAO.class);
	public void setDataSourceLMS(DataSource dataSourceLMS) {
		this.dataSourceLMS = dataSourceLMS;
	}

	public StringBuilder timsheetTree(String FilterType)
			throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMetricsTreequery = "";
		StringBuilder builder = new StringBuilder();
		try {
			List<String> reportDescriptionList = new ArrayList<String>();
			connection = dataSourceLMS.getConnection();
			sdMetricsTreequery = StoredProcedureConstants.getAgentsByMgrID ;
			callableStatement = connection.prepareCall(sdMetricsTreequery);
			callableStatement.setString(1, FilterType);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				builder.append("{id:'" + resultSet.getString(1) + "',parent:'");
				if (resultSet.getString(2).equalsIgnoreCase("0")) {
					builder.append("#',text:");
				} else
					builder.append(resultSet.getString(2) + "',text:");
				String SDM_org_lbl = resultSet.getString(3).replace("\n", " ");
				SDM_org_lbl = SDM_org_lbl.replace("'", "");
				builder.append("'" + SDM_org_lbl + "',types:");
				builder.append("'" + resultSet.getString(4) + "',");
				builder.append(" },");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder;
	}


	public Map<String, List<?>> getAgentDiscrapancy(String date,String agentId) throws SQLException,
	NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getAgentActivities;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, date);
			callableStatement.setString(2, agentId);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.AGENTTIMESHEETCOLUMNNAME,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.AGENTTIMESHEETVALUES,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return leaveHistoryMap;
	}

	public Map<String, List<?>> getAgentActivity(String date,String agentId,String agentActivity) throws SQLException,
	NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String agentActivityQuery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> agentShiftDataMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			if(agentActivity.equalsIgnoreCase(DashboardConstants.AgentShiftData)){
				agentActivityQuery = StoredProcedureConstants.generateAgentShiftData;
			}else if(agentActivity.equalsIgnoreCase(DashboardConstants.AgentAvayaActivities)){
				agentActivityQuery = StoredProcedureConstants.AgentAvayaActivities;
			}else if(agentActivity.equalsIgnoreCase(DashboardConstants.AgentLoginActivities)){
				agentActivityQuery = StoredProcedureConstants.AgentLoginStats ;
			}else if(agentActivity.equalsIgnoreCase(DashboardConstants.AgentScheduleActivities)){
				/* schedule procedure write here */
				agentActivityQuery = StoredProcedureConstants.getAgentScheduleForTimesheet;
			}


			callableStatement = connection.prepareCall(agentActivityQuery);
			callableStatement.setString(1, agentId);
			callableStatement.setString(2, date);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			agentShiftDataMap.put(DashboardConstants.AGENTACTIVITYCOLUMNNAME,
					reportDescriptionList);
			agentShiftDataMap.put(DashboardConstants.AGENTACTIVTYVALUES,
					reportList);

		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}  finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return agentShiftDataMap;
	}

	public List<String> modalAdjust(int tran_id,String activity_Name,String eligitime,String staus,String comment,String userName) throws SQLException,
	NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<String> resultMsg = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.AgentActivityModification;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setInt(1, tran_id);
			callableStatement.setString(2, activity_Name);
			callableStatement.setString(3, eligitime);
			callableStatement.setString(4, staus);
			callableStatement.setString(5, comment);
			callableStatement.setString(6, userName);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg .add(resultSet.getString(1));
				resultMsg .add(resultSet.getString(2));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}


	public Map<String, List<?>> getLoginStats (String date,String id) throws SQLException,
	NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getLoginStats ;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, date);
			callableStatement.setString(2, id);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.AGENTLOGINSTATCOLUMNNAME,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.AGENTLOGINSTATCOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return leaveHistoryMap;
	}

	public Map<String, List<?>> getAgentModifiedActivities (String agentId) throws SQLException,
	NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getAgentModifiedActivities;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, agentId);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				cellList.add("");
				cellList.add("");
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.AGENTMODIFIEDCOLUMNNAME,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.AGENTMODIFIEDCOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return leaveHistoryMap;
	}

	public List<String> getTimsheetMailAddress (int tran_id,String activity_Name,String eligitime,String staus) throws SQLException,
	NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String getMailAddressQuery = "";
		List<String> getMailAddress = new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			getMailAddressQuery = StoredProcedureConstants.getEmailAddressForTimesheet;
			callableStatement = connection.prepareCall(getMailAddressQuery);
			callableStatement.setInt(1, tran_id);
			callableStatement.setString(2, activity_Name);
			callableStatement.setString(3, eligitime);
			callableStatement.setString(4, staus);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				getMailAddress.add(resultSet.getString("Agnt_Act_Stat_ID"));
				getMailAddress.add(resultSet.getString("From_Mail_address"));
				getMailAddress.add(resultSet.getString("To_Mail_address"));
				getMailAddress.add(resultSet.getString("Email_subject"));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return getMailAddress;
	}

	public String updateTimsheeetMailStatus(String tran_id,String staus) throws SQLException, NamingException {


		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String leaveHistoryequery = "";
		String resultMsg="";
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.setEmailStatusTimesheet ;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, tran_id);
			callableStatement.setString(2, staus);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg=resultSet.getString(1);				
			}		

		}catch(Exception exception){
			logger.error(exception.getMessage(), exception);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> getDateForTimesheet() throws SQLException,
	NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String leaveHistoryequery = "";
		List<String> dateList = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getDateForTimesheet;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				dateList .add(resultSet.getString(1));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dateList;
	}
	public List<String> getPeoplesoftCode() throws SQLException,
	NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String leaveHistoryequery = "";
		List<String> getPeoplesoftCode = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getPeoplesoftCode;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				getPeoplesoftCode .add(resultSet.getString(1));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return getPeoplesoftCode;
	}


	/**
	 * @param agentId, date
	 * @return Return Map of Payroll record which needs to send to People Soft
	 * @throws SQLException
	 * @throws NamingException
	 * @throws ParseException
	 */
	public Map<String, List<?>> generatePSoftData(String agentId,String date) throws NamingException, ParseException {

		logger.info("Inside generatePSoftData(String agentId,String date)");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();			
			leaveHistoryequery = StoredProcedureConstants.generatePSoftData;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, agentId);			
			callableStatement.setString(2, date);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.psoftColumnNames,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.psoftColumnValues,
					reportList);

		}catch(SQLException sqlException){
			logger.error(sqlException.getMessage(),sqlException);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
		}
		logger.info("Exit generatePSoftData(String agentId,String date)");
		return leaveHistoryMap;
	}

	/**
	 *
	 * @param agentId
	 * @param date
	 * @param psCode
	 * @param totalhrs
	 * @return Update Status 
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String updatePeopleSoftStatus(String agentId, String date, String psCode, String totalhrs, String bupForPSList, String prjForPSList, String actForPSList) throws SQLException, NamingException {

		logger.info("Inside updatePeopleSoftStatus()");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String updatePSStatusquery = "";
		String resultMsg="";
		try {
			connection = dataSourceLMS.getConnection();			
			updatePSStatusquery = StoredProcedureConstants.PEOPLE_SOFT_DATA_PUSH_TRACK ;
			callableStatement = connection.prepareCall(updatePSStatusquery);
			callableStatement.setString(1, agentId);
			callableStatement.setString(2, date);
			callableStatement.setString(3, psCode);
			callableStatement.setString(4, totalhrs);
			callableStatement.setString(5, bupForPSList);
			callableStatement.setString(6, prjForPSList);
			callableStatement.setString(7, actForPSList);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg=resultSet.getString(1);				
			}
		}catch(Exception exception){
			logger.error(exception.getMessage(), exception);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("Exit updatePeopleSoftStatus()");
		return resultMsg;
	}

	/**
	 *
	 * @param agentId
	 * @param date
	 * @param psCode
	 * @param totalhrs
	 * @return Update Status 
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String insertIntoPeopleSoftTempTbl(String seq, String agentId, String date, String psCode, String totalhrs, String bupForPSList, String prjForPSList, String actForPSList) throws SQLException, NamingException {

		logger.info("Inside insertIntoPeopleSoftTempTbl()");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String updatePSStatusquery = "";
		String resultMsg="";
		try {
			connection = dataSourceLMS.getConnection();			
			updatePSStatusquery = StoredProcedureConstants.PEOPLE_SOFT_DATA_PUSH_TO_TEMP_TBL ;
			callableStatement = connection.prepareCall(updatePSStatusquery);
			callableStatement.setString(1, seq);
			callableStatement.setString(2, agentId);
			callableStatement.setString(3, date);
			callableStatement.setString(4, psCode);
			callableStatement.setString(5, totalhrs);
			callableStatement.setString(6, bupForPSList);
			callableStatement.setString(7, prjForPSList);
			callableStatement.setString(8, actForPSList);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg=resultSet.getString(1);				
			}
		}catch(Exception exception){
			logger.error(exception.getMessage(), exception);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("Exit insertIntoPeopleSoftTempTbl()");
		return resultMsg;
	}
	
	
	/**
	 * @param agentId
	 * @param date
	 * @return Submit to People soft button status (True/False)
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String checkSubmitToPSButtonStatus(String agentId, String date) throws NamingException {
		logger.info("Inside checkSubmitToPSButtonStatus(String agentId, String date)");

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String updatePSStatusquery = "";
		String resultMsg="";
		try {
			connection = dataSourceLMS.getConnection();			
			updatePSStatusquery = StoredProcedureConstants.PS_PUSH_BUTTON_ENABLE_CHECK ;
			callableStatement = connection.prepareCall(updatePSStatusquery);
			callableStatement.setString(1, agentId);
			callableStatement.setString(2, date);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg=resultSet.getString(1);				
			}

		}catch(SQLException sqlException){
			logger.error(sqlException.getMessage(), sqlException);
		}catch(Exception exception){
			logger.error(exception.getMessage(), exception);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("Exit checkSubmitToPSButtonStatus(String agentId, String date)");
		return resultMsg;
	}
}
