package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.Admin.dao.SecurityRulesDAO;
import com.htc.LMS.dao.LMS_DASHBOARD_DAO;
import com.htc.authentication.dao.LoginDetailDAO;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.utility.DashboardConstants;
/**
 * 
 * @author HTC Offshore
 * 
 * Description: admin can add permission for reports
 *
 */
@Controller
public class ImpersonationController {

	private static final Logger logger = Logger.getLogger(ImpersonationController.class);
	@Autowired
	private SecurityRulesDAO securityRulesDAO;
	
	@Autowired
	private SecurityRulesDAO securityRulesDAORemedy;
	
	@Autowired
	private LoginDetailDAO loginTabsReports;
	
	@Autowired
	LMS_DASHBOARD_DAO dataSourceLMS;


	/*
	 * This method is used for displaying user field post selecting "One or more user" in 'Applies To' drop down field of Security Rules screen.
	 * This method with return external and remedy user
	 */
	@RequestMapping(value = "/Impersonation", method = RequestMethod.POST ,produces="application/json")
	public String getUserAppliesTo(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		Map<String, List<?>> impersonationRemedyUserDTOList = new HashMap<String, List<?>>();
		
		try {			
			impersonationRemedyUserDTOList = securityRulesDAORemedy.getAllRemedyUser();
					
			if(impersonationRemedyUserDTOList != null && impersonationRemedyUserDTOList.size() > 0){
				model.addAttribute("RemedyList", impersonationRemedyUserDTOList);
			}
			
			
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		
		
		return "Admin/Impersonation";
	}
	
	@RequestMapping(value = "/impersonationform", method = RequestMethod.POST ,produces="application/json")
	public String getUserApply(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		try {
		String Username="";
		String type="REMEDY";
		String teleopti_Agent_Id="";
		String teleopti_role="";
		String prev_teleopti_Agent_Id="";
		String prev_teleopti_role="";
		Map<String,String> teleopti_agent_role_Map=null;
		//Username=(String)request.getParameter("selectremedyuser");
		Username=(String)request.getParameter("data-selected-user");
				
		String groupids="";
		List<Integer> previousgroupid = new ArrayList<Integer>();
		List<Integer> groupidvalues = new ArrayList<Integer>();
		Map tabReports = new HashMap();
		Map previoustabReports = new HashMap();
		LoginDetailDTO loginDTO = new LoginDetailDTO();
		
		
		String previousUser=(String)session.getAttribute("username");
		previousgroupid=(List)session.getAttribute(DashboardConstants.GROUP_IDS);
	    previoustabReports=(Map)session.getAttribute(DashboardConstants.USER_REPORT_MAP);
	    prev_teleopti_Agent_Id=(String)session.getAttribute(DashboardConstants.TELEOPTI_USER_ID);
	    prev_teleopti_role=(String)session.getAttribute(DashboardConstants.ROLE);
					
	
			
			groupids = securityRulesDAORemedy.getRemedyIDS(Username);
			
			loginDTO.setUserName(Username);
			loginDTO.setGroup(groupids);
			loginDTO.setAuthType(type);
			tabReports = loginTabsReports.getReportsForUser(loginDTO);
			teleopti_agent_role_Map=dataSourceLMS.getTeleoptiAgentDetails(loginDTO);
			if(null!=teleopti_agent_role_Map)
			{
			teleopti_Agent_Id=teleopti_agent_role_Map.get(DashboardConstants.AGENT_ID);
			teleopti_role=teleopti_agent_role_Map.get(DashboardConstants.ROLE);
			}
			logger.info("Teleopti Agent id  ="+teleopti_Agent_Id+"   Role ="+teleopti_role);

			logger.info("changed user reports : ---> "
						+ tabReports);
			
		
		if(groupids.contains(";"))
		{
			String[] values=groupids.split(";");
			
			for(String   gid:values)
			{
				if(!gid.equals(""))
				{
				int i=Integer.parseInt(gid);
				
				groupidvalues.add(i);
				}
			}
			
		}
		
		//present impersonate user detilas
		session.setAttribute("username", Username);
		session.setAttribute(DashboardConstants.USER_REPORT_MAP,
				tabReports);
		session.setAttribute(DashboardConstants.GROUP_IDS, groupidvalues);
		session.setAttribute(DashboardConstants.TELEOPTI_USER_ID, teleopti_Agent_Id);
		session.setAttribute(DashboardConstants.ROLE, teleopti_role);
		session.setAttribute("USERIMPERSONATION", "impersonationout");
		//Previous impersonation user details
		session.setAttribute("PREVIOUSUSER", previousUser);
		session.setAttribute("PREVIOUSUSERGROUPIDS",previousgroupid);
		session.setAttribute("PREVIOUSUSERTABReports",previoustabReports);
		session.setAttribute("PREVIOUSTELEOPTIUSERID",prev_teleopti_Agent_Id);
		session.setAttribute("PREVIOUSROLE",prev_teleopti_role);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		
		return "authentication/DashBoardHome";
	}
	
	@RequestMapping(value = "/ImpersonateRedirect", method = RequestMethod.GET ,produces="application/json")
	public String getImpersonateRedirect(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		String previousUser=(String)session.getAttribute("PREVIOUSUSER");
		List<Integer> previousgroupids = new ArrayList<Integer>();
		 previousgroupids=(List)session.getAttribute("PREVIOUSUSERGROUPIDS");
		Map previoustabReports = new HashMap();
		previoustabReports=(Map)session.getAttribute("PREVIOUSUSERTABReports");
		String prev_teleopti_Agent_Id=(String)session.getAttribute("PREVIOUSTELEOPTIUSERID");
		String prev_teleopti_role=(String)session.getAttribute("PREVIOUSROLE");
		
		session.setAttribute("username", previousUser);
		session.setAttribute(DashboardConstants.USER_REPORT_MAP,previoustabReports);
		session.setAttribute(DashboardConstants.GROUP_IDS, previousgroupids);
		session.setAttribute(DashboardConstants.TELEOPTI_USER_ID, prev_teleopti_Agent_Id);
		session.setAttribute(DashboardConstants.ROLE, prev_teleopti_role);
		session.setAttribute("USERIMPERSONATION", "");
		return "authentication/DashBoardHome";
		
		
		
	}
	
	
}
