package com.htc.Admin.controller;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.MonitoringsDAO;
@Controller
public class MonitoringController {

	@Autowired
	private MonitoringsDAO monitorJobsDAO;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private JavaMailSender mailSenderMissedJob;

	private static final Logger logger = Logger
			.getLogger(MonitoringController.class);

	@RequestMapping(value = "/Monitoring", method = RequestMethod.POST)
	public String monitorHref(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		Map<String, List<Object[]>> map = new HashMap<>();
		Map<String, List<Object[]>> missedJabMap = new HashMap<>();
		List<Object> jobInfo=null;
		List<Object> missedJobInfo=null;
		String Status="";
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			try {
				map = monitorJobsDAO.monitorJobs();
				ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
				InputStream input = classLoader.getResourceAsStream("EmailProperties.properties");
				final Properties p = new Properties();
				p.load(input);
				if(null!=map){
					List<Object[]> mapValues=map.get("MONITORINGVALUES");
					if(null!=mapValues){
						for (Object[] value :mapValues) {

							if(null!=value){
								jobInfo=new ArrayList<>();
								for (Object value1 :value) {
									jobInfo.add(value1);
								}

								if(null!=jobInfo){	
									if("0".equalsIgnoreCase(jobInfo.get(6).toString())){
										p.setProperty("subject","MDD:"+jobInfo.get(0).toString()+"-"+jobInfo.get(2).toString()+"-"+jobInfo.get(3).toString());
										p.setProperty("message",jobInfo.get(2).toString()+" Failed.\nNote: Don't reply to this mail");
										mailSender.send(new MimeMessagePreparator() {
											@Override
											public void prepare(MimeMessage mimeMessage) throws Exception  {
												try{
													MimeMessageHelper messageHelper = new MimeMessageHelper(
															mimeMessage, true, "UTF-8");

													messageHelper.addTo(p.getProperty("MONITORING_TO_MAIL_ADDRESS"));
													messageHelper.setFrom(p.getProperty("MONITORING_FROM_MAIL_ADDRESS"));
													messageHelper.setSubject(p.getProperty("subject"));
													messageHelper.setText(p.getProperty("message"));
												}
												catch (Exception e) {
													logger.error(e.getMessage());
													throw new Exception(e.getMessage().replace('<', '-').replace('>', '-'));
												}

												// determines if there is an upload file, attach it to the e-mail
												//String attachName = attachFile.getOriginalFilename();
											}
										});

										String timeStamp=jobInfo.get(3).toString();
										Status= monitorJobsDAO.notifyAndFix(jobInfo.get(0).toString(),jobInfo.get(2).toString(),timeStamp,"notify");
										logger.info(jobInfo.get(0).toString()+":"+jobInfo.get(2)+":"+timeStamp+"-Status="+Status);
										logger.info("thanks,mail sent successfully");

									}
								}	

							}	
						}
					}	
				}		

				map = monitorJobsDAO.monitorJobs();
				logger.info("failureNotices===="+map);
				missedJabMap = monitorJobsDAO.getJobScheduleTime();

				if(null!=missedJabMap){
					List<Object[]> mapValues=missedJabMap.get("JOBSCHEDULEDVALUES");
					if(null!=mapValues){
						for (Object[] value :mapValues) {

							if(null!=value){
								missedJobInfo=new ArrayList<>();
								for (Object value1 :value) {
									missedJobInfo.add(value1);
								}

								if(null!=missedJobInfo){	
									if("0".equalsIgnoreCase(missedJobInfo.get(7).toString())){
										p.setProperty("missedjobSubject","MDD:"+missedJobInfo.get(0).toString()+"-"+missedJobInfo.get(1).toString()+"-"+missedJobInfo.get(4).toString());
										p.setProperty("missedjobMessage",missedJobInfo.get(1).toString()+" Failed.\nNote: Don't reply to this mail");

										mailSenderMissedJob.send(new MimeMessagePreparator() {
											@Override
											public void prepare(MimeMessage mimeMessage) throws Exception  {
												try{
													MimeMessageHelper messageHelper = new MimeMessageHelper(
															mimeMessage, true, "UTF-8");

													messageHelper.addTo(p.getProperty("MONITORING_TO_MAIL_ADDRESS"));
													messageHelper.setFrom(p.getProperty("MONITORING_FROM_MAIL_ADDRESS"));
													messageHelper.setSubject(p.getProperty("missedjobSubject"));
													messageHelper.setText(p.getProperty("missedjobMessage"));
												}
												catch (Exception e) {
													logger.error(e.getMessage());
													throw new Exception(e.getMessage().replace('<', '-').replace('>', '-'));
												}

												// determines if there is an upload file, attach it to the e-mail
												//String attachName = attachFile.getOriginalFilename();
											}
										});

										String timeStamp=missedJobInfo.get(4).toString();
										Status= monitorJobsDAO.notifyAndFix(missedJobInfo.get(0).toString(),missedJobInfo.get(1).toString(),timeStamp,"notify");
										logger.info(missedJobInfo.get(0).toString()+":"+missedJobInfo.get(1)+":"+timeStamp+"-Status="+Status);
										logger.info("thanks,mail sent successfully");

									}
								}	

							}	
						}
					}	
				}



				missedJabMap = monitorJobsDAO.getJobScheduleTime();
				logger.info("missedSchedule===="+missedJabMap);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage().replace('<', '-').replace('>', '-'));
			}

			request.setAttribute("monitoringMap",map);
			request.setAttribute("jobScheduledMap",missedJabMap);
			return "Admin/Monitoring";
		}{
			return "common/UnAuthoriseAccess";
		}	
	}


	@RequestMapping(value = "/notifyAndFix", method = RequestMethod.GET )
	public @ResponseBody
	String downloadDocs(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		String Status="";
		String groupId=request.getParameter("grpID");
		String jobName=request.getParameter("jbname");
		String timeStamp=request.getParameter("timeStamp");
		String ValidationFlag=request.getParameter("ValidationFlag");
		try {

			Status= monitorJobsDAO.notifyAndFix(groupId,jobName,timeStamp,ValidationFlag);
			logger.info("grpId="+groupId+"jobName="+jobName+"timeStamp="+timeStamp+"ValidationFlag="+ValidationFlag+"Status="+Status);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		return Status;
	}




	@RequestMapping(value = "/MonitoringAutoRefresh", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String,  Map<String, List<Object[]>>> monitoringAutoRefresh(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception,AddressException, MessagingException {
		Map<String, List<Object[]>> map = new HashMap<>();
		Map<String, List<Object[]>> missedJabMap = null;
		List<Object> jobInfo=null;
		List<Object> missedJobInfo=null;
		String Status="";

		Map<String,  Map<String, List<Object[]>>> failureAndMissed=new HashMap<String,  Map<String, List<Object[]>>>();
		try {
			map = monitorJobsDAO.monitorJobs();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream input = classLoader.getResourceAsStream("EmailProperties.properties");
			final Properties p = new Properties();
			p.load(input);

			if(null!=map){
				List<Object[]> mapValues=map.get("MONITORINGVALUES");
				if(null!=mapValues){
					for (Object[] value :mapValues) {

						if(null!=value){
							jobInfo=new ArrayList<>();
							for (Object value1 :value) {
								jobInfo.add(value1);
							}

							if(null!=jobInfo){	
								if("0".equalsIgnoreCase(jobInfo.get(6).toString())){

									p.setProperty("subject","MDD:"+jobInfo.get(0).toString()+"-"+jobInfo.get(2).toString()+"-"+jobInfo.get(3).toString());
									p.setProperty("message",jobInfo.get(2).toString()+" Failed.\nNote: Don't reply to this mail");
									mailSender.send(new MimeMessagePreparator() {
										@Override
										public void prepare(MimeMessage mimeMessage) throws Exception,AddressException, MessagingException {
											MimeMessageHelper messageHelper = new MimeMessageHelper(
													mimeMessage, true, "UTF-8");

											messageHelper.addTo(p.getProperty("MONITORING_TO_MAIL_ADDRESS"));
											messageHelper.setFrom(p.getProperty("MONITORING_FROM_MAIL_ADDRESS"));
											messageHelper.setSubject(p.getProperty("subject"));
											messageHelper.setText(p.getProperty("message"));

											// determines if there is an upload file, attach it to the e-mail
											//String attachName = attachFile.getOriginalFilename();
										}
									});

									String timeStamp=jobInfo.get(3).toString();
									Status= monitorJobsDAO.notifyAndFix(jobInfo.get(0).toString(),jobInfo.get(2).toString(),timeStamp,"notify");
									logger.info(jobInfo.get(0).toString()+":"+jobInfo.get(2)+":"+timeStamp+"-Status="+Status);
									logger.info("thanks,mail sent successfully");
								}	

							}	
						}
					}	
				}		
			}
			logger.info("refreshFailureNotices===="+map);
			missedJabMap = monitorJobsDAO.getJobScheduleTime();
			if(null!=missedJabMap){
				List<Object[]> mapValues=missedJabMap.get("JOBSCHEDULEDVALUES");
				if(null!=mapValues){
					for (Object[] value :mapValues) {

						if(null!=value){
							missedJobInfo=new ArrayList<>();
							for (Object value1 :value) {
								missedJobInfo.add(value1);
							}

							if(null!=missedJobInfo){	
								if("0".equalsIgnoreCase(missedJobInfo.get(7).toString())){
									p.setProperty("missedjobSubject","MDD:"+missedJobInfo.get(0).toString()+"-"+missedJobInfo.get(1).toString()+"-"+missedJobInfo.get(4).toString());
									p.setProperty("missedjobMessage",missedJobInfo.get(1).toString()+" Failed.\nNote: Don't reply to this mail");

									mailSenderMissedJob.send(new MimeMessagePreparator() {
										@Override
										public void prepare(MimeMessage mimeMessage) throws Exception  {
											try{
												MimeMessageHelper messageHelper = new MimeMessageHelper(
														mimeMessage, true, "UTF-8");

												messageHelper.addTo(p.getProperty("MONITORING_TO_MAIL_ADDRESS"));
												messageHelper.setFrom(p.getProperty("MONITORING_FROM_MAIL_ADDRESS"));
												messageHelper.setSubject(p.getProperty("missedjobSubject"));
												messageHelper.setText(p.getProperty("missedjobMessage"));
											}
											catch (Exception e) {
												logger.error(e.getMessage());
												throw new Exception(e.getMessage().replace('<', '-').replace('>', '-'));
											}

											// determines if there is an upload file, attach it to the e-mail
											//String attachName = attachFile.getOriginalFilename();
										}
									});

									String timeStamp=missedJobInfo.get(4).toString();
									Status= monitorJobsDAO.notifyAndFix(missedJobInfo.get(0).toString(),missedJobInfo.get(1).toString(),timeStamp,"notify");
									logger.info(missedJobInfo.get(0).toString()+":"+missedJobInfo.get(1)+":"+timeStamp+"-Status="+Status);
									logger.info("thanks,mail sent successfully");

								}
							}	

						}	
					}
				}	
			}	


			logger.info("refreshMissedSchedule===="+missedJabMap);
			failureAndMissed.put("monitoringMap", map);
			failureAndMissed.put("jobScheduledMap", missedJabMap);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage().replace('<', '-').replace('>', '-'));
		}
		return failureAndMissed;
	}

	@RequestMapping(value = "/jobResolveStep", method = RequestMethod.GET,produces="application/json")

	public @ResponseBody List<String> getJobResolveSteps(@RequestParam("jobName") String jobName,@RequestParam("jobTime") String jobTime,@RequestParam("jobType") String jobType,ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		List<String> steps=new ArrayList<String>();
		String userName = (String) session.getAttribute("username");

		try {

			steps= monitorJobsDAO.getJobResolveSteps(jobName,jobTime,jobType);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return steps;
	}

	
	



}
