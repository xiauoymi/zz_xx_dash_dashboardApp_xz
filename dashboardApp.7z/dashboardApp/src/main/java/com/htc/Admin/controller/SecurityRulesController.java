package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.SecurityRulesDAO;
import com.htc.Admin.dto.SecurityRulesDTO;
import com.htc.utility.DashboardConstants;
/**
 * 
 * @author HTC Offshore
 * 
 * Description: admin can add permission for reports
 *
 */
@Controller
public class SecurityRulesController {

	private static final Logger logger = Logger.getLogger(SecurityRulesController.class);
	@Autowired
	private SecurityRulesDAO securityRulesDAO;
	
	@Autowired
	private SecurityRulesDAO securityRulesDAORemedy;

	/*
	 * This method is used for displaying security Rules Screen if session is active otherwise unauthorise access screen will display.
	 * Available Report name for particular user will also display in "Report Name" drop down field of Security Rules screen.
	 */
	@RequestMapping(value = "/SecurityRules", method = RequestMethod.POST)
	public String getSecurityRule(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			List<String> reportNameList = new ArrayList<String>();
			try {
				reportNameList = securityRulesDAO.getReportName();
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			if(reportNameList != null && !reportNameList.isEmpty()){
				session.setAttribute(DashboardConstants.RULE_TYPES, reportNameList);
			}
			return "Admin/SecurityRules";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	/*
	 * This method is used for displaying user field post selecting "One or more user" in 'Applies To' drop down field of Security Rules screen.
	 * This method with return external and remedy user in json format.
	 */
	@RequestMapping(value = "/userAppliesTo", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public Map<String,List<String>> getUserAppliesTo(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		Map<String,List<String>> appliesToUser = new HashMap<String,List<String>>();
		List<String> remedyUserList = new ArrayList<String>();
		List<String> externalUserList = new ArrayList<String>();
		try {
			
			remedyUserList = securityRulesDAORemedy.getAppliesToUserRemedy();
			externalUserList = securityRulesDAO.getAppliesToUser();
			if(null != remedyUserList &&  null != externalUserList)
			{
				appliesToUser.put(DashboardConstants.REMEDY_USER, remedyUserList);
				appliesToUser.put(DashboardConstants.EXTERNAL_USER, externalUserList);
				
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return appliesToUser;
	}

	/*
	 * This method is used for displaying Groups field post selecting "One or more Groups" in 'Applies To' drop down field Security Rules screen.
	 * This method will return external and remedy groups in json format.
	 */
	@RequestMapping(value = "/groupAppliesTo", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public Map<String,List<String>> getGroupAppliesTo(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		Map<String,List<String>> appliesToGroup = new HashMap<String,List<String>>();
		List<String> remedyGroupList = new ArrayList<String>();
		List<String> externalGroupList = new ArrayList<String>();
		try {
			externalGroupList = securityRulesDAO.getAppliesToExternalGroup();
			remedyGroupList = securityRulesDAORemedy.getAppliesToRemedyGroup();
			if(null != externalGroupList ){
				appliesToGroup.put(DashboardConstants.EXTERNAL_USER, externalGroupList);
			}
			if(null != remedyGroupList ){
				appliesToGroup.put(DashboardConstants.REMEDY_USER, remedyGroupList);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return appliesToGroup;
	}

	/*
	 * This method is used for inserting or deleting user/groups post clicking on apply button in Security Rules screen.
	 * This method will return success/failure message post execution.
	 */
	@RequestMapping(value = "/updatePermissions", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> setUpdatePermissions(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		String userName = "";
		String access = "";
		String reportName = "";
		String appliesTo = "";
		String userOrGroup = "";
		String userType = "";
		userName = (String) session.getAttribute("username");
		access = request.getParameter("access");
		reportName = request.getParameter("reportname");
		appliesTo = request.getParameter("appliesto");
		userOrGroup = request.getParameter("userorgroup");
		userType = request.getParameter("usertype");
		SecurityRulesDTO securityRulesDTO=new SecurityRulesDTO();
		List<String> resultMsg = new ArrayList<String>();
		securityRulesDTO.setAccess(access);
		securityRulesDTO.setReportName(reportName);
		securityRulesDTO.setAppliesTo(appliesTo);
		securityRulesDTO.setUserOrGroup(userOrGroup);
		securityRulesDTO.setUserType(userType);
		try {
			resultMsg = securityRulesDAO.setAddPermissions(securityRulesDTO,userName);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return resultMsg;
	}

	/*
	 * This method is used for displaying Users/Groups based on filter criteria post clicking on "search" button in Security Rules screen.
	 * This method will return user/group name,type,role in json format.
	 */
	@RequestMapping(value = "/viewRules", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public Map<String,List<List<String>>> getViewRules(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {
		String reportName = "";
		reportName = request.getParameter("reportname");
		Map<String,List<List<String>>> viewRules = new HashMap<String,List<List<String>>>();
		try {
			viewRules = securityRulesDAO.getViewRules(reportName);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return viewRules;
	}
}
