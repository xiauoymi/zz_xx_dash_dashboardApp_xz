package com.htc.Admin.controller;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.htc.Admin.dao.MonthEndReportDAO;
import com.htc.utility.DashboardConstants;


@Controller
public class MonthEndReportController {

	@Autowired
	MonthEndReportDAO  monthEndReportDao;

	@Autowired
	ServletContext context;

	@RequestMapping(value = "/MonthEnd", method = RequestMethod.GET)
	public String getMetricTree(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		Map<String, List<?>> monthEndMap=new HashMap<>();
		monthEndMap=monthEndReportDao.monthEndReport();
		request.setAttribute(DashboardConstants.MONTHENDREPORTMAP, monthEndMap);
		return "Admin/MonthEndReport";
	}

	@RequestMapping(value = "/downloadMonthEndreport", method = RequestMethod.GET )
	public @ResponseBody
	void getPulseAlert(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		ServletOutputStream sos;
		String fileName="Y:\\DOCX\\2017_03\\HFM Service Desk Performance Metrics March 2017.docx";  //.docx or .txt
		File f = new File(fileName);
		FileInputStream istr = new FileInputStream(f);
		BufferedInputStream bstr = new BufferedInputStream( istr );
		int size = (int) f.length(); // get the file size (in bytes)
		byte[] data = new byte[size];
		bstr.read( data, 0, size ); // read into byte array
		bstr.close();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition","attachment; filename=\"" + fileName + "\"");
		sos = response.getOutputStream();
		sos.write(data);
		sos.flush();
		sos.close();
	}

	@RequestMapping(value = "/exefile", method = RequestMethod.GET )
	public @ResponseBody
	void getexefile(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		try {
			Runtime rt=Runtime.getRuntime();
			String cmd[]={"cmd.exe", "/C", "\\\\impc1940\\MonthEndProcess\\Release\\MonthEndProcessing.exe 21"};
			rt.exec(cmd); 

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
