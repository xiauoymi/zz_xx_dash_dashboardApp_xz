package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.utility.StoredProcedureConstants;

public class MonitoringsDAO {

	private static final Logger logger = Logger.getLogger(MonitoringsDAO.class);
	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@SuppressWarnings("deprecation")
	public Map<String, List<Object[]>> monitorJobs() throws SQLException, ParseException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object[]> reportList = new ArrayList<>();
		List<Object[]> reportDescriptionList = new ArrayList<Object[]>();
		Object[] ColumnNameArray=null;
		Object[] values = null;
		LinkedHashMap<String, List<Object[]>> monitorJobs = new LinkedHashMap<String, List<Object[]>>();
		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_etl_monitoring;
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			ColumnNameArray=new Object[columnCount];
			for (int i = 1; i <=columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				ColumnNameArray[i-1]=name;
			}
			reportDescriptionList.add(ColumnNameArray);

			while (resultSet.next()) {
				values = new String[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if("Job Start Time".equalsIgnoreCase(resultSetMetaData.getColumnName(i))){
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm");
						Date date = formatter.parse(resultSet.getString(i).toString());

						String dateFormate=""+date.getDate(); 
						if(date.getDate()<10){
							dateFormate="0"+date.getDate();
						}

						String mnthFormate=""+(date.getMonth()+1); 
						if(date.getMonth()<8){
							mnthFormate="0"+(date.getMonth()+1);
						}

						String hrsFormate=""+date.getHours(); 
						if(date.getHours()<10){
							hrsFormate="0"+date.getHours();
						}

						String mntsFormate=""+date.getMinutes(); 
						if(date.getMinutes()<10){
							mntsFormate="0"+date.getMinutes();
						}



						values[i - 1]=hrsFormate+":"+mntsFormate+" "+mnthFormate+"/"+dateFormate;
					}else if("JobTime".equalsIgnoreCase(resultSetMetaData.getColumnName(i))){
						SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
						Date date = sdf.parse(resultSet.getObject(i).toString());
						values[i - 1] = sdf.format(date);
					}else{
						values[i - 1] = resultSet.getString(i);
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}




			monitorJobs.put("MONITORINGNAMES",
					reportDescriptionList);
			monitorJobs.put("MONITORINGVALUES", reportList);



		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return monitorJobs;
	}

	public String notifyAndFix(String grpId,String jobName,String timeStamp,String validationFlag) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		String Status="";	
		try {
			connection = dataSource.getConnection();
			if ("notify".equals(validationFlag)) {
				query = StoredProcedureConstants.sp_monitoring_notify;
			} else if ("fix".equals(validationFlag)) {
				query = StoredProcedureConstants.sp_monitoring_fix;
			}

			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, grpId);
			callableStatement.setString(2, jobName);
			callableStatement.setString(3, timeStamp);
			resultSet = callableStatement.executeQuery();

			while (resultSet.next()) {
				Status=resultSet.getString(1);
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return Status;
	}


	@SuppressWarnings("deprecation")
	public LinkedHashMap<String, List<Object[]>> getJobScheduleTime() throws SQLException, ParseException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<Object[]> reportList = new ArrayList<Object[]>();
		List<Object[]> reportDescriptionList = new ArrayList<Object[]>();
		LinkedHashMap<String, List<Object[]>> monitorJobs = new LinkedHashMap<String, List<Object[]>>();
		Object[] ColumnNameArray=null;
		try {
			connection = dataSource.getConnection();
			query = StoredProcedureConstants.sp_monitoring_not_run_jobs;
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();


			ColumnNameArray=new Object[columnCount];
			for (int i = 1; i <=columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				ColumnNameArray[i-1]=name;
			}
			reportDescriptionList.add(ColumnNameArray);


			while (resultSet.next()) {
				Object[] values = new Object[columnCount];
				for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
					if (resultSetMetaData.getColumnTypeName(i).equals("float")
							&& resultSet.getString(i) != null) {
						values[i - 1] = String.format("%.2f",
								Float.parseFloat(resultSet.getString(i)))
								.replaceAll("\\.*0*$", "");
					} else {
						if("Job Last Run Time".equalsIgnoreCase(resultSetMetaData.getColumnName(i))){
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
							Date date = formatter.parse(resultSet.getString(i));
							String dateFormate=""+date.getDate(); 
							if(date.getDate()<10){
								dateFormate="0"+date.getDate();
							}

							String mnthFormate=""+(date.getMonth()+1); 
							if(date.getMonth()<8){
								mnthFormate="0"+(date.getMonth()+1);
							}

							String hrsFormate=""+date.getHours(); 
							if(date.getHours()<10){
								hrsFormate="0"+date.getHours();
							}

							String mntsFormate=""+date.getMinutes(); 
							if(date.getMinutes()<10){
								mntsFormate="0"+date.getMinutes();
							}



							values[i - 1]=hrsFormate+":"+mntsFormate+" "+mnthFormate+"/"+dateFormate;
						}else if("JobTime".equalsIgnoreCase(resultSetMetaData.getColumnName(i))){
							SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
							Date date = sdf.parse(resultSet.getObject(i).toString());
							values[i - 1] = sdf.format(date);
						}else{
							values[i - 1] = resultSet.getObject(i);
						}
					}
					if ((values[i - 1]) == null) {
						values[i - 1] = "";
					}
				}
				reportList.add(values);
			}

			monitorJobs.put("JOBSCHEDULEDNAMES",
					reportDescriptionList);
			monitorJobs.put("JOBSCHEDULEDVALUES", reportList);



		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return monitorJobs;
	}

	public List<String> getJobResolveSteps(String jobName,String jobTime,String jobType) throws SQLException, NamingException {

		logger.info("jobResolve steps Table Detail from DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		Statement statement = null;
		ResultSet resultSet = null;

		String sdMtericsDetailquery = "";
		List<String> reportList = new ArrayList<String>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> AAATableMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();

			sdMtericsDetailquery =StoredProcedureConstants.sp_get_ETL_Monitoring_help;

			callableStatement = connection.prepareCall(sdMtericsDetailquery);
			callableStatement.setString(1,jobName );
			callableStatement.setString(2,jobTime );
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet.getString(reportDescriptionList.get(i));
					reportList.add(getColumnVal);
				}

			}


		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("job Resolve steps Table Detail from DB Ends");
		return reportList;
	}



}
