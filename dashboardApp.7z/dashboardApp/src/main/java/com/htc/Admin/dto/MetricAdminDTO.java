package com.htc.Admin.dto;

public class MetricAdminDTO {
	String parentId=null;
	String type=null;
	String status=null;
	String name=null;
	String label=null;
	String abbreviation=null;
	String description=null;
	String remedyGroupId=null;
	String sourceType=null;
	String cretatedAndModifiedBy=null;
	String clientId=null;
	String userId=null;
	String parentBilling=null;
	String parentMetricId=null;
	String parentCategoryId=null;
	String metricFormula=null;

	private String rowId = null;
	private String customerCode = null;
	private String customerType = null;
	private String customer = null;
	private String purOrgName = null;
	private String prmryTwrColor = null;
	private String scndryTwrColor = null;
	private String flr = null;
	private String netFlr = null;
	private String dlyBfrAnsPerc = null;
	private String dlyBfrAnsInSec = null;
	private String abdnmntRate = null;
	private String cSat = null;
	private String mnthlyRprtDlvry = null;
	private String hideFromMtd = null;
	private String totalContacts = null;
	private String cSatFirstLevel = null;

	public String getParentMetricId() {
		return parentMetricId;
	}
	public void setParentMetricId(String parentMetricId) {
		this.parentMetricId = parentMetricId;
	}
	public String getParentCategoryId() {
		return parentCategoryId;
	}
	public void setParentCategoryId(String parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}
	public String getMetricFormula() {
		return metricFormula;
	}
	public void setMetricFormula(String metricFormula) {
		this.metricFormula = metricFormula;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemedyGroupId() {
		return remedyGroupId;
	}
	public void setRemedyGroupId(String remedyGroupId) {
		this.remedyGroupId = remedyGroupId;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public String getCretatedAndModifiedBy() {
		return cretatedAndModifiedBy;
	}
	public void setCretatedAndModifiedBy(String cretatedAndModifiedBy) {
		this.cretatedAndModifiedBy = cretatedAndModifiedBy;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getParentBilling() {
		return parentBilling;
	}
	public void setParentBilling(String parentBilling) {
		this.parentBilling = parentBilling;
	}
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getPurOrgName() {
		return purOrgName;
	}
	public void setPurOrgName(String purOrgName) {
		this.purOrgName = purOrgName;
	}
	public String getPrmryTwrColor() {
		return prmryTwrColor;
	}
	public void setPrmryTwrColor(String prmryTwrColor) {
		this.prmryTwrColor = prmryTwrColor;
	}
	public String getScndryTwrColor() {
		return scndryTwrColor;
	}
	public void setScndryTwrColor(String scndryTwrColor) {
		this.scndryTwrColor = scndryTwrColor;
	}
	public String getFlr() {
		return flr;
	}
	public void setFlr(String flr) {
		this.flr = flr;
	}
	public String getNetFlr() {
		return netFlr;
	}
	public void setNetFlr(String netFlr) {
		this.netFlr = netFlr;
	}
	public String getDlyBfrAnsPerc() {
		return dlyBfrAnsPerc;
	}
	public void setDlyBfrAnsPerc(String dlyBfrAnsPerc) {
		this.dlyBfrAnsPerc = dlyBfrAnsPerc;
	}
	public String getDlyBfrAnsInSec() {
		return dlyBfrAnsInSec;
	}
	public void setDlyBfrAnsInSec(String dlyBfrAnsInSec) {
		this.dlyBfrAnsInSec = dlyBfrAnsInSec;
	}
	public String getAbdnmntRate() {
		return abdnmntRate;
	}
	public void setAbdnmntRate(String abdnmntRate) {
		this.abdnmntRate = abdnmntRate;
	}
	public String getcSat() {
		return cSat;
	}
	public void setcSat(String cSat) {
		this.cSat = cSat;
	}
	public String getMnthlyRprtDlvry() {
		return mnthlyRprtDlvry;
	}
	public void setMnthlyRprtDlvry(String mnthlyRprtDlvry) {
		this.mnthlyRprtDlvry = mnthlyRprtDlvry;
	}
	public String getHideFromMtd() {
		return hideFromMtd;
	}
	public void setHideFromMtd(String hideFromMtd) {
		this.hideFromMtd = hideFromMtd;
	}
	public String getTotalContacts() {
		return totalContacts;
	}
	public void setTotalContacts(String totalContacts) {
		this.totalContacts = totalContacts;
	}
	public String getcSatFirstLevel() {
		return cSatFirstLevel;
	}
	public void setcSatFirstLevel(String cSatFirstLevel) {
		this.cSatFirstLevel = cSatFirstLevel;
	}
}
