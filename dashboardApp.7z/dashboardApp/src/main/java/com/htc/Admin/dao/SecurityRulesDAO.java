package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.htc.Admin.dto.SecurityRulesDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

@Repository
public class SecurityRulesDAO {

	DataSource dataSource;
	private static final Logger LOGGER = Logger.getLogger(SecurityRulesDAO.class);
	public void setDataSourceMetrics(DataSource dataSourceMetrics) {
		this.dataSource = dataSourceMetrics;
	}

	DataSource dataSourceRemedy;

	public void setDataSourceRemedy(DataSource securityRulesDAORemedy) {
		this.dataSourceRemedy = securityRulesDAORemedy;
	}

	/*
	 * This method is used for getting the Report names. This method will not
	 * take any arguments. This method will return list type value i.e.
	 * reportName.
	 */
	public List<String> getReportName() throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String reportNameQuery = StoredProcedureConstants.sp_Get_SDM_Report_Name;
		List<String> reportName = new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(reportNameQuery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				reportName.add(resultSet.getString(1));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return reportName;
	}

	/*
	 * This method is used for getting the user names(External and Remedy). This
	 * method will not take any arguments. This method will return map type
	 * value i.e. userMap.
	 */
	public List getAppliesToUser() throws SQLException,
	NamingException {

		Connection connection = null;
		CallableStatement callableStatement=null;
		ResultSet resultSet=null;
		String externalUserQuery="";
		List<String> externalUserList = new ArrayList<String>();
		externalUserQuery = StoredProcedureConstants.sp_Get_User_Name_For_External;

		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(externalUserQuery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				externalUserList.add(resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return externalUserList;
	}

	/*
	 * This method is used for getting the group names(External and Remedy).
	 * This method will not take any arguments. This method will return map type
	 * value i.e. groupMap.
	 */
	public List<String> getAppliesToExternalGroup() throws SQLException,
	NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String externalGroupQuery = "";
		List<String> externalGroupList = new ArrayList<String>();
		externalGroupQuery = StoredProcedureConstants.sp_Get_SDM_GroupName_External;

		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(externalGroupQuery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				externalGroupList.add(resultSet.getString(1));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return externalGroupList;
	}
	
	public List<String> getAppliesToRemedyGroup() throws SQLException,
	NamingException {

		Connection connection = null;
		Statement  statement = null;
		ResultSet resultSet = null;
		String remedyGroupQuery = "";
		List<String> remedyGroupList = new ArrayList<String>();
		remedyGroupQuery = "SELECT Group_Name,Group_ID FROM Group_X WITH (NOLOCK)";

		try {
			connection = dataSourceRemedy.getConnection();
			statement  = connection.createStatement();
			resultSet  = statement.executeQuery(remedyGroupQuery);
			while (resultSet.next()) {
				remedyGroupList.add(resultSet.getString(1));
			}
			
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return remedyGroupList;
	}

	/*
	 * This method is used for inserting or deleting the users/groups . This
	 * method will take two arguments i.e SecurityRulesDTO object and username.
	 * This method will return List type value i.e. resultMsg.
	 */
	public List<String> setAddPermissions(SecurityRulesDTO securityRulesDTO,
			String userName) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> resultMsg = new ArrayList<String>();
		String groupAndUserQuery = StoredProcedureConstants.sp_Assign_Report_To_GroupAndUser_with_Access;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(groupAndUserQuery);
			callableStatement.setString(1, securityRulesDTO.getAccess());
			callableStatement.setString(2, securityRulesDTO.getUserOrGroup());
			callableStatement.setString(3, securityRulesDTO.getReportName());
			callableStatement.setString(4, securityRulesDTO.getAppliesTo());
			callableStatement.setString(5, securityRulesDTO.getUserType());
			callableStatement.setString(6, userName);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg.add(resultSet.getString(1));
				resultMsg.add(resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	/*
	 * This method is used for getting the list of available users/groups. This
	 * method will take one argument i.e report Name. This method will return
	 * map type value i.e. userGroupMap.
	 */
	public Map<String, List<List<String>>> getViewRules(String reportName)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> userGroupList = null;
		List<List<String>> userGroupListOfList = new ArrayList<List<String>>();
		Map<String, List<List<String>>> userGroupMap = new HashMap<String, List<List<String>>>();
		String viewRulesQuery = StoredProcedureConstants.SP_VIEW_RULES;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(viewRulesQuery);
			callableStatement.setString(1, reportName);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				userGroupList = new ArrayList<String>();
				userGroupList.add(resultSet.getString(1));
				userGroupList.add(resultSet.getString(2));
				userGroupList.add(resultSet.getString(3));
				userGroupListOfList.add(userGroupList);
				userGroupList = null;
			}
			userGroupMap.put(DashboardConstants.VIEW_USER_GROUP_NAME,
					userGroupListOfList);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userGroupMap;
	}

	public List getAppliesToUserRemedy() throws SQLException {
		// TODO Auto-generated method stub

		Connection connection = null;
		CallableStatement callableStatement, callableStatement1;
		callableStatement = callableStatement1 = null;
		ResultSet resultSet, resultSet1;
		resultSet = resultSet1 = null;
		Statement statement = null;
		String remedyUserQuery="";
		List<String> remedyUserList = new ArrayList<String>();
		remedyUserQuery="SELECT Login_Name FROM User_X WITH (NOLOCK)";

		try {
			connection = dataSourceRemedy.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(remedyUserQuery);
			while (resultSet.next()) {
				remedyUserList.add(resultSet.getString(1));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return remedyUserList;
	}
	
	public Map<String, List<?>> getAllRemedyUser() throws NamingException, ParseException {

		LOGGER.info("Inside getAllRemedyUser()");
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String remedyUserQuery="Select Login_Name as 'Remedy ID' ,Full_Name AS 'Full Name'"
				+", ISNULL(Email_Address,'') AS 'Email Address'"
				+" from user_x with (nolock) where login_name like 'cts-%'";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> remedyUserMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceRemedy.getConnection();			
			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(remedyUserQuery);
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}

				reportList.add(cellList);
			}
			remedyUserMap.put(DashboardConstants.COLUMN_NAMES,
					reportDescriptionList);
			remedyUserMap.put(DashboardConstants.COLUMN_VALUES,
					reportList);

		}catch(SQLException sqlException){
			LOGGER.error(sqlException.getMessage(),sqlException);
		}catch(Exception e){
			LOGGER.error(e.getMessage(),e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				LOGGER.error(e.getMessage(),e);
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				LOGGER.error(e.getMessage(),e);
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				LOGGER.error(e.getMessage(),e);
			}
		}
		LOGGER.info("Exit generatePSoftData(String agentId,String date)");
		return remedyUserMap;
	}
	
	
	public String getRemedyIDS(String username) throws SQLException {
		// TODO Auto-generated method stub
		Connection connection = null;
		CallableStatement callableStatement, callableStatement1;
		callableStatement = callableStatement1 = null;
		ResultSet resultSet, resultSet1;
		resultSet = resultSet1 = null;
		Statement statement = null;
		String remedyUserQuery="";
		String groupid="";
		List<String> remedyUserList = new ArrayList<String>();
		remedyUserQuery="SELECT Group_List+Computed_Grp_List FROM User_x WITH (NOLOCK) WHERE Login_Name='"+username+"'";
		try {
			connection = dataSourceRemedy.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(remedyUserQuery);
			
			while (resultSet.next()) {
				groupid=resultSet.getString(1);
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return groupid;
	}
}
