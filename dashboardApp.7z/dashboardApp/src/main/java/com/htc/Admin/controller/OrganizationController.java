package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.OrganizatioDAO;
import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;

/**
 * 
 * @author HTC OffShare
 * 
 * Description : Organization page is used to create new client
 *
 */
@Controller
public class OrganizationController {

	@Autowired
	OrganizatioDAO organizationdao;

	@RequestMapping(value = "/Organizations", method = RequestMethod.POST)
	public String getMetricTree(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String metricsTree="";
		List<String> metrics=new ArrayList<String>();
		Map<String,List<String>> userMap = new HashMap<String,List<String>>();
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			try {
				metricsTree = organizationdao.metricAdmin(0);			
				userMap=organizationdao.typeAndStatusDropDown();
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			metrics.add(metricsTree);
			userMap.put(DashboardConstants.JSTREEMAP, metrics);
			request.setAttribute(DashboardConstants.JSTREE, userMap);
			return "Admin/CSD_organization";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}
	@RequestMapping(value = "/metrixLoadContent", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> loadMetricsIDContent(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String treeCodeSelected =(String) request.getParameter("treeid");
		List<String> metrixDataList=new ArrayList<String>();
		metrixDataList=organizationdao.metricContentID(treeCodeSelected);
		return metrixDataList;
	}
	@RequestMapping(value = "/insertorgdata", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getInsertData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String arrayData[] = request.getParameterValues("arraydata[]");
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setParentId(arrayData[5]);
		metricsdto.setType(arrayData[1]);
		metricsdto.setStatus(arrayData[2]);
		metricsdto.setName(arrayData[4]);
		metricsdto.setLabel(arrayData[3]);
		metricsdto.setAbbreviation(arrayData[6]);
		metricsdto.setDescription(arrayData[13]);
		metricsdto.setRemedyGroupId(arrayData[7]);
		metricsdto.setSourceType(arrayData[8]);
		metricsdto.setCretatedAndModifiedBy((String) session.getAttribute("username"));
		try {
			status = organizationdao.setInsertPermissions(metricsdto);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return status;
	}

	@RequestMapping(value = "/deleteOrgData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getDeleteData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		String clientId = request.getParameter("clientID").toString();
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setClientId(clientId);
		try {
			status = organizationdao.setDeletePermissions(metricsdto);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return status;
	}


	@RequestMapping(value = "/updateOrgData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getUpdateData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String arrayData[] = request.getParameterValues("arraydata[]");
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		for(int i=0;i<arrayData.length;i++)
			metricsdto.setClientId(arrayData[0]);
		metricsdto.setParentId(arrayData[5]);
		metricsdto.setType(arrayData[1]);
		metricsdto.setStatus(arrayData[2]);
		metricsdto.setName(arrayData[4]);
		metricsdto.setLabel(arrayData[3]);
		metricsdto.setAbbreviation(arrayData[6]);
		metricsdto.setDescription(arrayData[13]);
		metricsdto.setRemedyGroupId(arrayData[7]);
		metricsdto.setSourceType(arrayData[8]);
		metricsdto.setCretatedAndModifiedBy((String) session.getAttribute("username"));
		try {
			status = organizationdao.setUpdatePermissions(metricsdto);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return status;
	}
	/*
	 * This method is used for displaying phone queue detail post clicking on phone queue
	 * button in Organisation Screen. This method will return phone queue details in json format.
	 */
	@RequestMapping(value = "/PhoneQueueDetail", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> getPhoneQDetails(ModelMap model,
			HttpSession session, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String organisationId = "";
		organisationId = request.getParameter("organisationid"); 
		List<String> phoneQDetails = new ArrayList<String>();
		if (organisationId != null && !("".equals(organisationId))) {
			try {
				phoneQDetails = organizationdao.getPhoneQDetail(organisationId);

			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		}
		return phoneQDetails;
	}

	/*
	 * This method is used for creating new phone queue and also used for editing,updating and deleting the existing phone queue.
	 * This method will return success/failure message post successful execution.
	 */
	@RequestMapping(value = "/PhoneQueueUpdate", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> setPhoneQUpdate(ModelMap model,
			HttpSession session, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String phoneQFlag = request.getParameter("phoneqflag");
		String rowId = request.getParameter("row_id");
		String customerCode = request.getParameter("customer_code");
		String customerType = request.getParameter("customer_type");
		String customer = request.getParameter("customer");
		String purOrgName = request.getParameter("pur_org_name");
		String prmryTwrColor = request.getParameter("primary_tower_color");
		String scndryTwrColor = request.getParameter("secondary_tower_color");
		String flr = request.getParameter("flr");
		String netFlr = request.getParameter("net_flr");
		String dlyBfrAnsPerc = request.getParameter("dly_bfr_ans_perc");
		String dlyBfrAnsInSec = request.getParameter("dly_bfr_ans_in_sec");
		String abdnmntRate = request.getParameter("abandonment_rate");
		String cSat = request.getParameter("csat");
		String mnthlyRprtDlvry = request.getParameter("monthly_report_delivery");
		String hideFromMtd = request.getParameter("hide_from_mtd");
		String totalContacts = request.getParameter("total_contacts");
		String cSatFirstLevel = request.getParameter("csat_1st_level");

		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setRowId(rowId);
		metricsdto.setCustomerCode(customerCode);
		metricsdto.setCustomerType(customerType);
		metricsdto.setCustomer(customer);
		metricsdto.setPurOrgName(purOrgName);
		metricsdto.setPrmryTwrColor(prmryTwrColor);
		metricsdto.setScndryTwrColor(scndryTwrColor);
		metricsdto.setFlr(flr);
		metricsdto.setNetFlr(netFlr);
		metricsdto.setDlyBfrAnsPerc(dlyBfrAnsPerc);
		metricsdto.setDlyBfrAnsInSec(dlyBfrAnsInSec);
		metricsdto.setAbdnmntRate(abdnmntRate);
		metricsdto.setcSat(cSat);
		metricsdto.setMnthlyRprtDlvry(mnthlyRprtDlvry);
		metricsdto.setHideFromMtd(hideFromMtd);
		metricsdto.setTotalContacts(totalContacts);
		metricsdto.setcSatFirstLevel(cSatFirstLevel);

		List<String> phoneQUpdateResult = null;
		if (rowId != null && !("".equals(rowId))) {
			phoneQUpdateResult = new ArrayList<String>();
			try {
				phoneQUpdateResult = organizationdao.updatePhoneQDetail(metricsdto,phoneQFlag);
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		}
		return phoneQUpdateResult;
	}
}
