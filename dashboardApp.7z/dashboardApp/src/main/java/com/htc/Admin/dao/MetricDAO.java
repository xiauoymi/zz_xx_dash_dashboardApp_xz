package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;



public class MetricDAO {

	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public String setMetricsTree() throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_get_Metrics_Tree;
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				builder.append("{id:'" + resultSet.getString("Child_ID")+"',parent:'");
				if(resultSet.getString("Parent_ID").equalsIgnoreCase("0"))
					builder.append("#',text:");
				else
					builder.append(resultSet.getString("Parent_ID")+"',text:");
				String SDM_org_code=resultSet.getString("Label").replace("\n", " ");
				SDM_org_code=SDM_org_code.replace("'", "");
				builder.append("'"+SDM_org_code+"',type:");
				builder.append("'"+resultSet.getString("Type")+"'},");
			}

		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}

	public String categoryTree() throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_get_metric_groups;
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				builder.append("{id:" + resultSet.getInt("Child_ID")+",parent:");
				if(resultSet.getInt("Parent_ID")==0)
				{
					builder.append("'#',text:");
				}
				else
					builder.append(resultSet.getInt("Parent_ID")+",text:");
				String SDM_org_lbl=resultSet.getString("Label").replace("\n", " ");
				SDM_org_lbl=SDM_org_lbl.replace("'", "");
				builder.append("'"+SDM_org_lbl+"'},");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}
	public List<String> csdMetricContentID(String treeCodeSelected) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> metrixDataList=new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_get_metrics_ByID;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, treeCodeSelected);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				for (int i = 0; i < columnCount; i++) {
					metrixDataList.add(resultSet.getString(reportDescriptionList.get(i)));
				}
			}

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return metrixDataList;
	}

	public List<String> csdMetricGroupContentID(String treeCodeSelected) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> metrixDataList=new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_get_metric_groups_ByID;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, treeCodeSelected);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				for (int i = 0; i < columnCount; i++) {
					metrixDataList.add(resultSet.getString(reportDescriptionList.get(i)));
				}
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return metrixDataList;

	}

	public Map<String,List<String>> typeAndStatusDropDown() throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement,callableStatement1,callableStatement2,callableStatement3 ;
		callableStatement=callableStatement1=callableStatement2=callableStatement3=null;
		ResultSet  resultSet,resultSet1,resultSet2,resultSet3;
		resultSet= resultSet1 =resultSet2=resultSet3= null;
		String metricTypeQuery,metricStatusQuery,metricGroupTypeQuery,metricGroupStatusQuery;
		metricTypeQuery=metricStatusQuery=metricGroupTypeQuery=metricGroupStatusQuery="";
		List<String> typeMetricLablel = new ArrayList<String>();
		List<String> typeMetricValue = new ArrayList<String>();
		List<String> statusMetricLabel = new ArrayList<String>();
		List<String> statusMetricValue = new ArrayList<String>();
		List<String> typeLablelMetricGroup = new ArrayList<String>();
		List<String> typeValueMetricGroup = new ArrayList<String>();
		List<String> statusLabelMetricGroup = new ArrayList<String>();
		List<String> statusValueMetricGroup = new ArrayList<String>();
		Map<String,List<String>> userMap = new HashMap<String,List<String>>();

		try {
			connection = dataSource.getConnection();
			metricTypeQuery =StoredProcedureConstants.sp_get_Type_METRIC;
			callableStatement = connection.prepareCall(metricTypeQuery);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				typeMetricLablel.add(resultSet.getString(1));
				typeMetricValue.add(resultSet.getString(2));
			}
			metricStatusQuery =StoredProcedureConstants.sp_get_Status_METRIC;
			callableStatement1 = connection.prepareCall(metricStatusQuery);
			resultSet1 = callableStatement1.executeQuery();
			while(resultSet1.next()){
				statusMetricLabel.add(resultSet1.getString(1));
				statusMetricValue.add(resultSet1.getString(2));
			}
			metricGroupTypeQuery =StoredProcedureConstants.sp_get_Type_METRIC_GROUP;
			callableStatement2 = connection.prepareCall(metricGroupTypeQuery);
			resultSet2 = callableStatement2.executeQuery();
			while(resultSet2.next()){
				typeLablelMetricGroup.add(resultSet2.getString(1));
				typeValueMetricGroup.add(resultSet2.getString(2));
			}
			metricGroupStatusQuery =StoredProcedureConstants.sp_get_Status_METRIC_GROUP;
			callableStatement3 = connection.prepareCall(metricGroupStatusQuery);
			resultSet3 = callableStatement3.executeQuery();
			while(resultSet3.next()){
				statusLabelMetricGroup.add(resultSet3.getString(1));
				statusValueMetricGroup.add(resultSet3.getString(2));
			}
			userMap.put(DashboardConstants.METRICTYPEDROPDOWN, typeMetricLablel);
			userMap.put(DashboardConstants.METRICTYPEDROPDOWNVALUE, typeMetricValue);
			userMap.put(DashboardConstants.METRICSTATUSDROPDOWN, statusMetricLabel);
			userMap.put(DashboardConstants.METRICSTATUSDROPDOWNVALUE, statusMetricValue);
			userMap.put(DashboardConstants.METRICGROUPTYPEDROPDOWN, typeLablelMetricGroup);
			userMap.put(DashboardConstants.METRICGROUPTYPEDROPDOWNVALUE, typeValueMetricGroup);
			userMap.put(DashboardConstants.METRICGROUPSTATUSDROPDOWN, statusLabelMetricGroup);
			userMap.put(DashboardConstants.METRICGROUPSTATUSDROPDOWNVALUE, statusValueMetricGroup);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet2)
					resultSet2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet3)
					resultSet3.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement1)
					callableStatement1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement2)
					callableStatement2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement3)
					callableStatement3.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userMap;
	}

	public List<String> setInsertMetricGroupPermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metric_groups_DML_INSERT;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getParentId());
			callableStatement.setString(3, metricAdmindto.getName());
			callableStatement.setString(4, metricAdmindto.getLabel());
			callableStatement.setString(5, metricAdmindto.getDescription());
			callableStatement.setString(6, metricAdmindto.getType());
			callableStatement.setString(7, metricAdmindto.getStatus());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}

		}finally {

			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setMetricGroupDeletePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metric_groups_DML_DELETE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setMetricGroupUpdatePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metric_groups_DML_UPDATE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			callableStatement.setString(3, metricAdmindto.getParentId());
			callableStatement.setString(4, metricAdmindto.getName());
			callableStatement.setString(5, metricAdmindto.getLabel());
			callableStatement.setString(6, metricAdmindto.getDescription());
			callableStatement.setString(7, metricAdmindto.getType());
			callableStatement.setString(8, metricAdmindto.getStatus());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}

		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setInsertMetricPermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metrics_DML_INSERT;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getParentMetricId());
			callableStatement.setString(3, metricAdmindto.getType());
			callableStatement.setString(4, metricAdmindto.getName());
			callableStatement.setString(5, metricAdmindto.getLabel());
			callableStatement.setString(6, metricAdmindto.getDescription());
			callableStatement.setString(7, metricAdmindto.getMetricFormula());
			callableStatement.setString(8, metricAdmindto.getStatus());
			callableStatement.setString(9, metricAdmindto.getParentCategoryId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}
	public List<String> setUpdatePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metrics_DML_UPDATE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			callableStatement.setString(3, metricAdmindto.getParentMetricId());
			callableStatement.setString(4, metricAdmindto.getType());
			callableStatement.setString(5, metricAdmindto.getName());
			callableStatement.setString(6, metricAdmindto.getLabel());
			callableStatement.setString(7, metricAdmindto.getDescription());
			callableStatement.setString(8, metricAdmindto.getMetricFormula());
			callableStatement.setString(9, metricAdmindto.getStatus());
			callableStatement.setString(10, metricAdmindto.getParentCategoryId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}

		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setMetricDeletePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_metrics_DML_DELETE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public Map<String, List<String>> mcat_ByMID(String treeCodeSelected) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> mcatValues=new ArrayList<String>();
		List<String> mcatText=new ArrayList<String>();
		Map<String,List<String>> mcatList=new HashMap<String,List<String>>();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_get_mCat_BymID;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, treeCodeSelected);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				mcatValues.add(resultSet.getString(1));
				mcatText.add(resultSet.getString(2));
			}

			mcatList.put(DashboardConstants.MCATVALUES,  mcatText);
			mcatList.put(DashboardConstants.MCATTEXT, mcatValues);

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mcatList;
	}
}
