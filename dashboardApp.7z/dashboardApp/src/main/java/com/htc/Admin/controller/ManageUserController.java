package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.ManageUserDAO;
import com.htc.Admin.dto.ManageUserDTO;
import com.htc.utility.DashboardConstants;

@Controller
public class ManageUserController {

	private static final Logger logger = Logger
			.getLogger(ManageUserController.class);
	@Autowired
	private ManageUserDAO manageUserDAO;

	/*
	 * This method is used for displaying user management Screen if session is
	 * active otherwise unauthorize access screen will display. Available users
	 * will be display in screen and also list of groups will display in
	 * "Groups Membership" drop down field post clicking on create user hyper
	 * link.
	 */
	@RequestMapping(value = "/Configuration", method = RequestMethod.POST)
	public String getManageUser(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");

		if (userName != null && !("".equals(userName))) {
			List<String> groupNamleList = new ArrayList<String>();
			List<List<String>> userDetailList = new ArrayList<List<String>>();
			try {
				groupNamleList = manageUserDAO.getGroupName();
				userDetailList = manageUserDAO.getUserDetail();
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			if (groupNamleList != null && !groupNamleList.isEmpty()) {
				session.setAttribute(DashboardConstants.EXTERNAL_GROUP_NAMES,
						groupNamleList);
			}
			if (userDetailList != null && !userDetailList.isEmpty()) {
				session.setAttribute(DashboardConstants.EXTERNAL_USER_DETAILS,
						userDetailList);
			}
			return "Admin/ManageUser";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

	/*
	 * This method is used for creating a new user post clicking on save button
	 * in create user screen. This method will return success/failure message
	 * post execution.
	 */
	@RequestMapping(value = "/createNewUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> setNewUser(ModelMap model, HttpSession session,
			HttpServletRequest request, HttpServletResponse response)
					throws Exception {

		String userName = "";
		String firstName = "";
		String middleName = "";
		String lastName = "";
		String email = "";
		String password = "";
		String userID = "";
		String userType = "";
		String confirmPassword = "";
		String group = "";

		userName = (String) session.getAttribute("username");
		firstName = request.getParameter("firstname");
		middleName = request.getParameter("middlename");
		lastName = request.getParameter("lastname");
		email = request.getParameter("email");
		password = request.getParameter("password");
		userID = request.getParameter("userid");
		userType = request.getParameter("usertype");
		confirmPassword = request.getParameter("confirmpassword");
		group = request.getParameter("group");

		List<String> resultMsgList = new ArrayList<String>();
		ManageUserDTO manageUserDTO = new ManageUserDTO();

		manageUserDTO.setFirstName(firstName);
		manageUserDTO.setMiddleName(middleName);
		manageUserDTO.setLastName(lastName);
		manageUserDTO.setEmail(email);
		manageUserDTO.setPassword(password);
		manageUserDTO.setUserID(userID);
		manageUserDTO.setUserType(userType);
		manageUserDTO.setConfirmPassword(confirmPassword);
		manageUserDTO.setGroup(group);

		try {
			resultMsgList = manageUserDAO
					.createNewUser(manageUserDTO, userName);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return resultMsgList;
	}

	/*
	 * This method is used for displaying user detail post clicking on edit
	 * button in user management Screen. This method will return single external
	 * user details in json format.
	 */
	@RequestMapping(value = "/editUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Map<String, List<List<String>>> getUserDetails(ModelMap model,
			HttpSession session, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String userId = "";
		userId = request.getParameter("userid");
		Map<String, List<List<String>>> userDetailList = new HashMap<String, List<List<String>>>();
		try {
			userDetailList = manageUserDAO.editUser(userId);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return userDetailList;
	}

	/*
	 * This method is used for updating the existing user post clicking on
	 * update button in edit screen. This method will return success/failure
	 * message post execution.
	 */
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> setUpdateUser(ModelMap model, HttpSession session,
			HttpServletRequest request, HttpServletResponse response)
					throws Exception {

		String firstName = "";
		String middleName = "";
		String lastName = "";
		String email = "";
		String userID = "";

		String userName = (String) session.getAttribute("username");
		firstName = request.getParameter("firstname");
		middleName = request.getParameter("middlename");
		lastName = request.getParameter("lastname");
		email = request.getParameter("email");
		userID = request.getParameter("userid");

		ManageUserDTO manageUserDTO = new ManageUserDTO();
		List<String> resultMsg = new ArrayList<String>();
		manageUserDTO.setFirstName(firstName);
		manageUserDTO.setMiddleName(middleName);
		manageUserDTO.setLastName(lastName);
		manageUserDTO.setEmail(email);
		manageUserDTO.setUserID(userID);

		try {
			resultMsg = manageUserDAO.updateUser(manageUserDTO, userName);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return resultMsg;
	}

	/*
	 * This method is used for delete the existing user. This method will return
	 * success/failure message post execution.
	 */
	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> setDeleteUser(ModelMap model, HttpSession session,
			HttpServletRequest request, HttpServletResponse response)
					throws Exception {

		String userID = "";
		userID = request.getParameter("userid");

		List<String> resultMsg = new ArrayList<String>();
		ManageUserDTO manageUserDTO = new ManageUserDTO();
		manageUserDTO.setUserID(userID);

		try {
			resultMsg = manageUserDAO.deleteUser(manageUserDTO);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return resultMsg;
	}

}
