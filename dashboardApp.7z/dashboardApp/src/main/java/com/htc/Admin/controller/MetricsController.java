package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.MetricDAO;
import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;

/**
 * 
 * @author Htc Offshore
 * Description: metrics pages to add new metrics and 
 * cateogires for new clients. and can find each metric metric information for every client
 */
@Controller
public class MetricsController {


	private static final Logger logger = Logger
			.getLogger(MetricsController.class);

	@Autowired
	MetricDAO metricDAO;

	@RequestMapping(value = "/Metrics", method = RequestMethod.POST)
	public String getMetricTree(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String metricsTree="";
		String categoryTree="";
		String userName ="";
		List<String> metrics=new ArrayList<String>();
		Map<String,List<String>> typeAndDropDown = new HashMap<String,List<String>>();
		userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			try {

				metricsTree = metricDAO.setMetricsTree();
				logger.info("metricsTree--"+metricsTree);
				categoryTree=   metricDAO.categoryTree();
				logger.info("categoryTree--"+categoryTree);
				typeAndDropDown=metricDAO.typeAndStatusDropDown();
				logger.info("typeAndStatusDropDown--"+typeAndDropDown);

			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			metrics.add(metricsTree);
			metrics.add(categoryTree);
			typeAndDropDown.put(DashboardConstants.JSTREEMAP, metrics);
			request.setAttribute(DashboardConstants.JSTREE, typeAndDropDown);
			return "Admin/CSD_Metrics";
		}else{
			return "common/UnAuthoriseAccess";
		}


	}

	@RequestMapping(value = "/csdMetricLoadContent", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public Map<String, List<String>> loadMetricsIDContent(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		String treeCodeSelected =(String) request.getParameter("treeid");
		List<String> offeringDataList=new ArrayList<String>();
		Map<String, List<String>> categoryList=new HashMap<String, List<String>>();
		try {
			offeringDataList=metricDAO.csdMetricContentID(treeCodeSelected);
			logger.info("onClick of jstree Loading Parent metric Content-"+offeringDataList);
			categoryList=metricDAO.mcat_ByMID(treeCodeSelected);
			logger.info("onClick of jstree loading Parent category content-"+offeringDataList);
		}catch(Exception e){
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		categoryList.put(DashboardConstants.MBYIDANDMCATBYID, offeringDataList);
		return categoryList;

	}

	@RequestMapping(value = "/csdMetricGroupLoadContent", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> loadMetricsGroupIDContent(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		String treeCodeSelected =(String) request.getParameter("treeid");
		List<String> offeringDataList=new ArrayList<String>();
		try {
			offeringDataList=metricDAO.csdMetricGroupContentID(treeCodeSelected);
			logger.info("onClick of jstree loading Parent category content="+offeringDataList);

		}catch(Exception e){
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return offeringDataList;

	}

	@RequestMapping(value = "/insertMetricGroupdata", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getInsertData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId( session.getAttribute("username").toString());	
		metricsdto.setParentId(request.getParameter("ct-parent-cat"));
		metricsdto.setType(request.getParameter("ct-option-type-common"));
		metricsdto.setStatus(request.getParameter("ct-metrics-option-status"));
		metricsdto.setName(request.getParameter("ct-name"));
		metricsdto.setLabel(request.getParameter("ct-label"));
		metricsdto.setDescription(request.getParameter("ct-desc"));
		try {
			status = metricDAO.setInsertMetricGroupPermissions(metricsdto);
			logger.info("inserted metricgroup data into db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}

	@RequestMapping(value = "/deleteMetricGroupData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getDeleteData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		String clientId = request.getParameter("clientID").toString();
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId((String) session.getAttribute("username"));
		metricsdto.setClientId(clientId);
		try {
			status = metricDAO.setMetricGroupDeletePermissions(metricsdto);
			logger.info("Deleted metricgroup data from  db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}
	@RequestMapping(value = "/MetricGroupupdateData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getUpdateData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setClientId(request.getParameter("p_metrics_id"));
		metricsdto.setUserId((String) session.getAttribute("username"));
		metricsdto.setParentId(request.getParameter("ct-parent-cat"));
		metricsdto.setType(request.getParameter("ct-option-type-common"));
		metricsdto.setStatus(request.getParameter("ct-metrics-option-status"));
		metricsdto.setName(request.getParameter("ct-name"));
		metricsdto.setLabel(request.getParameter("ct-label"));
		metricsdto.setDescription(request.getParameter("ct-desc"));
		try {

			status = metricDAO.setMetricGroupUpdatePermissions(metricsdto);
			logger.info("Updated metricgroup data into db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		return status;

	}

	@RequestMapping(value = "/insertMetricdata", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getInsertMetricData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId((String) session.getAttribute("username"));	
		metricsdto.setType(request.getParameter("ct-option-type-common"));
		metricsdto.setStatus(request.getParameter("ct-metrics-option-status"));
		metricsdto.setName(request.getParameter("ct-name"));
		metricsdto.setLabel(request.getParameter("ct-label"));
		metricsdto.setParentMetricId(request.getParameter("parentMetric"));
		metricsdto.setParentCategoryId(request.getParameter("ct-parent-cat"));
		metricsdto.setMetricFormula(request.getParameter("metricFormula"));
		metricsdto.setDescription(request.getParameter("ct-desc"));
		metricsdto.setCretatedAndModifiedBy((String) session.getAttribute("username"));
		try {
			status = metricDAO.setInsertMetricPermissions(metricsdto);
			logger.info("inserted metric data into db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}
	@RequestMapping(value = "/MetricupdateData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getMetricUpdateData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setClientId(request.getParameter("p_metrics_id"));
		metricsdto.setUserId((String) session.getAttribute("username"));	
		metricsdto.setType(request.getParameter("ct-option-type-common"));
		metricsdto.setStatus(request.getParameter("ct-metrics-option-status"));
		metricsdto.setName(request.getParameter("ct-name"));
		metricsdto.setLabel(request.getParameter("ct-label"));
		metricsdto.setParentMetricId(request.getParameter("parentMetric"));
		metricsdto.setParentCategoryId(request.getParameter("ct-parent-cat"));
		metricsdto.setMetricFormula(request.getParameter("metricFormula"));
		metricsdto.setDescription(request.getParameter("ct-desc"));
		try {
			status = metricDAO.setUpdatePermissions(metricsdto);
			logger.info("Updated metric data into db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}


	@RequestMapping(value = "/deleteMetricData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getMetricDeleteData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String clientId = request.getParameter("clientID").toString();
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId((String) session.getAttribute("username"));
		metricsdto.setClientId(clientId);
		try {
			status = metricDAO.setMetricDeletePermissions(metricsdto);
			logger.info("Deleted metric data from  db are not status-"+status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}

}
