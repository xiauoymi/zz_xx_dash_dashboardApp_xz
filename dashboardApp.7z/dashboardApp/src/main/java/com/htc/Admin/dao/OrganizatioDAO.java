package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

public class OrganizatioDAO {


	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public String metricAdmin(int clientList) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String query = "";
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_get_Organizations_Tree;
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				builder.append("{id:" + resultSet.getInt(1)+",parent:");
				if(resultSet.getInt(2)==0)
				{
					builder.append("'#',text:");
				}
				else
					builder.append(resultSet.getInt(2)+",text:");
				String SDM_org_lbl=resultSet.getString(3).replace("\n", " ");
				SDM_org_lbl=SDM_org_lbl.replace("'", "");
				builder.append("'"+SDM_org_lbl+"'},");
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}

	public Map<String,List<String>> typeAndStatusDropDown() throws SQLException, NamingException {
		Connection connection = null;
		Statement  statement = null;
		ResultSet  resultSet,resultSet1;
		resultSet= resultSet1 = null;
		String query,query1;
		query=query1="";
		List<String> typeLablel = new ArrayList<String>();
		List<String> typeValue = new ArrayList<String>();
		List<String> statusLabel = new ArrayList<String>();
		List<String> statusValue = new ArrayList<String>();
		Map<String,List<String>> userMap = new HashMap<String,List<String>>();
		query=StoredProcedureConstants.sp_get_Type;
		query1=StoredProcedureConstants.sp_get_Status;
		try {
			connection = dataSource.getConnection();
			statement  = connection.createStatement();
			resultSet  = statement.executeQuery(query);
			while(resultSet.next()){
				typeLablel.add(resultSet.getString(1));
				typeValue.add(resultSet.getString(2));
			}
			resultSet1  = statement.executeQuery(query1);
			while(resultSet1.next()){
				statusLabel.add(resultSet1.getString(1));
				statusValue.add(resultSet1.getString(2));
			}
			userMap.put(DashboardConstants.TYPEDROPDOWN, typeLablel);
			userMap.put(DashboardConstants.TYPEDROPDOWNVALUE, typeValue);
			userMap.put(DashboardConstants.STATUSDROPDOWN, statusLabel);
			userMap.put(DashboardConstants.STATUSDROPDOWNVALUE, statusValue);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}			
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userMap;
	}

	public List metricContentID(String treeCodeSelected) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> metrixDataList=new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_Get_Organization_By_ID;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, treeCodeSelected);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				for (int i = 0; i < columnCount; i++) {
					metrixDataList.add(resultSet.getString(reportDescriptionList.get(i)));
				}
			}			

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return metrixDataList;		
	}

	public List<String> setInsertPermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_organizations_DML_INSERT;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getParentId());
			callableStatement.setString(2, metricAdmindto.getType());
			callableStatement.setString(3, metricAdmindto.getStatus());
			callableStatement.setString(4, metricAdmindto.getName());
			callableStatement.setString(5, metricAdmindto.getLabel());
			callableStatement.setString(6, metricAdmindto.getAbbreviation());
			callableStatement.setString(7, metricAdmindto.getDescription());
			callableStatement.setString(8, metricAdmindto.getRemedyGroupId());
			callableStatement.setString(9, metricAdmindto.getSourceType());
			callableStatement.setString(10, metricAdmindto.getCretatedAndModifiedBy());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}

		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setDeletePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_organizations_DML_DELETE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getClientId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}

	public List<String> setUpdatePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_organizations_DML_UPDATE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getClientId());
			callableStatement.setString(2, metricAdmindto.getParentId());
			callableStatement.setString(3, metricAdmindto.getType());
			callableStatement.setString(4, metricAdmindto.getStatus());
			callableStatement.setString(5, metricAdmindto.getName());
			callableStatement.setString(6, metricAdmindto.getLabel());
			callableStatement.setString(7, metricAdmindto.getAbbreviation());
			callableStatement.setString(8, metricAdmindto.getDescription());
			callableStatement.setString(9, metricAdmindto.getRemedyGroupId());
			callableStatement.setString(10, metricAdmindto.getSourceType());
			callableStatement.setString(11, metricAdmindto.getCretatedAndModifiedBy());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}
	/*
	 * This method is used for getting the phone queue detail.
	 * This method will take only one argument i.e organisation id. This
	 * method will return List type value i.e. phoneQDetailList.
	 */
	public List<String> getPhoneQDetail(String organisationId)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		ResultSetMetaData rsmd = null;

		List<String> phoneQDetailList = new ArrayList<String>();
		String phoneQDetailQuery = StoredProcedureConstants.sp_htc_get_SDM_SDCustomerSLA_ByID;

		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(phoneQDetailQuery);
			callableStatement.setString(1, organisationId);
			resultSet = callableStatement.executeQuery();
			rsmd = resultSet.getMetaData(); 

			while (resultSet.next()){
				int totalColumns = rsmd.getColumnCount();
				String value = "";
				for(int i=1 ; i <= totalColumns ; i++){
					if(null == resultSet.getString(i)){
						value = "";
					}else{
						value = resultSet.getString(i);
					}
					phoneQDetailList.add(value);
				}
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return phoneQDetailList;
	}

	/*
	 * This method is used for creating new phone queue and also used for editing,updating and deleting the existing phone queue.
	 * This method will take only two arguments i.e MetricAdminDTO object and phoneQFlag. This
	 * method will return List type value i.e. phoneQUpdateList.
	 */
	public List<String> updatePhoneQDetail( MetricAdminDTO metricsdto,String phoneQFlag)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		List<String> phoneQUpdateList = null;
		String phoneQUpdateQuery = StoredProcedureConstants.sp_htc_SDM_SDCustomerSLA_DML;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(phoneQUpdateQuery);
			callableStatement.setString(1, phoneQFlag);
			callableStatement.setString(2, metricsdto.getRowId());
			callableStatement.setString(3, metricsdto.getCustomerCode());
			callableStatement.setString(4, metricsdto.getCustomerType());
			callableStatement.setString(5, metricsdto.getCustomer());
			callableStatement.setString(6, metricsdto.getPurOrgName());
			callableStatement.setString(7, metricsdto.getPrmryTwrColor());
			callableStatement.setString(8, metricsdto.getScndryTwrColor());
			callableStatement.setString(9, metricsdto.getFlr());
			callableStatement.setString(10, metricsdto.getNetFlr());
			callableStatement.setString(11, metricsdto.getDlyBfrAnsPerc());
			callableStatement.setString(12, metricsdto.getDlyBfrAnsInSec());
			callableStatement.setString(13, metricsdto.getAbdnmntRate());
			callableStatement.setString(14, metricsdto.getcSat());
			callableStatement.setString(15, metricsdto.getMnthlyRprtDlvry());
			callableStatement.setString(16, metricsdto.getHideFromMtd());
			callableStatement.setString(17, metricsdto.getTotalContacts());
			callableStatement.setString(18, metricsdto.getcSatFirstLevel());
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()){
				phoneQUpdateList = new ArrayList<String>();
				phoneQUpdateList.add(resultSet.getString(1));
				phoneQUpdateList.add(resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return phoneQUpdateList;
	}
}
