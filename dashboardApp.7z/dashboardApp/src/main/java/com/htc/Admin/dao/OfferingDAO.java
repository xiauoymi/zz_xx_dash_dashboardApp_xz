package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;
import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

public class OfferingDAO {
	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public String metricAdminOffering(int clientList) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String query = "";
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			query ="{call sp_get_Billing_Tree }";
			callableStatement = connection.prepareCall(query);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				builder.append("{id:" + resultSet.getInt("Child")+",parent:");
				if(resultSet.getString("Parent")==null)
					builder.append("'#',text:");
				else
					builder.append(resultSet.getInt("Parent")+",text:");
				String SDM_org_code=resultSet.getString("Label");
				SDM_org_code=SDM_org_code.replace("'", "");
				builder.append("'"+SDM_org_code+"'},");
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}

	public Map<String,List<String>> getOfferTypeAndStatusDropDown() throws SQLException, NamingException {
		Connection connection = null;
		Statement  statement = null;
		ResultSet  resultSet,resultSet1;
		resultSet= resultSet1 = null;
		String query,query1;
		query=query1="";
		List<String> typeLablel = new ArrayList<String>();
		List<String> typeValue = new ArrayList<String>();
		List<String> statusLabel = new ArrayList<String>();
		List<String> statusValue = new ArrayList<String>();
		Map<String,List<String>> userMap = new HashMap<String,List<String>>();
		query=StoredProcedureConstants.sp_get_Type_1;;
		query1=StoredProcedureConstants.sp_get_Status_1;
		try {
			connection = dataSource.getConnection();
			statement  = connection.createStatement();
			resultSet  = statement.executeQuery(query);
			while(resultSet.next()){
				typeLablel.add(resultSet.getString(1));
				typeValue.add(resultSet.getString(2));
			}
			resultSet1  = statement.executeQuery(query1);
			while(resultSet1.next()){
				statusLabel.add(resultSet1.getString(1));
				statusValue.add(resultSet1.getString(2));
			}
			userMap.put(DashboardConstants.OFFERTYPEDROPDOWN, typeLablel);
			userMap.put(DashboardConstants.OFFERTYPEDROPDOWNVALUE, typeValue);
			userMap.put(DashboardConstants.OFFERSTATUSDROPDOWN, statusLabel);
			userMap.put(DashboardConstants.OFFERSTATUSDROPDOWNVALUE, statusValue);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}			
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userMap;
	}

	@SuppressWarnings("rawtypes")
	public List offeringContentID(String treeCodeSelected) throws SQLException {
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;
		String query = "";
		@SuppressWarnings("unused")
		List reportList = new ArrayList();
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> metrixDataList=new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			query =StoredProcedureConstants.sp_get_billing_ByID;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, treeCodeSelected);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}
			while (resultSet.next()) {
				for (int i = 0; i < columnCount; i++) {
					metrixDataList.add(resultSet.getString(reportDescriptionList.get(i)));
				}
			}

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return metrixDataList;		
	}


	public List<String> setOfferInsertPermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_billing_DML_INSERT;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getName());
			callableStatement.setString(3, metricAdmindto.getLabel());
			callableStatement.setString(4, metricAdmindto.getDescription());
			callableStatement.setString(5, metricAdmindto.getParentBilling());
			callableStatement.setString(6, metricAdmindto.getType());
			callableStatement.setString(7, metricAdmindto.getStatus());
			callableStatement.setString(8, metricAdmindto.getParentId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}

		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}
	public List<String> setOfferUpdatePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_billing_DML_UPDATE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			callableStatement.setString(3, metricAdmindto.getName());
			callableStatement.setString(4, metricAdmindto.getLabel());
			callableStatement.setString(5, metricAdmindto.getDescription());
			callableStatement.setString(6, metricAdmindto.getParentBilling());
			callableStatement.setString(7, metricAdmindto.getType());
			callableStatement.setString(8, metricAdmindto.getStatus());
			callableStatement.setString(9, metricAdmindto.getParentId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}
	public List<String> setOfferDeletePermissions(MetricAdminDTO metricAdmindto) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet  resultSet = null;
		String query = StoredProcedureConstants.sp_billing_DML_DELETE;
		List<String> resultMsg=new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, metricAdmindto.getUserId());
			callableStatement.setString(2, metricAdmindto.getClientId());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				resultMsg .add( resultSet.getString(1));
				resultMsg .add( resultSet.getString(2));
			}
		}finally {
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultMsg;
	}
}
