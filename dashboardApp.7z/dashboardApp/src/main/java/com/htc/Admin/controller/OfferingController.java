package com.htc.Admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.Admin.dao.OfferingDAO;
import com.htc.Admin.dao.OrganizatioDAO;
import com.htc.Admin.dto.MetricAdminDTO;
import com.htc.utility.DashboardConstants;
/**
 * 
 *@author Htc Offshore
 * 
 * Description: Offering pages are used to add Billing and details of client
 *
 */
@Controller
public class OfferingController {


	private static final Logger logger = Logger
			.getLogger(OfferingController.class);

	@Autowired
	OfferingDAO offeringDAO;

	@Autowired
	OrganizatioDAO organizationdao;

	@RequestMapping(value = "/Offering", method = RequestMethod.POST)
	public String getMetricTree(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String metricsTree="";
		String metricsTreeOffering="";
		List<String> metrics=new ArrayList<String>();
		Map<String,List<String>> offerTypeAndStatus = new HashMap<String,List<String>>();
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			try {
				metricsTree = organizationdao.metricAdmin(0);		
				metricsTreeOffering = offeringDAO.metricAdminOffering(0);
				offerTypeAndStatus=offeringDAO.getOfferTypeAndStatusDropDown();
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			metrics.add(metricsTreeOffering);
			metrics.add(metricsTree);
			offerTypeAndStatus.put(DashboardConstants.JSTREEMAP, metrics);
			request.setAttribute(DashboardConstants.JSTREE, offerTypeAndStatus);
			return "Admin/CSD_Offering";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/offeringLoadContent", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> loadMetricsIDContent(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String treeCodeSelected =(String) request.getParameter("treeid");
		List<String> offeringDataList=new ArrayList<String>();
		try {
			offeringDataList=offeringDAO.offeringContentID(treeCodeSelected);
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}
		return offeringDataList;
	}
	@RequestMapping(value = "/offeringinsertorgdata", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getInsertData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String arrayData[] = request.getParameterValues("arraydata[]");
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId((String) session.getAttribute("username"));	
		metricsdto.setParentId(arrayData[5]);
		metricsdto.setType(arrayData[1]);
		metricsdto.setStatus(arrayData[2]);
		metricsdto.setName(arrayData[4]);
		metricsdto.setLabel(arrayData[3]);
		metricsdto.setParentBilling(arrayData[6]);
		metricsdto.setDescription(arrayData[11]);
		metricsdto.setCretatedAndModifiedBy((String) session.getAttribute("username"));
		try {
			status = offeringDAO.setOfferInsertPermissions(metricsdto);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}

	@RequestMapping(value = "/offeringupdateOrgData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getUpdateData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {

		String arrayData[] = request.getParameterValues("arraydata[]");
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setClientId(arrayData[0]);
		metricsdto.setUserId((String) session.getAttribute("username"));
		metricsdto.setParentId(arrayData[5]);
		metricsdto.setType(arrayData[1]);
		metricsdto.setStatus(arrayData[2]);
		metricsdto.setName(arrayData[4]);
		metricsdto.setLabel(arrayData[3]);
		metricsdto.setParentBilling(arrayData[6]);
		metricsdto.setDescription(arrayData[11]);
		try {
			status = offeringDAO.setOfferUpdatePermissions(metricsdto);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}


	@RequestMapping(value = "/offerdeleteOrgData", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getDeleteData(ModelMap model, HttpSession session, HttpServletRequest request) throws Exception {
		String clientId = request.getParameter("clientID").toString();
		List<String> status=new ArrayList<>();
		MetricAdminDTO metricsdto=new MetricAdminDTO();
		metricsdto.setUserId((String) session.getAttribute("username"));
		metricsdto.setClientId(clientId);
		try {
			status = offeringDAO.setOfferDeletePermissions(metricsdto);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
		return status;
	}

}
