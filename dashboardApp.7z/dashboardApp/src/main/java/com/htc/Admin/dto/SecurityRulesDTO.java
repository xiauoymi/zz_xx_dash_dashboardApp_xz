package com.htc.Admin.dto;

public class SecurityRulesDTO {

	private String reportName ;
	private String appliesTo;
	private String userOrGroup;
	private String userType ;
	private String access ;


	public void setAccess(String access) {
		this.access = access;
	}

	public String getAccess() {
		return access;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReportName() {
		return reportName;
	}

	public void setAppliesTo(String appliesTo) {
		this.appliesTo = appliesTo;
	}

	public String getAppliesTo() {
		return appliesTo;
	}

	public void setUserOrGroup(String userOrGroup) {
		this.userOrGroup = userOrGroup;
	}

	public String getUserOrGroup() {
		return userOrGroup;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}

}






