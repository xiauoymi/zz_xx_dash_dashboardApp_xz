package com.htc.Admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.naming.NamingException;

import org.springframework.stereotype.Repository;

import com.htc.Admin.dto.ManageUserDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

@Repository
public class ManageUserDAO {
	DataSource dataSource;
	public void setDataSourceMetrics(DataSource dataSourceMetrics) {
		this.dataSource = dataSourceMetrics;
	}

	/*
	 * This method is used for getting the External Group names. This method
	 * will not take any arguments. This method will return list type value i.e.
	 * groupNameList.
	 */
	public List<String> getGroupName() throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> groupNameList = new ArrayList<String>();
		String groupNamequery = StoredProcedureConstants.sp_Get_SDM_GroupName_External;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(groupNamequery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				groupNameList.add(resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return groupNameList;
	}

	/*
	 * This method is used for getting the External User names. This method will
	 * not take any arguments. This method will return list of list type value
	 * i.e. userDetailList1.
	 */
	public List<List<String>> getUserDetail() throws SQLException,
	NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> userDetailList = null;
		List<List<String>> userDetailList1 = new ArrayList<List<String>>();
		String ExternalUserNameQuery = StoredProcedureConstants.sp_Get_User_Name_For_External;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(ExternalUserNameQuery);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				userDetailList = new ArrayList<String>();
				userDetailList.add(resultSet.getString(3));
				userDetailList.add(resultSet.getString(2));
				userDetailList.add(resultSet.getString(4));
				userDetailList.add(resultSet.getString(5));
				userDetailList1.add(userDetailList);
				userDetailList = null;
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userDetailList1;
	}

	/*
	 * This method is used for creating a new user. This method will take two
	 * arguments i.e ManageUserDTO object and user name. This method will return
	 * List type value i.e. resultList.
	 */
	public List<String> createNewUser(ManageUserDTO manageUserDTO,
			String userName) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement, callableStatement1;
		callableStatement = callableStatement1 = null;
		ResultSet resultSet, resultSet1;
		resultSet = resultSet1 = null;
		String resultKey = "";
		String resultMsg = "";
		String resultMsg1 = "";
		List<String> userCreateList = new ArrayList<String>();
		List<String> groupAssignList = new ArrayList<String>();
		List<String> resultList = new ArrayList<String>();
		String createUserQuery = StoredProcedureConstants.sp_create_group_user;
		String assignUserToGroupQuery = StoredProcedureConstants.sp_Assign_User_To_Group;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(createUserQuery);
			callableStatement.setString(1, manageUserDTO.getUserID());
			callableStatement.setString(2, manageUserDTO.getPassword());
			callableStatement.setString(3, manageUserDTO.getUserType());
			callableStatement.setString(4, manageUserDTO.getEmail());
			callableStatement.setString(5, manageUserDTO.getFirstName());
			callableStatement.setString(6, manageUserDTO.getMiddleName());
			callableStatement.setString(7, manageUserDTO.getLastName());
			callableStatement.setString(8, userName);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultKey = resultSet.getString(1);
				resultMsg = resultSet.getString(2);
				userCreateList.add(resultKey);
				userCreateList.add(resultMsg);
			}
			if ("0".equals(resultKey)
					&& (!"".equals(manageUserDTO.getGroup()) && null != manageUserDTO
					.getGroup())) {
				callableStatement1 = connection
						.prepareCall(assignUserToGroupQuery);
				callableStatement1.setString(1, manageUserDTO.getUserID());
				callableStatement1.setString(2, manageUserDTO.getGroup());
				callableStatement1.setString(3, userName);
				resultSet1 = callableStatement1.executeQuery();
				while (resultSet1.next()) {
					resultMsg1 = resultSet1.getString(2);
					groupAssignList.add(resultMsg1);
				}
			}
			if (groupAssignList.size() > 0) {
				resultList.add(userCreateList.get(0));
				resultList.add(userCreateList.get(1) + " - "
						+ groupAssignList.get(0));
			} else {
				resultList.add(userCreateList.get(0));
				resultList.add(userCreateList.get(1));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement1)
					callableStatement1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultList;
	}

	/*
	 * This method is used for getting the detail of existing External User.
	 * This method will take only one arguments i.e external user id. This
	 * method will return Map type value i.e. userDetailMap.
	 */
	public Map<String, List<List<String>>> editUser(String userId)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> userDetailList = null;
		List<List<String>> userDetailListOfList = new ArrayList<List<String>>();
		Map<String, List<List<String>>> userDetailMap = new HashMap<String, List<List<String>>>();
		String query = StoredProcedureConstants.sp_Get_External_User_Information_With_Group;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, userId);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				userDetailList = new ArrayList<String>();
				userDetailList.add(resultSet.getString(2));
				userDetailList.add(resultSet.getString(3));
				userDetailList.add(resultSet.getString(4));
				userDetailList.add(resultSet.getString(5));
				userDetailList.add(resultSet.getString(6));
				userDetailList.add(resultSet.getString(7));
				userDetailList.add(resultSet.getString(8));
				userDetailListOfList.add(userDetailList);
				userDetailList = null;
			}
			userDetailMap.put(DashboardConstants.SINGLE_USER_DETAIL,
					userDetailListOfList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userDetailMap;
	}

	/*
	 * This method is used for editing the existing user. This method will take
	 * two arguments i.e ManageUserDTO object and user name. This method will
	 * return List type value i.e. resultList.
	 */
	public List<String> updateUser(ManageUserDTO manageUserDTO, String userName)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String resultKey = "";
		String resultMsg = "";
		List<String> resultList = new ArrayList<String>();
		String updateUserQuery = StoredProcedureConstants.sp_Delete_or_Update_External_User;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(updateUserQuery);
			callableStatement.setString(1, "UPDATE");
			callableStatement.setString(2, manageUserDTO.getUserID());
			callableStatement.setString(3, manageUserDTO.getFirstName());
			callableStatement.setString(4, manageUserDTO.getLastName());
			callableStatement.setString(5, manageUserDTO.getMiddleName());
			callableStatement.setString(6, manageUserDTO.getEmail());
			callableStatement.setString(7, userName);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultKey = resultSet.getString(1);
				resultMsg = resultSet.getString(2);
				resultList.add(resultKey);
				resultList.add(resultMsg);
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultList;
	}

	/*
	 * This method is used for deleting the users. This method will take one
	 * arguments i.e ManageUserDTO object. This method will return List type
	 * value i.e. resultList.
	 */
	public List<String> deleteUser(ManageUserDTO manageUserDTO)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		List<String> resultList = new ArrayList<String>();
		String deleteUserQuery = StoredProcedureConstants.sp_Delete_or_Update_External_User;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(deleteUserQuery);
			callableStatement.setString(1, "DELETE");
			callableStatement.setString(2, manageUserDTO.getUserID());
			callableStatement.setString(3, "");
			callableStatement.setString(4, "");
			callableStatement.setString(5, "");
			callableStatement.setString(6, "");
			callableStatement.setString(7, "");
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultList.add(resultSet.getString(1));
				resultList.add(resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultList;
	}
}
