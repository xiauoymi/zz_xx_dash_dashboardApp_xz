package com.htc.executive.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.utility.QueryBuilder;
import com.htc.utility.StoredProcedureConstants;
import com.htc.executive.dto.ExecutiveHomeDTO;

import java.sql.ResultSetMetaData;



@SuppressWarnings("unused")
public class ExecutiveDashboardDAO {

	DataSource dataSource;
	DataSource savedDataSource;
	
	CallableStatement callableStatement = null;
	Statement statement=null;
	PreparedStatement psstatemet=null;
	


	public void setDataSourceRemedy(DataSource dataSourceRemedy) {
		this.dataSource = dataSourceRemedy;
	}
	
	public void setDataSource(DataSource dataSource) {
		this.savedDataSource = dataSource;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List dashboardExecutiveHomeData(ExecutiveHomeDTO executiveHomeDTO)throws SQLException,NamingException
	{
		Connection connection=null;
		
		ResultSet resultSet=null;
		String query="";
		List opentaskList = new ArrayList();
		List opentaskGroupList = new ArrayList();

		try
		{
			connection= dataSource.getConnection();
			//query=com.htc.utility.QueryBuilder.getOpenTaskByGroup(executiveHomeDTO);
			query = StoredProcedureConstants.Open_Task;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			while (resultSet.next())
			{
				opentaskList.add(resultSet.getString("Assigned_Group"));
				opentaskList.add(resultSet.getInt("Open Task"));
				opentaskGroupList.add(opentaskList);
				opentaskList = new ArrayList();
			}

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return opentaskGroupList;
	}

	public List dashboardExecutiveGroupData(ExecutiveHomeDTO ldto)throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		String query="";
		List opentaskList = new ArrayList();
		List opentaskGroupList = new ArrayList();

		try
		{
			connection= dataSource.getConnection();
			//query=com.htc.utility.QueryBuilder.getExecutiveClientGroupList();
			//psstatemet = connection.prepareStatement(query);
			//psstatemet.setString(1,ldto.getClientName());
			query = StoredProcedureConstants.Group_List_by_User;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1,ldto.getClientName() );
			resultSet = callableStatement.executeQuery();
			//resultSet = psstatemet.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			while (resultSet.next())
			{
				opentaskList.add(resultSet.getString("GroupName"));
				opentaskGroupList.add(resultSet.getInt("GroupID"));
			}
		}
		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return opentaskList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List taskPastSLA(ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List opentaskList = new ArrayList();
		List opentaskList1 = new ArrayList();
		List opentaskGroupList = new ArrayList();
		try
		{
			connection= dataSource.getConnection();
			//query=com.htc.utility.QueryBuilder.getTasks_PAST_SLA(executiveHomeDTO);
			query = StoredProcedureConstants.Task_Past_SLA;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			while (resultSet.next())
			{
				opentaskList.add(resultSet.getString("Assigned_Group"));
				opentaskList1.add(resultSet.getInt("Task_Count"));
			}
			opentaskGroupList.add(opentaskList);
			opentaskGroupList.add(opentaskList1);

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return opentaskGroupList;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List performanceSla(ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List opentaskList = new ArrayList();
		List opentaskList1 = new ArrayList();
		List opentaskGroupList = new ArrayList();
		try
		{
			connection= dataSource.getConnection();
			//query=com.htc.utility.QueryBuilder.getSLAPerformance(executiveHomeDTO);
			//psstatemet = connection.prepareStatement(query);
			//resultSet = psstatemet.executeQuery();
			query = StoredProcedureConstants.SLA_Performance;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			while (resultSet.next())
			{

				opentaskList.add(resultSet.getString("Assigned Group"));
				opentaskList1.add(resultSet.getInt("Percent"));
			}
			opentaskGroupList.add(opentaskList);
			opentaskGroupList.add(opentaskList1);

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return opentaskGroupList;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <ExecutiveHomeDTO> List  openRequestByTeam(com.htc.executive.dto.ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> columnList = null;
		List<String> cellList = null;
		List<List<String>> rowList = null;

		try
		{
			rowList=new ArrayList<List<String>>();
			columnList=new ArrayList<String>();
			connection= dataSource.getConnection();
			//query=QueryBuilder.getOpenRequestsByTeam(executiveHomeDTO);
			//psstatemet = connection.prepareStatement(query);
			//resultSet = psstatemet.executeQuery();
			query = StoredProcedureConstants.Open_Request;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			
			for(int i=1;i<=columnCount;i++)
			{
				columnList.add(resultSetMetaData.getColumnName(i));
			}
			rowList.add(columnList);
			//System.out.println(columnList.size());
			while (resultSet.next())
			{
				cellList = new ArrayList<String>();
				for(int i=0;i<columnCount;i++)
				{
					String getColumnVal= resultSet.getString(columnList.get(i));
					if(null == getColumnVal){
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}
				
				rowList.add(cellList);
			}

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return rowList;
	}



	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List  ClosedRequests(com.htc.executive.dto.ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> columnList = null;
		List<String> cellList = null;
		List<List<String>> rowList = null;
		try
		{
			rowList=new ArrayList<List<String>>();
			columnList=new ArrayList<String>();
			connection= dataSource.getConnection();
			//query=QueryBuilder.getClosedRequests(executiveHomeDTO);
			//psstatemet = connection.prepareStatement(query);
			//resultSet = psstatemet.executeQuery();
			query = StoredProcedureConstants.Closed_Request;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			
			for(int i=1;i<=columnCount;i++)
			{
				columnList.add(resultSetMetaData.getColumnName(i));
			}
			rowList.add(columnList);
			while (resultSet.next())
			{
				cellList = new ArrayList<String>();
				for(int i=0;i<columnCount;i++)
				{ 
					String getColumnVal= resultSet.getString(columnList.get(i));
					if(null == getColumnVal){
						getColumnVal = "--";
					}
					cellList.add(getColumnVal);
				}
				
				rowList.add(cellList);
			}

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return rowList;
	}
	@SuppressWarnings("unchecked")
	public Map<String, List<?>>  summary(com.htc.executive.dto.ExecutiveHomeDTO ldto) throws SQLException,NamingException
	{
		
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> summary=new ArrayList<>();
		List valuee=new ArrayList<>();
		List map=new ArrayList<>(); 
		Map<String,List<?>> map1=new HashMap<String,List<?>>();
			
			
			try
			{
				connection= dataSource.getConnection();
				
				query=QueryBuilder.getSummary(ldto);
				
					psstatemet = connection.prepareStatement(query);
					resultSet = psstatemet.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnsNumber = resultSetMetaData.getColumnCount();
					
					
					for (int i = 1; i <= columnsNumber; i++) {
						String name = resultSetMetaData.getColumnName(i);
						summary.add(name);
					}
					
					while (resultSet.next()) {
						Object[] values = new Object[columnsNumber];
						for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
							 values[i - 1] = resultSet.getObject(i);
						}
						valuee.add(values);
					}
					
					   map.add(summary); 
					   map1.put("colunmname", summary);
					    map1.put("columnvalue", valuee);
				    System.out.println("---------"+map1);
			}

			finally {
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return map1;
	}



	
@SuppressWarnings({ "unchecked", "rawtypes" })
public Map<String, List<?>>  getTaskDetailsInSummaryPage(com.htc.executive.dto.ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
{
	Connection connection=null;
	CallableStatement callableStatement = null;
	ResultSet resultSet=null;
	
	String query="";
	List<String> summary=new ArrayList<>();
	List valuee=new ArrayList<>();
	List map=new ArrayList<>(); 
	Map<String,List<?>> map1=new HashMap<String,List<?>>();
		
		
		try
		{
			connection= dataSource.getConnection();
			
			query=QueryBuilder.getTaskDetailsInSummaryPageQuery(executiveHomeDTO);
			
				psstatemet = connection.prepareStatement(query);
				resultSet = psstatemet.executeQuery();
				ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
				int columnsNumber = resultSetMetaData.getColumnCount();
				
				
				for (int i = 1; i <= columnsNumber; i++) {
					String name = resultSetMetaData.getColumnName(i);
					summary.add(name);
				}
				
				while (resultSet.next()) {
					Object[] values = new Object[columnsNumber];
					for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
						 	values[i - 1] = resultSet.getObject(i);
							if(null == values[i - 1]){
								values[i - 1] = "--";
							}
					}
					valuee.add(values);
				}
				
				   map.add(summary); 
				   map1.put("colunmname", summary);
				    map1.put("columnvalue", valuee);
			
		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return map1;
}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List  createChart(ExecutiveHomeDTO ldto) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List caseasigngroup = new ArrayList();
		List taskcountlist = new ArrayList();
		List chartList = new ArrayList();
		try
		{
			connection= dataSource.getConnection();
			query=ldto.getQuery();
			psstatemet = connection.prepareStatement(query);
			resultSet = psstatemet.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			while (resultSet.next())
			{
				caseasigngroup.add(resultSet.getString("Group Name"));
				taskcountlist.add(resultSet.getString("Task Count"));
			}
			chartList.add(caseasigngroup);
			chartList.add(taskcountlist);


		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return chartList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List  barClickDetailTable(ExecutiveHomeDTO ldto) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> caseasigngroupName = new ArrayList();
		List taskcountlistData = new ArrayList();
		List chartList = new ArrayList();
		String values = null;
		
		try
		{
			connection= dataSource.getConnection();
			query=ldto.getQuery();
			
			psstatemet = connection.prepareStatement(query);
			resultSet = psstatemet.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				caseasigngroupName.add(name);
			}
			chartList.add(caseasigngroupName);
			while (resultSet.next()) {
				
				  for (String temp : caseasigngroupName) {
					  values=resultSet.getString(temp);
					  if(null!=values)
					  taskcountlistData.add(values);
					  else
						  taskcountlistData.add("--");
					}
				  chartList.add(taskcountlistData);
				  taskcountlistData=new ArrayList();
				
				
			}
			
			
		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return chartList;
	}
	
	
	public Map<String, List<?>>  getSavedPage(ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> savedColumn=new ArrayList<>();
		List savedvaluee=new ArrayList<>();
		List map=new ArrayList<>(); 
		Map<String,List<?>> saved=new HashMap<String,List<?>>();
			
			
			try
			{
				connection= dataSource.getConnection();
				
				//query=QueryBuilder.getSavedQuery(executiveHomeDTO);
				
					psstatemet = connection.prepareStatement(query);
					resultSet = psstatemet.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnsNumber = resultSetMetaData.getColumnCount();
					
					
					for (int i = 1; i <= columnsNumber; i++) {
						String name = resultSetMetaData.getColumnName(i);
						savedColumn.add(name);
					}
					
					while (resultSet.next()) {
						Object[] values = new Object[columnsNumber];
						for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
							 values[i - 1] = resultSet.getObject(i);
						}
						savedvaluee.add(values);
					}
					
					   map.add(savedColumn); 
					   saved.put("colunmname", savedColumn);
					   saved.put("columnvalue", savedvaluee);
			}

			finally {
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return saved;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<List<String>>  showReportTable(ExecutiveHomeDTO ldto) throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List<String> columnList = new ArrayList<String>();
		List<String> cellList = null;
		List<List<String>> rowList = new ArrayList<>();

			
			
			try
			{
				connection= dataSource.getConnection();
				
				query=ldto.getQuery();;
				
					psstatemet = connection.prepareStatement(query);
					resultSet = psstatemet.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnCount = resultSetMetaData.getColumnCount();
					
					
					for (int i = 1; i <= columnCount; i++) {
						String name = resultSetMetaData.getColumnName(i);
						columnList.add(name);
					}
					rowList.add(columnList);
					while (resultSet.next())
					{
						cellList = new ArrayList<String>();
						for(int i=0;i<columnCount;i++)
						{ 
							String getColumnVal= resultSet.getString(columnList.get(i));
							if(null == getColumnVal){
								getColumnVal = "--";
							}
							cellList.add(getColumnVal);
						}
						
						rowList.add(cellList);
					}
			}

			finally {
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return rowList;
	}
	
	
	public List chartOnClick(ExecutiveHomeDTO executiveHomeDTO)throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List valueList = new ArrayList();
		List tableList = new ArrayList();
		List<String> caseasigngroupName = new ArrayList();
		String value="";

		try
		{
			connection= dataSource.getConnection();
			if(executiveHomeDTO.getChartType().equalsIgnoreCase("openTaskChart")){
				//query=com.htc.utility.QueryBuilder.getOpenTaskOnClick(executiveHomeDTO);
				query = StoredProcedureConstants.Open_Tasks_Drill_Down;
			}else if(executiveHomeDTO.getChartType().equalsIgnoreCase("taskPastSLA")){
				//query=com.htc.utility.QueryBuilder.getTaskPastSLAOnClick(executiveHomeDTO);
				query = StoredProcedureConstants.Task_past_SLA_Drill_Down;
			}else if(executiveHomeDTO.getChartType().equalsIgnoreCase("myTable")){
				//query=com.htc.utility.QueryBuilder.getClosedRequestOnClick(executiveHomeDTO);
				query = StoredProcedureConstants.Closed_Request_Drill_Down;
			}else if(executiveHomeDTO.getChartType().equalsIgnoreCase("RequestWaiting")){
				//query=com.htc.utility.QueryBuilder.getRequestWaitingForAppovalOnClick(executiveHomeDTO);
				query = StoredProcedureConstants.Requests_Awaiting_Approval_Drill_Down;
			}
			
			//psstatemet = connection.prepareStatement(query);
			//resultSet = psstatemet.executeQuery();
			
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			

			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				caseasigngroupName.add(name);
			}
			tableList.add(caseasigngroupName);
			while (resultSet.next()) {
				
				  for (String temp : caseasigngroupName) {
					  value=resultSet.getString(temp);
					  if(null!=value)
						  valueList.add(value);
					  else
						  valueList.add("--");
					}
				  tableList.add(valueList);
				  valueList=new ArrayList();
				
				
			}
			
			
		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return tableList;
	}
	
	public List requestWaitingApproval(ExecutiveHomeDTO executiveHomeDTO)throws SQLException,NamingException
	{
		Connection connection=null;
		CallableStatement callableStatement = null;
		ResultSet resultSet=null;
		
		String query="";
		List opentaskList = new ArrayList();
		List opentaskGroupList = new ArrayList();

		try
		{
			connection= dataSource.getConnection();
			//query=com.htc.utility.QueryBuilder.getRequestWaitingForAppoval(executiveHomeDTO);
			//psstatemet = connection.prepareStatement(query);
			//resultSet = psstatemet.executeQuery();
			query = StoredProcedureConstants.Requests_Awaiting_Approval;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, executiveHomeDTO.getDropdownOption());
			callableStatement.setString(2, executiveHomeDTO.getGroupName());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();

			while (resultSet.next())
			{
				opentaskList.add(resultSet.getString("Assigned Group"));
				opentaskList.add(resultSet.getInt("Request Awaiting Approval"));
				opentaskGroupList.add(opentaskList);
				opentaskList = new ArrayList();
			}

		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=callableStatement)callableStatement.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}

		return opentaskGroupList;
	}
	
	
}


