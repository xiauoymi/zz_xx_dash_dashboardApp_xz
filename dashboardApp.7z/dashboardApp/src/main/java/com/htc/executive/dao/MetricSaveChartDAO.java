package com.htc.executive.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.executive.dto.ExecutiveHomeDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;

@SuppressWarnings("unused")
public class MetricSaveChartDAO {

	DataSource dataSource1;
	DataSource dataSource2;
	Connection connection=null;
	Statement statement=null;
	PreparedStatement psstatemet=null;
	CallableStatement callableStatement=null;
	ResultSet resultSet=null;
	ResultSet resultSet1=null;
	
	public void setDataSourceMetrics(DataSource dataSourceMetrics) {
		this.dataSource1 = dataSourceMetrics;
	}
	
	public void setDataSourceRemedy(DataSource dataSourceMetrics1) {
		this.dataSource2 = dataSourceMetrics1;
	}
	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String  chartReportSave(ExecutiveHomeDTO ldto) throws SQLException,NamingException
	{
		String query="";
		String Success="Report successfully saved";
		
		try
		{
			connection= dataSource1.getConnection();
			query=QueryBuilder.chartSave(ldto);
			psstatemet = connection.prepareStatement(query);
			psstatemet.setString(1,ldto.getClientName());
			psstatemet.setString(2,ldto.getReportName());
			psstatemet.setString(3,ldto.getQuery());
			psstatemet.setString(4,ldto.getCreated_date());
			int i=psstatemet.executeUpdate();
			
		}

		finally {
			try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
			{e.printStackTrace();}
			try { if(null!=connection)connection.close();} catch (SQLException e) 
			{e.printStackTrace();}
		}
		return Success;
	}
	
	public Map<String, List<?>>  getSavedReports(ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		String query="";
		List<String> summary=new ArrayList<>();
		List rowid=new ArrayList<>();
		List profileName=new ArrayList<>();
		List profileValue=new ArrayList<>();
		List userId=new ArrayList<>();
		List map=new ArrayList<>(); 
		Map<String,List<?>> map1=new HashMap<String,List<?>>();
			
			
			try
			{
				connection= dataSource1.getConnection();
				
				query=QueryBuilder.getSavedQuery(executiveHomeDTO);
				
					psstatemet = connection.prepareStatement(query);
					resultSet = psstatemet.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnsNumber = resultSetMetaData.getColumnCount();
					
					for (int i = 1; i <= columnsNumber; i++) {
						String name = resultSetMetaData.getColumnName(i);
						summary.add(name);
					}
					while (resultSet.next()) {
						rowid.add(resultSet.getInt(summary.get(0)));
						profileName.add(resultSet.getString(summary.get(1)));
						profileValue.add(resultSet.getString(summary.get(2)));
						userId.add(resultSet.getString(summary.get(4)));
					}
					    map1.put("rowid", rowid);
					    map1.put("profileName", profileName);
					    map1.put("profileValue",profileValue);
					    map1.put("userId", userId);
				
			}

			finally {
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return map1;
	}
	
	

	public String  getMydashboardProfileValue(ExecutiveHomeDTO executiveHomeDTO) throws SQLException,NamingException
	{
		String query="";
		String MydashboardProfileValue="";
		List<String> summary=new ArrayList<>();
		List rowid=new ArrayList<>();
		List profileName=new ArrayList<>();
		List profileValue=new ArrayList<>();
		List map=new ArrayList<>(); 
		Map<String,List<?>> map1=new HashMap<String,List<?>>();
			
			
			try
			{
				connection= dataSource1.getConnection();
				
				query=QueryBuilder.getSavedProfileValue(executiveHomeDTO);
				
					psstatemet = connection.prepareStatement(query);
					resultSet = psstatemet.executeQuery();
					while (resultSet.next()) {
						MydashboardProfileValue=resultSet.getString("profileValue");
					}
					
					
					    
				
			}

			finally {
				try { if(null!=resultSet1)resultSet1.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return MydashboardProfileValue;
	}
	
	public List  getProfileChart(String myDashboardValue) throws SQLException,NamingException
	{
		String query="";
		String MydashboardProfileValue="";
		List<String> summary=new ArrayList<>();
		List chartValues=new ArrayList<>();
		List profileName=new ArrayList<>();
		List profileValue=new ArrayList<>();
		List map=new ArrayList<>(); 
		Map<String,List<?>> map1=new HashMap<String,List<?>>();
			
			
			try
			{
				    connection= dataSource2.getConnection();
					psstatemet = connection.prepareStatement(myDashboardValue);
					resultSet = psstatemet.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnsNumber = resultSetMetaData.getColumnCount();
					for (int i = 1; i <= columnsNumber; i++) {
						String name = resultSetMetaData.getColumnName(i);
						summary.add(name);
					}
					while (resultSet.next()) {
						profileName.add(resultSet.getString(summary.get(0)));
						profileValue.add(resultSet.getString(summary.get(1)));
					}
					chartValues.add(profileName);
					chartValues.add(profileValue);
			}

			finally {
				try { if(null!=resultSet1)resultSet1.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=resultSet)resultSet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=psstatemet)psstatemet.close();} catch (SQLException e) 
				{e.printStackTrace();}
				try { if(null!=connection)connection.close();} catch (SQLException e) 
				{e.printStackTrace();}
			}

			return chartValues;
	}

	
}
