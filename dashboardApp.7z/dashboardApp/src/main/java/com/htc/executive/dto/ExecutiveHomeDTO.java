package com.htc.executive.dto;

import java.util.List;



public class ExecutiveHomeDTO {

	private String clientName;
	private String month;
	private String query;
	private String reportName;
	private String fromDate;
	private String toDate;
	private String groupName;
	private String atttribute;
	private String created_date;
    private String rowid;
	private List<GroupDTO> groupList;
	private String dropdownOption;
	private String userId;
	private String chartType;

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public List<GroupDTO> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<GroupDTO> groupList) {
		this.groupList = groupList;
	}

	public String getDropdownOption() {
		return dropdownOption;
	}
	public void setDropdownOption(String dropdownOption) {
		this.dropdownOption = dropdownOption;
	}

	public String getCreated_date() {
		return created_date;
	}

	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}


	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	private String Group;

	public String getGroup() {
		return Group;
	}

	public void setGroup(String grouplist) {
		Group = grouplist;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}




	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getAtttribute() {
		return atttribute;
	}

	public void setAtttribute(String atttribute) {
		this.atttribute = atttribute;
	}

	public String getRowid() {
		return rowid;
	}

	public void setRowid(String string) {
		this.rowid = string;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}






