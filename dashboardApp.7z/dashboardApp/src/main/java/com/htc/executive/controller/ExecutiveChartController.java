package com.htc.executive.controller;

//import java.sql.SQLException;
//import java.text.DateFormat;
//import java.util.ArrayList;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;







import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;







import com.htc.executive.dao.ExecutiveDashboardDAO;
import com.htc.executive.dao.MetricSaveChartDAO;
import com.htc.executive.dto.ExecutiveHomeDTO;
import com.htc.utility.DashboardConstants;

@Controller
public class ExecutiveChartController {
	
	@Autowired
	private ExecutiveDashboardDAO executiveDashboardDAO;
	@Autowired
	private MetricSaveChartDAO metricDashboardDAO;
	
	private static final Logger logger = Logger
			.getLogger(ExecutiveChartController.class);
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ExecutiveDashboard", method = RequestMethod.POST,produces = "application/json")
	public  String showGroups(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		String userName = (String) session.getAttribute("username");
		List<String> groupList=null;
		StringBuilder builder = new StringBuilder();
		
		ExecutiveHomeDTO  dashboardExecdto=new ExecutiveHomeDTO();
		
		
	    if (userName != null && !("".equals(userName))) {
	    	dashboardExecdto.setClientName(userName);
	    	groupList=executiveDashboardDAO.dashboardExecutiveGroupData(dashboardExecdto);
			if(null!=groupList &&  !groupList.isEmpty()){
				for (String s : groupList)
				{
					builder.append("'"+s+"',");
				}
				builder.deleteCharAt(builder.length() - 1);
				dashboardExecdto.setGroup(builder.toString());
				session.setAttribute("grouplist", groupList);
			    model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG, groupList);	
			}else{
				groupList=null;
				session.setAttribute("grouplist", groupList);
				 model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG,groupList);	
			}
	    	return "Executive/Executive_Dashboard";
	    }else {
			return "common/UnAuthoriseAccess";
		}
		
		
		
		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/Executive", method = RequestMethod.GET,produces = "application/json")
	public  String getExecutiveGroups(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		String userName = (String) session.getAttribute("username");
		List<String> groupList=null;
		groupList = (List<String>) session.getAttribute("grouplist");
	    model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG, groupList);	
	    if (userName != null && !("".equals(userName))) {
	    	return "Executive/Executive_Dashboard";
	    }else {
			return "common/UnAuthoriseAccess";
		}
		
		
		
		
	}

/*	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ExecutiveDashboard", method = RequestMethod.POST,produces = "application/json")
	public  String getMydashboard(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		Map<String, List<?>> defaultSummary=null;
		Map<String, String> calender=new HashMap<>();
		Map<String, List<?>> saved=null;
		StringBuilder builder = new StringBuilder();
		String fromDate,toDate;
		List<String> groupList=null;
		
		ExecutiveHomeDTO  dashboardExecdto=new ExecutiveHomeDTO();
		String userName = (String)session.getAttribute("username");
		dashboardExecdto.setClientName(userName);
	if (userName != null && !("".equals(userName))) {	
		try {
			groupList=executiveDashboardDAO.dashboardExecutiveGroupData(dashboardExecdto);
			if(null!=groupList &&  !groupList.isEmpty()){
				for (String s : groupList)
				{
					builder.append("'"+s+"',");
				}
			}
			builder.deleteCharAt(builder.length() - 1);
			dashboardExecdto.setGroup(builder.toString());
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DATE, 1);
			Date firstDateOfPreviousMonth = cal.getTime();
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			Date lastDateOfPreviousMonth = cal.getTime();
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			fromDate = dateFormat.format(firstDateOfPreviousMonth);
			toDate = dateFormat.format(lastDateOfPreviousMonth);
			dashboardExecdto.setFromDate(fromDate);
			dashboardExecdto.setToDate(toDate);
			
			defaultSummary=executiveDashboardDAO.summary(dashboardExecdto);
			logger.info("defaultSummary----"+defaultSummary);
			saved=metricDashboardDAO. getSavedReports(dashboardExecdto);
			logger.info("saved----"+saved);
			defaultSummary.put("groupList", groupList);
			
			calender.put("fromDate",fromDate);
			calender.put("toDate", toDate);
		} catch (Exception e){
			logger.info("landing page error block----"+e);
			throw new Exception(e.getMessage());
		}
		if (null != groupList && !groupList.isEmpty()) {
			session.setAttribute("grouplist", groupList);
		}
		 model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG, defaultSummary);	
	     model.addAttribute("calenderValues", calender);	
	     model.addAttribute("saved", saved);	
		
		return "Executive/Mydashboard";
	}else {
		return "common/UnAuthoriseAccess";
	}	
}*/

	@RequestMapping(value = "/Mydashboard", method = RequestMethod.GET,produces = "application/json")
	public  String getMydashboard1(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		Map<String, List<?>> defaultSummary=null;
		Map<String, String> calender=new HashMap<>();
		Map<String, List<?>> saved=null;
		StringBuilder builder = new StringBuilder();
		String fromDate,toDate;
		List<String> groupList=null;
		
		ExecutiveHomeDTO  dashboardExecdto=new ExecutiveHomeDTO();
		String userName = (String)session.getAttribute("username");
		dashboardExecdto.setClientName(userName);
	if (userName != null && !("".equals(userName))) {		
		try {
			groupList=executiveDashboardDAO.dashboardExecutiveGroupData(dashboardExecdto);
			logger.info("get group list----"+groupList);
			if(null!=groupList &&  !groupList.isEmpty()){
				for (String s : groupList)
				{
					builder.append("'"+s+"',");
				}
			}
			builder.deleteCharAt(builder.length() - 1);
			dashboardExecdto.setGroup(builder.toString());
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DATE, 1);
			Date firstDateOfPreviousMonth = cal.getTime();
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			Date lastDateOfPreviousMonth = cal.getTime();
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			fromDate = dateFormat.format(firstDateOfPreviousMonth);
			toDate = dateFormat.format(lastDateOfPreviousMonth);
			dashboardExecdto.setFromDate(fromDate);
			dashboardExecdto.setToDate(toDate);
			
			defaultSummary=executiveDashboardDAO.summary(dashboardExecdto);
			saved=metricDashboardDAO. getSavedReports(dashboardExecdto);
			defaultSummary.put("groupList", groupList);
			
			calender.put("fromDate",fromDate);
			calender.put("toDate", toDate);
		} catch (Exception e){
			logger.info("grouplist error block----"+groupList);
			throw new Exception(e.getMessage());
		}
		if (null != groupList && !groupList.isEmpty()) {
			session.setAttribute("grouplist", groupList);
		}
		 model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG, defaultSummary);	
	     model.addAttribute("calenderValues", calender);	
	     model.addAttribute("saved", saved);	
		
		return "Executive/Mydashboard";
	}else{
		return "common/UnAuthoriseAccess";
	}
}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/NewExecutive", method = RequestMethod.GET,produces = "application/json")
	public  String showNewChart(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		String userName = (String)session.getAttribute("username");
		List<String> groupList=null;
		groupList = (List<String>) session.getAttribute("grouplist");
	    model.addAttribute(DashboardConstants.EXECUTIVE_GROUPORG, groupList);	
	    if (userName != null && !("".equals(userName))) {		
		return "Executive/NewExecutiveDashboard";
	    }else{
	    	return "common/UnAuthoriseAccess";
	    }
	}
	
	
}
