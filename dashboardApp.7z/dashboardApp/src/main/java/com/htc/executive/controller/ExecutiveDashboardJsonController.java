package com.htc.executive.controller;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.executive.dao.ExecutiveDashboardDAO;
import com.htc.executive.dto.ExecutiveHomeDTO;
import com.htc.monthEnd.controller.SDMetricsReportController;
import com.htc.utility.DashboardConstants;
@Controller
public class ExecutiveDashboardJsonController {
	
	@Autowired
	private ExecutiveDashboardDAO executiveDashboardDAO;
	
	private static final Logger logger = Logger
			.getLogger(ExecutiveDashboardJsonController.class);
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/opentask", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List OpenTask(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		List openTaskList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new com.htc.executive.dto.ExecutiveHomeDTO();
		String groupNames = request.getParameter("groupNames");
		String dropdownOption = request.getParameter("dropdownOption");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupNames);

		try {
			openTaskList=executiveDashboardDAO.dashboardExecutiveHomeData(executiveHomeDTO);
			logger.info("openTaskList:---"+openTaskList);
		} catch (Exception e) {
			logger.info("openTaskList error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}




		return openTaskList;
	}

	@RequestMapping(value = "/taskPastSLA", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List taskPastSLA(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		List taskPastSLAList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new ExecutiveHomeDTO();
		String dropdownOption = request.getParameter("dropdownOption");
		String groupNames = request.getParameter("groupNames");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupNames);
		try {
			taskPastSLAList=executiveDashboardDAO.taskPastSLA(executiveHomeDTO);
			logger.info("taskPastSLAList  :--"+taskPastSLAList);
		} catch (Exception e) {
			logger.info("openTaskList error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return  taskPastSLAList ;
	}



	@RequestMapping(value = "/slaperformance", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List slaPerformance(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{

		List slaPerformanceList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new ExecutiveHomeDTO();
		String dropdownOption = request.getParameter("dropdownOption");
		String groupNames = request.getParameter("groupNames");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupNames);
		try {
			slaPerformanceList=executiveDashboardDAO.performanceSla(executiveHomeDTO);
			logger.info("slaPerformanceList :--"+slaPerformanceList);
		} catch (Exception e) {
			logger.info("slaPerformanceList error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return  slaPerformanceList ;

	}


	@RequestMapping(value = "/openTaskByTeam", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List openTaskByTeam(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {

		List openTaskList=new ArrayList();
		String groupName = request.getParameter("groupNames");
		ExecutiveHomeDTO executiveHomeDTO=new ExecutiveHomeDTO();
		executiveHomeDTO.setGroupName(groupName);
		String dropdownOption = request.getParameter("dropdownOption");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		try {
			openTaskList=executiveDashboardDAO.openRequestByTeam(executiveHomeDTO);
			logger.info("openTaskByTeam  :--"+openTaskList);
		} catch (Exception e) {
			logger.info("openTaskByTeam error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return  openTaskList ;
	}



	@RequestMapping(value = "/ClosedRequests", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List ClosedRequestsByWeek(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {

		List openTaskList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new ExecutiveHomeDTO();
		String dropdownOption = request.getParameter("dropdownOption");
		String groupNames = request.getParameter("groupNames");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupNames);

		try {
			openTaskList=executiveDashboardDAO.ClosedRequests(executiveHomeDTO);
			logger.info("ClosedRequests :--"+openTaskList);
		} catch (Exception e) {
			logger.info("ClosedRequests error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return  openTaskList ;
	}
	
	@RequestMapping(value = "/Summary", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody Map<String, List<?>> getSummary(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
						Map<String, List<?>> openTaskList=new HashMap<>();
						
						
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        dashboardhomedto.setFromDate(request.getParameter("fromdate"));
				        dashboardhomedto.setToDate(request.getParameter("todate"));
				       dashboardhomedto.setGroup(request.getParameter("grouplist"));
					try {
						openTaskList=executiveDashboardDAO.summary(dashboardhomedto);
						logger.info("Summary:--"+openTaskList);
					} catch (Exception e) {
						logger.info("Summary error block :--"+e);
						throw new Exception(DashboardConstants.SQL_EXCEPTION);
					}
					return  openTaskList ;
    }
	

	@RequestMapping(value = "/exeNewchart", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List createChartforDashboard(@RequestParam("queryDashboard") String queryForDashboard,ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		
						List openNewChartList=new ArrayList();
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        queryForDashboard=	URLDecoder.decode(queryForDashboard,
								StandardCharsets.UTF_8.toString());
				        String queryForBarchart= StringEscapeUtils.unescapeHtml(queryForDashboard);
				        dashboardhomedto.setQuery(queryForBarchart);
					
					try {
						openNewChartList=executiveDashboardDAO.createChart(dashboardhomedto);
						logger.info("openNewChartList :--"+openNewChartList);
					} catch (Exception e) {
						logger.info("openNewChartList error block :--"+e);
						throw new Exception(DashboardConstants.SQL_EXCEPTION);
					}
					return  openNewChartList ;
    }
	
	@RequestMapping(value = "/exeBarClickchart", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List barClickDetailTable(@RequestParam("queryBarClick") String queryBarClick,ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		
						List openBarClickList=new ArrayList();
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        String queryBar= StringEscapeUtils.unescapeHtml(queryBarClick);
				        dashboardhomedto.setQuery(queryBar);
					
					try {
						openBarClickList=executiveDashboardDAO.barClickDetailTable(dashboardhomedto);
						logger.info("openBarClickList :--"+openBarClickList);
					} catch (Exception e) {
						logger.info("openBarClickList error block :--"+e);
						throw new Exception(DashboardConstants.SQL_EXCEPTION);
					}
					return  openBarClickList ;
    }
	
	@RequestMapping(value = "/MyDhashboardLink", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody Map<String, List<?>> getMyDhashboardLink(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
						Map<String, List<?>> openTaskList=new HashMap<String, List<?>>();
						
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        dashboardhomedto.setGroupName((request.getParameter("groupName")));
				        dashboardhomedto.setFromDate(request.getParameter("fromdate"));
				        dashboardhomedto.setToDate(request.getParameter("todate"));
				        dashboardhomedto.setAtttribute((request.getParameter("colunmname")));
					
				try {
						openTaskList=executiveDashboardDAO.getTaskDetailsInSummaryPage(dashboardhomedto);
						logger.info("MyDhashboardLink onclick of table value :--"+openTaskList);
				} catch (Exception e) {
					logger.info("MyDhashboardLink  onclick of table value error block :--"+e);
					throw new Exception(DashboardConstants.SQL_EXCEPTION);
				}
				model.addAttribute("summaryValue", openTaskList);
					return  openTaskList ;
    }
	
	@RequestMapping(value = "/exeNewShowReport", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List<List<String>> createNewReportTable(@RequestParam("queryDashboard") String queryForDashboard,ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception{
		
						List<List<String>> openNewChartList=new ArrayList<>();
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        queryForDashboard=	URLDecoder.decode(queryForDashboard,
								StandardCharsets.UTF_8.toString());
				        String queryForBarchart= StringEscapeUtils.unescapeHtml(queryForDashboard);
				        dashboardhomedto.setQuery(queryForBarchart);
					
					try {
						openNewChartList=executiveDashboardDAO.showReportTable(dashboardhomedto);
						logger.info("openNewChartList error block :--"+openNewChartList);
					} catch (Exception e) {
						logger.info("openNewChartList error block :--"+e);
						throw new Exception(DashboardConstants.SQL_EXCEPTION);
					}
					return  openNewChartList ;
    }
	
	
	
	
	
	
	@RequestMapping(value = "/chartOnlick", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List opentaskOnClick(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		List taskList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new com.htc.executive.dto.ExecutiveHomeDTO();
		String chartType=request.getParameter("chartType");;
		String dropdownOption = request.getParameter("dropdownOption");
		String groupName = request.getParameter("groupName");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupName);
		executiveHomeDTO.setChartType(chartType);

		try {
			taskList=executiveDashboardDAO.chartOnClick(executiveHomeDTO);
			logger.info(chartType+":---"+taskList);
		} catch (Exception e) {
			logger.info("openTaskList error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}




		return taskList;
	}
	
	@RequestMapping(value = "/RequestWaiting", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List requestWaitingForApproval(ModelMap model, HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		List openTaskList=new ArrayList();

		ExecutiveHomeDTO executiveHomeDTO=new com.htc.executive.dto.ExecutiveHomeDTO();
		String dropdownOption = request.getParameter("dropdownOption");
		String groupNames = request.getParameter("groupNames");
		executiveHomeDTO.setDropdownOption(dropdownOption);
		executiveHomeDTO.setGroupName(groupNames);

		try {
			openTaskList=executiveDashboardDAO.requestWaitingApproval(executiveHomeDTO);
			logger.info("requestWaiting:---"+openTaskList);
		} catch (Exception e) {
			logger.info("openTaskList error block :--"+e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}




		return openTaskList;
	}
	
	
}
