package com.htc.executive.controller;


import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.executive.dao.MetricSaveChartDAO;
import com.htc.executive.dto.ExecutiveHomeDTO;
import com.htc.utility.DashboardConstants;

@Controller
public class ExecutiveSaveController {
	
	@Autowired
	private MetricSaveChartDAO metricDashboardDAO;
	@Autowired
	private MetricSaveChartDAO metricDashboardDAO1;

	
	private static final Logger logger = Logger
			.getLogger(ExecutiveSaveController.class);
	
	@RequestMapping(value = "/exeNewchartSave", method = RequestMethod.GET,produces="text/plain")
	public @ResponseBody String createChartforDashboard(@RequestParam("queryDashboard") String queryForDashboard,
			@RequestParam("clickAction") String action,@RequestParam("reportName") String reportName,ModelMap model, 
			HttpServletRequest request,HttpServletResponse response,HttpSession session)  throws Exception
	{
		
						String Success="";
						queryForDashboard=	URLDecoder.decode(queryForDashboard,
								StandardCharsets.UTF_8.toString());
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        dashboardhomedto.setQuery(queryForDashboard);
				        String userName = (String)session.getAttribute("username");
				      
				        	dashboardhomedto.setReportName(reportName);
				        	dashboardhomedto.setClientName(userName);
				        	dashboardhomedto.setCreated_date(getTodayDate());
				        	
								          try {
								        		
								        		  Success=metricDashboardDAO.chartReportSave(dashboardhomedto);
								        		  logger.info("saving report to db :---"+Success);
												} catch (Exception e) {
													 logger.info("saving report to db error block :---"+e); 
													throw new Exception(DashboardConstants.SQL_EXCEPTION);
												}
								          
								         
								          
							  return Success;
				        	
				        	
    }

	
	public String getTodayDate()
	{
		
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

		// Get the date today using Calendar object.
		Date today =  Calendar.getInstance().getTime();        
		// Using DateFormat format method we can create a string 
		// representation of a date with the defined format.
		String reportDate = df.format(today);

		// Print what date is today!
		System.out.println("Report Date: " + reportDate);
		return reportDate;
		
	}
	
	
	@RequestMapping(value = "/myDashboardSavedReport", method = RequestMethod.GET,produces = "application/json")
	public @ResponseBody List getmyDashboardSavedReport(ModelMap model, 
			HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception
	{
		
						String Success="";
						List chartValues=new ArrayList();
				        ExecutiveHomeDTO dashboardhomedto=new ExecutiveHomeDTO();
				        dashboardhomedto.setRowid(request.getParameter("profilId"));
				        dashboardhomedto.setUserId(request.getParameter("userID"));
				        
								          try {
								        		
								        	  Success=metricDashboardDAO.getMydashboardProfileValue(dashboardhomedto);
								        	  logger.info(" Get saved report query :---"+Success); 
								        	  chartValues=metricDashboardDAO1.getProfileChart(Success);
								        	  logger.info("saved report values :---"+chartValues); 
							                  
												} catch (Exception e) {
													 logger.info("saved report error block :---"+e); 
													throw new Exception(DashboardConstants.SQL_EXCEPTION);
												}
								          
								         
								          
							  return chartValues;
				        	
				        	
    }
}
