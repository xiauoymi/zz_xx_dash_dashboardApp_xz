package com.htc.LMS.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.LMS.dto.ApproveLeaveDTO;
import com.htc.LMS.dto.CreateRUpdateInviteDTO;
import com.htc.LMS.dto.TeleoptiWebserviceDto;
import com.htc.utility.StoredProcedureConstants;

public class TeleoptiWebserviceDao {

	private static final Logger logger = Logger.getLogger(TeleoptiWebserviceDao.class);

	DataSource dataSourceLMS;
	public void setDataSourceLMS(DataSource dataSourceLMS) {
		this.dataSourceLMS = dataSourceLMS;
	}
	public TeleoptiWebserviceDto getTeleoptiApproveData(ApproveLeaveDTO approveLeaveDTO) throws SQLException,
	NamingException {
		logger.info("Inside TELEOPTIWEBSERVICEDAO getTeleoptiApproveData() method");
		Connection connection = null;
		TeleoptiWebserviceDto teleDto=new TeleoptiWebserviceDto();
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveBalancequery = "";
		List<String> reportDescriptionList = new ArrayList<String>();

		try {
			connection = dataSourceLMS.getConnection();
			leaveBalancequery = StoredProcedureConstants. getLeaveDataForTeleopti;
			callableStatement = connection.prepareCall(leaveBalancequery);
			callableStatement.setString(1,  approveLeaveDTO.getRequestID());
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {

				teleDto.setAgentId(resultSet.getString("Agent_ID"));
				teleDto.setActivityId(resultSet.getString("Activity_ID"));
				teleDto.setStartDate(resultSet.getString("start_Date"));
				teleDto.setEndDate(resultSet.getString("end_Date"));
				if(approveLeaveDTO.getRequestType().equalsIgnoreCase("OVT")){
					teleDto.setOverTimeException((resultSet.getString("OverTime_code")));
				}
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting TELEOPTIWEBSERVICEDAO getTeleoptiApproveData() method");
		return teleDto;
	}

	public List<TeleoptiWebserviceDto> getInviteScheduledDataForTeleopti(String timeOffId,String type) throws SQLException,
	NamingException {
		logger.info("Inside TELEOPTIWEBSERVICEDAO getInviteScheduledDataForTeleopti() method");
		Connection connection = null;

		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String addActivity = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<TeleoptiWebserviceDto> responseList= new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			addActivity = StoredProcedureConstants.getInviteScheduledDataForTeleopti;

			callableStatement = connection.prepareCall(addActivity);
			callableStatement.setString(1,timeOffId);
			callableStatement.setString(2,type);

			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				TeleoptiWebserviceDto teleDto=new TeleoptiWebserviceDto();
				teleDto.setAgentId(resultSet.getString("Agent_ID"));
				teleDto.setActivityId(resultSet.getString("Activity_ID"));
				teleDto.setStartDate(resultSet.getString("start_Date"));
				teleDto.setEndDate(resultSet.getString("end_Date"));
				responseList.add(teleDto);
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting TELEOPTIWEBSERVICEDAO getInviteScheduledDataForTeleopti() method");
		return responseList;
	}


	/**
	 * @param requestDTO
	 * @return Equivalent Teleopti "Agent_ID,Activity_ID,start_Date,end_Date" List for the given login user Id
	 * @throws SQLException
	 * @throws NamingException
	 */
	public List<TeleoptiWebserviceDto> getEquivalentTeleoptiRecord(CreateRUpdateInviteDTO createRUpdateInviteDTO) throws SQLException,
	NamingException {

		logger.info("Inside TELEOPTIWEBSERVICEDAO getEquivalentTeleoptiRecord() method");
		Connection connection = null;

		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String addActivity = "";
		List<String> reportDescriptionList = new ArrayList<String>();
		List<TeleoptiWebserviceDto> responseList= new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			addActivity = StoredProcedureConstants.GET_EQUIVALENT_TELEOPTI_RECORD;

			callableStatement = connection.prepareCall(addActivity);
			callableStatement.setString(1,createRUpdateInviteDTO.getLoginId());
			callableStatement.setString(2,createRUpdateInviteDTO.getInviteType());
			callableStatement.setString(3,createRUpdateInviteDTO.getInviteFromDate());
			callableStatement.setString(4,createRUpdateInviteDTO.getInviteToDate());
			callableStatement.setString(5,createRUpdateInviteDTO.getNumOfDaysRHours());
			callableStatement.setString(6,createRUpdateInviteDTO.getInviteFormat());
			callableStatement.setString(7,createRUpdateInviteDTO.getInviteStartTime());
			callableStatement.setString(8,createRUpdateInviteDTO.getInviteEndTime());


			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				TeleoptiWebserviceDto teleDto=new TeleoptiWebserviceDto();
				teleDto.setAgentId(resultSet.getString("Agent_ID"));
				teleDto.setActivityId(resultSet.getString("Activity_ID"));
				teleDto.setStartDate(resultSet.getString("start_Date"));
				teleDto.setEndDate(resultSet.getString("end_Date"));
				responseList.add(teleDto);
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting TELEOPTIWEBSERVICEDAO getEquivalentTeleoptiRecord() method");
		return responseList;
	}
	public TeleoptiWebserviceDto getTeleoptiCancelApproveData(String timeOffId) throws SQLException,
	NamingException {
		logger.info("Inside TELEOPTIWEBSERVICEDAO getTeleoptiApproveData() method");
		Connection connection = null;
		TeleoptiWebserviceDto teleDto=new TeleoptiWebserviceDto();
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveBalancequery = "";
		List<String> reportDescriptionList = new ArrayList<String>();

		try {
			connection = dataSourceLMS.getConnection();
			leaveBalancequery = StoredProcedureConstants. GETCANCELLEDLEAVEDATATOTELEOPTI;
			callableStatement = connection.prepareCall(leaveBalancequery);
			callableStatement.setString(1,  timeOffId);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {

				teleDto.setAgentId(resultSet.getString("Agent_ID"));
				teleDto.setStartDate(resultSet.getString("start_Date"));
				teleDto.setEndDate(resultSet.getString("end_Date"));
			}

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting TELEOPTIWEBSERVICEDAO getTeleoptiApproveData() method");
		return teleDto;
	}

}
