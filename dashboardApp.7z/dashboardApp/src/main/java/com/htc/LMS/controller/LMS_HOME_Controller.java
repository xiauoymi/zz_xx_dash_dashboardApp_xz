package com.htc.LMS.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.io.FileWriter;

import javax.mail.internet.MimeMessage;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.htc.LMS.dao.LMS_DASHBOARD_DAO;
import com.htc.LMS.dao.TeleoptiWebserviceDao;
import com.htc.LMS.dto.AgentsListForManagerDTO;
import com.htc.LMS.dto.ApplyLeaveDTO;
import com.htc.LMS.dto.ApplyLeaveResponseDTO;
import com.htc.LMS.dto.ApproveLeaveDTO;
import com.htc.LMS.dto.ApproveLeaveResponseDTO;
import com.htc.LMS.dto.CreateRUpdateInviteDTO;
import com.htc.LMS.dto.LoadInviteDTO;
import com.htc.LMS.dto.ScheduledInviteDTO;
import com.htc.LMS.dto.SendEmailDTO;
import com.htc.LMS.dto.TeleoptiWebserviceDto;
import com.htc.LMS.dto.cancelAppliedRequestDTO;
import com.htc.LMS.soap.service1.TeleoptiAgentClient;
import com.htc.LMSTimesheetAndAdjustMent.dao.LMSTimsheetAdjustmentDAO;
import com.htc.TOMS.peopleSoft.wsdl.service.BuildElapsedTimeAddElements;
import com.htc.lmspageview.calender.dao.CalenderDao;
import com.htc.lmspageview.calender.dto.CalenderLeaveStatusDTO;
import com.htc.lmspageview.calender.utility.CalenderJsonConverter;
import com.htc.utility.DashboardConstants;
import com.htc.utility.TeleoptiCheckScheduleDTO;

/*
 * HTC_Offshore
 * purpose: TOMS Screen Controller 
 * */
@Controller
@SessionAttributes("username")
public class LMS_HOME_Controller {

	@Autowired
	LMS_DASHBOARD_DAO dataSourceLMS;

	private static final Logger LOGGER = Logger.getLogger(LMS_HOME_Controller.class);
	
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	CalenderDao calenderDao;

	@Autowired
	LMSTimsheetAdjustmentDAO LMSTimsheetAdjustment;

	@Autowired
	TeleoptiAgentClient teleoptiAgentClient;

	@Autowired
	TeleoptiWebserviceDao teleoptiWebserviceData;

	
	/**
	 * @Purpose: Used to Load "TOMS - Agent Home" Screen. Login User : Team Lead
	 * @param model
	 * @param request
	 * @param session
	 * @returnType: String ; Value = JSP Name which needs to be loaded.
	 * */
	@RequestMapping(value = "/TOMSHome", method = RequestMethod.POST)
	public String getTOMSHome(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		
		LOGGER.info("Inside getTOMSHome() method");		
		
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
		
		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		
		String loginUserId = (String) session.getAttribute("userid");
		String json = null;

		try {

			leaveBalanceTableDetailMap = dataSourceLMS.leaveBalnceTable(loginUserId);
			leaveHistoryTableDetailMap = dataSourceLMS.leaveHistoryTable(loginUserId);
			
			calenderLeaveStatusList = calenderDao.getLeaveStatus(loginUserId);
			
			if (calenderLeaveStatusList != null	&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter.getJsonList(calenderLeaveStatusList);
			}
			
			request.setAttribute(DashboardConstants.lEAVEBALANCETABLEMAP 
									,leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP
									,leaveHistoryTableDetailMap);
			request.setAttribute(DashboardConstants.LEAVE_STATUS_JSON_STRING
									,json);

		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		}catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Inside getTOMSHome() method");

		return "LMS/TOMS_HOME";
	}

	/**
	 * @Purpose: Used to Load "TOMS - Agent Home" Screen. Login User : Agents
	 * @param model
	 * @param request
	 * @param session
	 * @returnType: String ; Value = JSP Name which needs to be loaded.
	 */
	@RequestMapping(value = "/TOMSAgentHome", method = RequestMethod.POST)
	public String getTOMSAgentHome(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		
		LOGGER.info("Inside getTOMSAgentHome() method");
		
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();
		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		String loginUserId = (String) session.getAttribute("userid");
		String json = null;

		try {
			leaveBalanceTableDetailMap = dataSourceLMS.leaveBalnceTable(loginUserId);
			leaveHistoryTableDetailMap = dataSourceLMS.leaveHistoryTable(loginUserId);
			
			calenderLeaveStatusList = calenderDao.getLeaveStatus(loginUserId);

			leaveProjectionTableDetailMap = dataSourceLMS.leaveProjectionTable(loginUserId);
			if (calenderLeaveStatusList != null	&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter.getJsonList(calenderLeaveStatusList);
			}
			
			request.setAttribute(DashboardConstants.lEAVEBALANCETABLEMAP, leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP, leaveHistoryTableDetailMap);
			request.setAttribute(DashboardConstants.LEAVEPROJECTIONMAP, leaveProjectionTableDetailMap);
			request.setAttribute(DashboardConstants.LEAVE_STATUS_JSON_STRING, json);

		}catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		}catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Inside getTOMSAgentHome() method");

		return "LMS/TOMS_AGENT_HOME";
	}

	/**
	 * @Purpose: Used to apply leave/Time off along with leave balance/history details. Login User : Agents
	 * @param model
	 * @param request
	 * @param session
	 * @returnType: String ; Value = JSP Name which needs to be loaded.
	 */
	@RequestMapping(value = "/TOMSApplyLeave", method = RequestMethod.GET)
	public String getTOMSApplyLeave(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Inside getTOMSApplyLeave() method");
	
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();
		List<String> overTimeExceptionList=new ArrayList<>();
		String userid = (String) session.getAttribute("userid");
		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		String json = null;

		try {
			leaveBalanceTableDetailMap = dataSourceLMS.leaveBalnceTable(userid);
			leaveProjectionTableDetailMap = dataSourceLMS.leaveProjectionTable(userid);

			leaveHistoryTableDetailMap = dataSourceLMS
					.leaveHistoryTable(userid);
			overTimeExceptionList=dataSourceLMS.getOverTimeExceptionActivities();

			calenderLeaveStatusList = calenderDao.getLeaveStatus(userid);

			if (calenderLeaveStatusList != null
					&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter
						.getJsonList(calenderLeaveStatusList);
			}

			request.setAttribute(DashboardConstants.lEAVEBALANCETABLEMAP,
					leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP,
					leaveHistoryTableDetailMap);
			request.setAttribute(DashboardConstants.LEAVEPROJECTIONMAP,
					leaveProjectionTableDetailMap);
			request.setAttribute(DashboardConstants.OVERTIMEEXCETIONLIST,
					overTimeExceptionList);


			request.setAttribute(DashboardConstants.LEAVE_STATUS_JSON_STRING,
					json);

		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Inside getTOMSApplyLeave() method");

		return "LMS/TOMS_apply_leave";
	}

	/**
	 * @Purpose: Used to retrieve leave details applied by all the agents belonging to a particular manager along with all the agents under a manager. Login User : Manager
	 * @param model
	 * @param request
	 * @param session
	 * @returnType: String ; Value = JSP Name which needs to be loaded.
	 */
	@RequestMapping(value = "/TOMSApproveLeave", method = RequestMethod.GET)
	public String getTOMSApproveLeave(ModelMap model,
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside getTOMSApproveLeave() method");
		
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
		List<AgentsListForManagerDTO> agentList = new ArrayList<>();

		String userid = (String) session.getAttribute("userid");
		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		String json = null;

		try {
			leaveHistoryTableDetailMap = dataSourceLMS.getRequestAwaitingApprovalManager(userid);

			// getting agent list
			//agent issue,not loaded 1-25-2018 start
		/*	ApproveLeaveDTO approveLeaveDTO = new ApproveLeaveDTO();
			approveLeaveDTO.setSupervisorID(supervisorUserid);
			agent issue,not loaded 1-25-2018 end*/
			agentList = dataSourceLMS.getAgentsListForManager(userid);

			calenderLeaveStatusList = calenderDao
					.getLeaveStatus(userid);

			if (calenderLeaveStatusList != null
					&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter
						.getJsonList(calenderLeaveStatusList);
			}

			request.setAttribute(DashboardConstants.lEAVEBALANCETABLEMAP,
					leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP,
					leaveHistoryTableDetailMap);
			request.setAttribute(DashboardConstants.LEAVE_STATUS_JSON_STRING,
					json);
			request.setAttribute(DashboardConstants.MANAGERAPPROVETREE,
					agentList);

		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Inside getTOMSApproveLeave() method");

		return "LMS/TOMS_approve_leave";
	}
	
	/**
	 * @Purpose: Used to retrieve leave details applied by an individual agent along with leave balance/history details. Login User : Manager
	 * @param model
	 * @param request
	 * @param session
	 * @returnType: String ; Value = JSP Name which needs to be loaded.
	 */
	@RequestMapping(value = "/getLeavePerAgent", method = RequestMethod.GET)
	public String getRequestAwaitingApprovalAgent(ModelMap model,
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside getRequestAwaitingApprovalAgent() method");
		
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();

		try {

			leaveHistoryTableDetailMap = dataSourceLMS
					.getRequestAwaitingApprovalAgent("TestAgent1");

			request.setAttribute(DashboardConstants.lEAVEBALANCETABLEMAP,
					leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP,
					leaveHistoryTableDetailMap);
		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Inside getRequestAwaitingApprovalAgent() method");

		return "LMS/TOMS_approve_leave";
	}

	/**
	 * @Purpose: Used to approve leave/leaves applied by agent/agents. Login User : Manager
	 * @param model
	 * @param request
	 * @param session
	 * @return list of maps which contains lEAVEBALANCETABLEMAP, lEAVEHISTORYTABLEMAP, LEAVEPROJECTIONMAP.
	 * @throws Exception 
	 * @throws DecoderException 
	 */
	@RequestMapping(value = "/appUrl", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, Map<String, List<?>>> lmsApproveLeave(
			HttpServletRequest request, HttpSession session)
					throws Exception {

		LOGGER.info("Inside lmsApproveLeave() method");
		Map<String, Map<String, List<?>>> getAgentActivityAndLoginStatMap = new HashMap<String, Map<String, List<?>>>();
		String userid = (String) session.getAttribute("userid");
		String userName = (String) session.getAttribute("username");
		String formArray = request.getParameter("listdata");
		formArray = URLDecoder.decode(formArray,
				StandardCharsets.UTF_8.toString());
		TeleoptiWebserviceDto teleDto = new TeleoptiWebserviceDto();
		if (StringUtils.isNotBlank(formArray)) {
			String a[] = formArray.split("],");
			
			for (String s : a) {
				String row[] = s.split(",");
				if (row != null && row.length > 0) {
					ApproveLeaveDTO approveLeaveDTO = new ApproveLeaveDTO();
					String reqId = row[1].replaceAll("[^\\dA-Za-z ]", "");
					approveLeaveDTO.setRequestID(reqId);
					approveLeaveDTO.setSupervisorID(userid);
					String agentName = row[3].replaceAll("\"", "").trim();
					String requestType= row[4].replaceAll("\"", "").trim();
					approveLeaveDTO.setRequestType(requestType);
					approveLeaveDTO.setAgentName(agentName);
					String status =  URLDecoder.decode(row[11].replaceAll("\"", "").trim(),
							StandardCharsets.UTF_8.toString());
					approveLeaveDTO.setStatus(status);
					String remark = row[12];
					String remarks =  URLDecoder.decode(remark.replaceAll("^\"+|\"+$", ""),"UTF-8");
					remarks=remarks.replaceAll("]", "").trim();
					approveLeaveDTO.setApproverRemarks(remarks.substring(0,remarks.length()-1));
					approveLeaveDTO.setUser(userName);

					String fromDate = row[5].replaceAll("\"", "").trim();
					String toDate = row[6].replaceAll("\"", "").trim();

					LOGGER.info(approveLeaveDTO);
					ApproveLeaveResponseDTO responseObject = new ApproveLeaveResponseDTO();
					try {
						responseObject = dataSourceLMS
								.approveLeave(approveLeaveDTO);
						String output = responseObject.getStatus();
						if ("Success".equalsIgnoreCase(output)) {
							// getting mail params from db and sending mail
							List<String> mailList = new ArrayList<>();
							mailList.add(responseObject.getTransactionId());
							mailList.add(responseObject.getFromEmail());
							mailList.add(responseObject.getToEmail());
							mailList.add("Time Off " + status);

							
							
							String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding: 3px 10px;'";
							String formatTableBodyRight = "'border-bottom:1px solid #888888;padding:3px 10px;'";
							String mailBody = "<div style='font-weight:bold;'>Time Off Request Details>Time Off Approval</div><div><br><table style='width: 100%; border: 1px solid #888888; border-bottom: 0;border-collapse: separate;border-spacing: 0px;margin: 15px 0;'><tbody><tr><td style="+ formatTableBodyLeft
														+ " >Name:</td><td style="+ formatTableBodyRight
														+ "> "+ userName + "</td></tr>";
														mailBody += "<tr><td style="+formatTableBodyLeft+">Type</td> <td style="+formatTableBodyRight
														         + ">"+approveLeaveDTO.getRequestType()+"</td></tr>";
														mailBody += "<tr><td style="+formatTableBodyLeft+">Initiated by</td> <td style="
														         + formatTableBodyRight
														         + ">"+ userName + "</td></tr>";
														mailBody += "<tr><td style="+ formatTableBodyLeft
														         + ">Status</td><td style="+ formatTableBodyRight
														         + "> " + status+ "</td></tr>";
														mailBody += "<tr><td style="+ formatTableBodyLeft
														         + ">Scheduled at</td> <td style="+ formatTableBodyRight
														         + ">"+ fromDate + " - " + toDate + "</td></tr>";
														mailBody += "<tr><td style="+ formatTableBodyLeft
														         + ">Notes</td> <td style="+ formatTableBodyRight
														         + ">" + approveLeaveDTO.getApproverRemarks()+ "</td></table></div>";
							

							String mailResponse = mailSend(mailList, mailBody);
							// sending mail response and Transaction id for
							// updation of record
							ApplyLeaveResponseDTO applyLeaveResponseDTO = new ApplyLeaveResponseDTO();
							applyLeaveResponseDTO.setStatus(mailResponse);
							applyLeaveResponseDTO
							.setTransactionId(responseObject
									.getTransactionId());

							dataSourceLMS.updateEmail(applyLeaveResponseDTO);

							// teleopti approve
							if (approveLeaveDTO.getStatus().equalsIgnoreCase(
									"approved")) {
								teleDto = teleoptiWebserviceData
										.getTeleoptiApproveData(approveLeaveDTO);
								if ((approveLeaveDTO.getRequestType()).equalsIgnoreCase("OVT")) {
									teleoptiAgentClient.addOverTimeActivity(
											teleDto.getActivityId(),
											teleDto.getAgentId(),
											teleDto.getStartDate(),
											teleDto.getEndDate(),teleDto.getOverTimeException());
								} else {
									teleoptiAgentClient.addAbsence(
											teleDto.getActivityId(),
											teleDto.getAgentId(),
											teleDto.getStartDate(),
											teleDto.getEndDate());
								}
							}
						}
					
					} catch (Exception e) {
						LOGGER.error(e.getMessage(), e);
						throw new Exception(DashboardConstants.SQL_EXCEPTION);
					}
				}
			}

			List<AgentsListForManagerDTO> agentList = new ArrayList<>();
			Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
			Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
			Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();


			// fetching agentdetails for manager
		/*	agents loading issue,not loaded 1-25-2018 start
		 * ApproveLeaveDTO approveLeaveDTO = new ApproveLeaveDTO();
			approveLeaveDTO.setSupervisorID(supervisorid)
			agents loading issue,not loaded 1-25-2018 End;
			
			*/
			try {

				agentList = dataSourceLMS
						.getAgentsListForManager(userid);

				// fetching remaining leaves after approval
				String agentId = request.getParameter("agent");
				if (StringUtils.isNotBlank(agentId)) {
					leaveHistoryTableDetailMap = dataSourceLMS
							.getRequestAwaitingApprovalAgent(agentId);
				} else {
					leaveHistoryTableDetailMap = dataSourceLMS
							.getRequestAwaitingApprovalManagerforAjax(userid);
				}


				leaveBalanceTableDetailMap = dataSourceLMS.leaveBalnceTable(agentId);
				leaveProjectionTableDetailMap = dataSourceLMS.leaveProjectionTable(agentId);

			} catch (SQLException | NamingException  e) {
				LOGGER.error(e.getMessage(), e);
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}

			request.setAttribute(DashboardConstants.MANAGERAPPROVETREE,
					agentList);
			getAgentActivityAndLoginStatMap.put(DashboardConstants.lEAVEBALANCETABLEMAP,
					leaveBalanceTableDetailMap);
			request.setAttribute(DashboardConstants.lEAVEHISTORYTABLEMAP,
					leaveHistoryTableDetailMap);
			getAgentActivityAndLoginStatMap.put(DashboardConstants.LEAVEPROJECTIONMAP,
					leaveProjectionTableDetailMap);
			getAgentActivityAndLoginStatMap.put("leaveHistoryTableDetailMap",
					leaveHistoryTableDetailMap);
		}
		LOGGER.info("Inside lmsApproveLeave() method");
		return getAgentActivityAndLoginStatMap;

	}
	
	/**
	 * @Purpose: Used to retrieve information about leave details like approved,applied,pending of an agent. Login User : Manager
	 * @param model
	 * @param request
	 * @param session
	 * @return list of maps which contains lEAVEBALANCETABLEMAP, lEAVEHISTORYTABLEMAP, LEAVEPROJECTIONMAP.
	 */

	@RequestMapping(value = "/getBalanceTable", method = RequestMethod.POST)
	public @ResponseBody Map<String, Map<String, List<?>>> getLeaveBalanceTable(ModelMap model,
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside getLeaveBalanceTable() method");
		String agentId = request.getParameter("agentId");
		Map<String, Map<String, List<?>>> getAgentActivityAndLoginStatMap = new HashMap<String, Map<String, List<?>>>();
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveHistoryTableDetailMap = new HashMap<>();
		Map<String, List<?>> calenderLeaveMap = new HashMap<>();
		Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();
		
		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		String json = null;
		List<String> calenderLeaveList = new ArrayList<String>();

		try {
			leaveBalanceTableDetailMap = dataSourceLMS
					.leaveBalnceTable(agentId);
			
			leaveHistoryTableDetailMap = dataSourceLMS
					.getRequestAwaitingApprovalAgent(agentId);

			calenderLeaveStatusList = calenderDao.getLeaveStatus(agentId);
			leaveProjectionTableDetailMap = dataSourceLMS.leaveProjectionTable(agentId);


			if (calenderLeaveStatusList != null
					&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter
						.getJsonList(calenderLeaveStatusList);
				calenderLeaveList.add(json);
			}
			calenderLeaveMap.put("json", calenderLeaveList);
			System.out
			.println("agentId  is :: " + agentId + " json :: " + json);

			getAgentActivityAndLoginStatMap.put("leaveBalanceTableDetailMap",
					leaveBalanceTableDetailMap);
			getAgentActivityAndLoginStatMap.put("leaveHistoryTableDetailMap",
					leaveHistoryTableDetailMap);
			getAgentActivityAndLoginStatMap.put("jsoncalenderLeaveMap",
					calenderLeaveMap);
			getAgentActivityAndLoginStatMap.put(DashboardConstants.LEAVEPROJECTIONMAP,
					leaveProjectionTableDetailMap);

		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting getLeaveBalanceTable() method");

		return getAgentActivityAndLoginStatMap;
	}

	/**
	 * @Purpose: Used to do ajax refresh after apply leave . Login User : Agent
	 * @param model
	 * @param request
	 * @param session
	 * @return list of maps which contains calenderLeaveList.
	 */
	
	@RequestMapping(value = "/applyLeaveCalandarRefresh", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, Map<String, List<?>>> applyLeaveCalandarRefresh(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside getLeaveBalanceTable() method");
		String agentId = request.getParameter("agentId");
		String userid = "";
		String user = request.getParameter("userType");
		if (user.equalsIgnoreCase("agent")) {
			userid = (String) session.getAttribute("userid");
		} else {
			userid = request.getParameter("agent_id");
		}

		Map<String, Map<String, List<?>>> getAgentActivityAndLoginStatMap = new HashMap<String, Map<String, List<?>>>();
		Map<String, List<?>> calenderLeaveMap = new HashMap<>();

		List<CalenderLeaveStatusDTO> calenderLeaveStatusList = null;
		String json = null;
		List<String> calenderLeaveList = new ArrayList<String>();

		try {

			calenderLeaveStatusList = calenderDao.getLeaveStatus(userid);

			LOGGER.info("calenderLeaveStatusList size is  :: "
					+ calenderLeaveStatusList.size());

			if (calenderLeaveStatusList != null
					&& calenderLeaveStatusList.size() > 0) {
				json = CalenderJsonConverter
						.getJsonList(calenderLeaveStatusList);
				calenderLeaveList.add(json);
			}
			System.out
			.println("agentId  is :: " + agentId + " json :: " + json);
			calenderLeaveMap.put("json", calenderLeaveList);
			getAgentActivityAndLoginStatMap.put("jsoncalenderLeaveMap",
					calenderLeaveMap);

		} catch (Exception e) {
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		LOGGER.info("Exiting getLeaveBalanceTable() method");

		return getAgentActivityAndLoginStatMap;
	}

	/**
	 * @Purpose: Used to get Leave Type
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/leaveType", method = RequestMethod.GET)
	public @ResponseBody
	List<String> getLeaveType(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Inside getLeaveType() method");
		List<String> leaveTypeList = new ArrayList<String>();
		try {
			leaveTypeList = dataSourceLMS.getLeaveType();
		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting getLeaveType() method");

		return leaveTypeList;
	}

	/**
	 * @Purpose: Used to get Supervisor List
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/supervisor", method = RequestMethod.GET)
	public @ResponseBody
	List<String> getSupervisor(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Inside getSupervisor() method");
		
		String userid = (String) session.getAttribute("userid");
		
		List<String> supervisorList = new ArrayList<String>();
		try {
			supervisorList = dataSourceLMS.getSupervisor(userid);
		} catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting getSupervisor() method");

		return supervisorList;
	}

	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/apply", method = RequestMethod.POST)
	public @ResponseBody
	ApplyLeaveDTO applyForLeave(ModelMap model, HttpServletRequest request,
			HttpSession session) throws Exception {
		LOGGER.info("Inside applyForLeave() method");
		String userName = (String) session.getAttribute("username");
		List<String> mailList = new ArrayList<String>();
		String supuserid = (String) session.getAttribute("userid");
		ApplyLeaveDTO applyLeaveDTO = new ApplyLeaveDTO();
		// agent id from username
		applyLeaveDTO.setAgentID(supuserid);
		applyLeaveDTO.setSupervisorName((String) request
				.getParameter("supervisor"));
		applyLeaveDTO.setLeaveType((String) request.getParameter("leaveType"));
		applyLeaveDTO.setFromDate((String) request.getParameter("fromDate"));
		applyLeaveDTO.setToDate((String) request.getParameter("toDate"));
		applyLeaveDTO.setStartTime((String) request.getParameter("startTime"));
		applyLeaveDTO.setEndTime((String) request.getParameter("endTime"));
		applyLeaveDTO
		.setNoOfDaysHrs((String) request.getParameter("daysHours"));
		applyLeaveDTO.setUnitOfMeasurement((String) request
				.getParameter("unitOfMeasurement"));
		applyLeaveDTO.setStatus("applied");
		applyLeaveDTO.setRemarks( URLDecoder.decode(((String) request.getParameter("remarks")),"UTF-8"));
		applyLeaveDTO.setLoginId(userName);
		ApplyLeaveResponseDTO responseObject = new ApplyLeaveResponseDTO();
		if(applyLeaveDTO.getLeaveType().equalsIgnoreCase("OVT")){
			applyLeaveDTO.setOverTimeActivity(request.getParameter("overTimeActivity"));
		}else{
			applyLeaveDTO.setOverTimeActivity("");
		}
		String mailResponse = "";
		String output = "";
		try {
			String endDate = request.getParameter("toDate");
			// Applying leave without email msg
			Date cutOffDate = dataSourceLMS.getCutOFFDate();
			LOGGER.info("CutOff Date :" + cutOffDate);
			LOGGER.info(endDate);

			SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
			java.util.Date date = sdf1.parse(endDate);
			java.sql.Date sqlEndDate = new java.sql.Date(date.getTime());

			LOGGER.info(sqlEndDate);
			if (cutOffDate.after(sqlEndDate)||cutOffDate.equals(sqlEndDate)) {
				responseObject = dataSourceLMS.applyForLeave(applyLeaveDTO);
				// response
				output = responseObject.getStatus();
				if (output.equalsIgnoreCase("Your Time Off request has been Applied")) {
					// getting mail params from db and sending mail
					mailList = dataSourceLMS.getEmailOfSuperviser(applyLeaveDTO);
					String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding: 3px 10px;'";
					String formatTableBodyRight = "'border-bottom:1px solid #888888;padding:3px 10px;'";
					String mailBody = "<div style='font-weight:bold;'>Time Off Request Details :</div><div><br><table style='width: 100%; border: 1px solid #888888; border-bottom: 0;border-collapse: separate;border-spacing: 0px;margin: 15px 0;'><tbody><tr><td style="
							+ formatTableBodyLeft
							+ ">Name:</td><td style="
							+ formatTableBodyRight
							+ "> "
							+ userName.toUpperCase()
							+ "</td></tr>";
					mailBody += "<tr><td style=" + formatTableBodyLeft
							+ ">Time Off_Type</td> <td style="
							+ formatTableBodyRight + ">"
							+ applyLeaveDTO.getLeaveType() + "</td></tr>";
					if(applyLeaveDTO.getLeaveType().equalsIgnoreCase("OVT")){
						mailBody += "<tr><td style=" + formatTableBodyLeft
								+ ">OverTime_Activity</td> <td style="
								+ formatTableBodyRight + ">"
								+ applyLeaveDTO.getOverTimeActivity() + "</td></tr>";
				     }
					mailBody += "<tr><td style=" + formatTableBodyLeft
							+ ">From_Date</td> <td style="
							+ formatTableBodyRight + ">"
							+ applyLeaveDTO.getFromDate() + "</td></tr>";
					
					mailBody += "<tr><td style=" + formatTableBodyLeft
							+ ">To_Date</td><td style=" + formatTableBodyRight
							+ "> " + applyLeaveDTO.getToDate() + "</td></tr>";
					mailBody += "<tr><td style=" + formatTableBodyLeft
							+ ">No of Days/Hours</td><td style="
							+ formatTableBodyRight + ">"
							+ applyLeaveDTO.getNoOfDaysHrs() + " "
							+ applyLeaveDTO.getUnitOfMeasurement()
							+ "</td></tr>";
					mailBody += "<tr><td style=" + formatTableBodyLeft
							+ ">Status</td><td style=" + formatTableBodyRight
							+ ">" + applyLeaveDTO.getStatus()
							+ "</td></tr></table></div>";
					mailList.add(responseObject.getEmailSubject());
					mailResponse = mailSend(mailList, mailBody);
					// sending mail response and Transaction id for updation of record
					responseObject.setStatus(mailResponse);
					dataSourceLMS.updateEmail(responseObject);
					applyLeaveDTO.setOutputStatus(output);
					applyLeaveDTO.setLeaveProjectionTableDetailMap( dataSourceLMS.leaveProjectionTable(supuserid));
					applyLeaveDTO.setLeaveBalanceTableDetailMap( dataSourceLMS.leaveBalnceTable(supuserid));

				} else {
					applyLeaveDTO.setOutputStatus(output);
					applyLeaveDTO.setLeaveProjectionTableDetailMap( dataSourceLMS.leaveProjectionTable(supuserid));
					applyLeaveDTO.setLeaveBalanceTableDetailMap( dataSourceLMS.leaveBalnceTable(supuserid));
					return applyLeaveDTO;
				}
			} else {
				output = "Not Allowed After Cut-Off Date";
				applyLeaveDTO.setOutputStatus(output);
				applyLeaveDTO.setLeaveProjectionTableDetailMap( dataSourceLMS.leaveProjectionTable(supuserid));
				applyLeaveDTO.setLeaveBalanceTableDetailMap( dataSourceLMS.leaveBalnceTable(supuserid));
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			applyLeaveDTO.setOutputStatus(DashboardConstants.SQL_EXCEPTION);
			applyLeaveDTO.setLeaveProjectionTableDetailMap( dataSourceLMS.leaveProjectionTable(supuserid));
			applyLeaveDTO.setLeaveBalanceTableDetailMap( dataSourceLMS.leaveBalnceTable(supuserid));
			return applyLeaveDTO;
		} 
		LOGGER.info("Exiting applyForLeave() method");

		return applyLeaveDTO;
	}



	/**
	 * This method will get executed when user clicks on "TimesheetAdjustment" link under TOMS in home screen
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/TOMSTimesheet", method = RequestMethod.POST)
	public String getTOMSTimesheet(ModelMap model, HttpServletRequest request,
			HttpSession session) throws Exception {
		LOGGER.info("Inside getTOMSApproveLeave() method");
		
		List<String> getcal = new ArrayList<>();
		List<String> getPeoplesoftCode = new ArrayList<>();

		try {
			getcal = LMSTimsheetAdjustment.getDateForTimesheet();
			getPeoplesoftCode = LMSTimsheetAdjustment.getPeoplesoftCode();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		request.setAttribute(DashboardConstants.FULLCAL, getcal);
		request.setAttribute(DashboardConstants.getPeoplesoftCode,
				getPeoplesoftCode);

		LOGGER.info("Inside getTOMSApproveLeave() method");

		return "LMS/TOMS_Timesheet";
	}

	/**
	 * This method will get executed when user clicks on "TimesheetApproval" link under TOMS in home screen
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/TOMSTimesheetApproval", method = RequestMethod.POST)
	public String getTOMSTimesheetApproval(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside getTOMSApproveLeave() method");
		
		String userId = (String) session.getAttribute("userid");
		
		StringBuilder tree = new StringBuilder();
		try {
			tree = LMSTimsheetAdjustment.timsheetTree(userId);

			LOGGER.info(tree);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		request.setAttribute("tree", tree.toString());
		LOGGER.info("Inside getTOMSApproveLeave() method");

		return "LMS/TOMS_Timesheet_Approval";
	}

	/**
	 * @param mailAddress
	 * @param mailBody
	 * @return
	 */
	public String mailSend(final List<String> mailAddress, final String mailBody) {
		LOGGER.info("Inside mailSend() method");
		try {
			mailSender.send(new MimeMessagePreparator() {
				@Override
				public void prepare(MimeMessage mimeMessage) throws Exception {
					MimeMessageHelper messageHelper = new MimeMessageHelper(
							mimeMessage, true, "UTF-8");
					messageHelper.setFrom(mailAddress.get(1));
					messageHelper.addTo(mailAddress.get(2));
					
					messageHelper.setSubject(mailAddress.get(3));
					messageHelper.setText(mailBody, true);
					
				}

			});
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return "Mail not sent due to " + e.getMessage();
		}
		LOGGER.info("Exiting mailSend() method");
		return "Email Sent Successfully";
	}

	/**
	 * This method will gets execute when user clicks on "Date"  in "Time Sheet Adjustment"
	 * @param model
	 * @param request
	 * @param session
	 * @return maps-display all grids(Table)- Avaya Activity,Shift Activity,loginStat,People Soft data & Discrepancy in screen
	 * @throws Exception
	 */
	@RequestMapping(value = "/LMSDateClick", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Map<String, List<?>>> agentActivities(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside agentActivities() method");
		Map<String, List<?>> getAgentActivities = new HashMap<>();
		Map<String, List<?>> getLogiStat = new HashMap<>();
		Map<String, List<?>> agentShiftData = new HashMap<>();
		Map<String, List<?>> agentAvayaActivities = new HashMap<>();
		Map<String, List<?>> agentLoginStats  = new HashMap<>();
		Map<String, List<?>> peopleSoftData  = new HashMap<>();
		Map<String, List<?>> agentScheduleActivities   = new HashMap<>();

		Map<String, Map<String, List<?>>> getAgentActivityAndLoginStatMap = new HashMap<String, Map<String, List<?>>>();
		Map<String, List<?>> buttonStatusMap = new HashMap<>();
		try {
			String agentId = (String) session.getAttribute("userid");
			String getDate = request.getParameter("dateFormate");
			
			peopleSoftData = LMSTimsheetAdjustment.generatePSoftData(agentId, getDate);
			getAgentActivities = LMSTimsheetAdjustment.getAgentDiscrapancy(getDate, agentId);
			getLogiStat = LMSTimsheetAdjustment.getLoginStats(getDate, agentId);
			agentShiftData=LMSTimsheetAdjustment.getAgentActivity(getDate, agentId,DashboardConstants.AgentShiftData);
			agentAvayaActivities=LMSTimsheetAdjustment.getAgentActivity(getDate, agentId,DashboardConstants.AgentAvayaActivities);
			agentLoginStats=LMSTimsheetAdjustment.getAgentActivity(getDate, agentId,DashboardConstants.AgentLoginActivities);
			agentScheduleActivities=LMSTimsheetAdjustment.getAgentActivity(getDate, agentId,DashboardConstants.AgentScheduleActivities);



			getAgentActivityAndLoginStatMap.put("getAgentActivities",getAgentActivities);
			getAgentActivityAndLoginStatMap.put("getLogiStat", getLogiStat);
			buttonStatusMap.put("buttonStatus",submintButtonSatus(agentId, getDate));
			// Added for ps button status
			getAgentActivityAndLoginStatMap.put("buttonStatus", buttonStatusMap);
			getAgentActivityAndLoginStatMap.put("agentShiftData", agentShiftData);
			getAgentActivityAndLoginStatMap.put("agentAvayaActivityMap", agentAvayaActivities);
			getAgentActivityAndLoginStatMap.put("agentLoginActivityMap", agentLoginStats);
			getAgentActivityAndLoginStatMap.put("peopleSoftData", peopleSoftData);
			getAgentActivityAndLoginStatMap.put("agentScheduleActivityMap", agentScheduleActivities);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		LOGGER.info("Exiting agentActivities() method");
		return getAgentActivityAndLoginStatMap;
	}

	/**
	 * This method will gets execute when user make adjustment and  clicks on "save" button in "Time Sheet Adjustment"
	 * @param model
	 * @param request
	 * @param session
	 * @return success or failure
	 * @throws SqlException
	 */
	@RequestMapping(value = "/timesheetAdjust", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	List<String> modalAdjust(ModelMap model, HttpServletRequest request,
			HttpSession session) throws Exception {
		LOGGER.info("Inside modalAdjust() method");
		List<String> status = new ArrayList<>();

		String userName = (String) session.getAttribute("username");
		String[] modulAdjustData = request.getParameterValues("adjustData[]");
		
		String interval = request.getParameter("agent_interval");
		int transactionId = Integer.parseInt(request.getParameter("transc_id"));
		String date = request.getParameter("getCurrentDate");
		List<String> getAddress = new ArrayList<>();
		String mailStatus = "";
		String mailStatusUpdate = "";
		

		for (int i = 0; i < modulAdjustData.length; i++) {
			String[] browsedAttachments = modulAdjustData[i].split(",");
			try {
				status = LMSTimsheetAdjustment.modalAdjust(transactionId,
						browsedAttachments[1], browsedAttachments[0],
						"Applied", "", userName);
				if (Integer.parseInt(status.get(0)) == 0) {
					getAddress = LMSTimsheetAdjustment.getTimsheetMailAddress(
							transactionId, browsedAttachments[1],
							browsedAttachments[0], "Applied");
					String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
					String formatTableBodyRight = "'border-bottom:1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
					String mailBody = "<div style='font-weight:bold; margin:15px 0px;'>Time Off Adjustment Details :</div><div><table border='0' cellpadding='0' cellspacing='0' style='width: 100%;border:1px solid #888888;border-bottom:0px;border-collapse:separate;border-spacing:0px;margin-top:15px;margin-bottom:15px;margin-left:0px;margin-right:0px;'><tbody><tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Name</td><td valign='middle' style="
							+ formatTableBodyRight
							+ "> "
							+ userName
							+ "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Adjustment Type</td> <td valign='middle' style="
							+ formatTableBodyRight + ">"
							+ browsedAttachments[1] + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Adjustment Time</td> <td valign='middle' style="
							+ formatTableBodyRight + ">"
							+ browsedAttachments[0] + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Date</td><td valign='middle' style="
							+ formatTableBodyRight + "> " + date + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Interval</td> <td valign='middle' style="
							+ formatTableBodyRight + ">" + interval
							+ "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Status</td><td valign='middle' style="
							+ formatTableBodyRight
							+ ">Applied </td></table></div>";

					mailStatus = mailSend(getAddress, mailBody);
					mailStatusUpdate = LMSTimsheetAdjustment
							.updateTimsheeetMailStatus(getAddress.get(0),
									mailStatus);
				}
			} catch (Exception e) {
				LOGGER.error(mailStatusUpdate);
				throw new Exception(DashboardConstants.SQL_EXCEPTION);
			}

		}
		LOGGER.info("Exiting modalAdjust() method");
		return status;
	}

	/**
	 * This method trigger when user clicks on "Date" in time sheet adjustment screen.
	 * @param agentId
	 * @param getDate
	 * @return  status- already submitted to peopleSoft or not for clicked date.
	 * @throws SQLException
	 * @throws NamingException
	 */
	private List<String> submintButtonSatus(String agentId, String getDate)
			throws SQLException, NamingException {
		LOGGER.info("Inside submintButtonSatus() method");
		List<String> psSubmitButtonStatus = new ArrayList<String>();
		;

		psSubmitButtonStatus.add(LMSTimsheetAdjustment
				.checkSubmitToPSButtonStatus(agentId, getDate).contains(
						"Disable") ? "true" : "false");
		LOGGER.info("Exiting submintButtonSatus() method");
		return psSubmitButtonStatus;

	}

	/**
	 * This method execute when user clicks on "Agent" in time sheet Approval screen.
	 * @param model
	 * @param request
	 * @param session
	 * @return Map- having time sheet discrepancy record
	 * @throws SQLException
	 * @throws NamingException
	 */
	@RequestMapping(value = "/LMSApprovalAgentClick", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, List<?>> agentWiseClick(ModelMap model,
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside agentWiseClick() method");
		Map<String, List<?>> getAgentActivities = new HashMap<>();

		try {

			String getDate = request.getParameter("dateFormate");
			String agentId = request.getParameter("id");

			getAgentActivities = LMSTimsheetAdjustment.getAgentDiscrapancy(getDate, agentId);

		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting agentWiseClick() method");
		return getAgentActivities;
	}

	/** 
	 * This method will gets execute when supervisor or lead clicks on "Discrepancy" in time sheet approval screen.
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/getModidifiedAgentActivity", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, List<?>> getModidifiedAgentActivity(ModelMap model,
			HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside getModidifiedAgentActivity() method");
		Map<String, List<?>> getModAgentActivities = new HashMap<>();
		try {

			String agentId = request.getParameter("id");

			getModAgentActivities = LMSTimsheetAdjustment
					.getAgentModifiedActivities(agentId);

		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting agentWiseClick() method");
		return getModAgentActivities;
	}

	/**
	 * This method will get executed when supervisor or lead "Approved/Declined" the Discrepancy and  clicks on "save" button in  TOMS Time sheet approval screen
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/timesheetApprovalAdjust", method = RequestMethod.POST)
	public @ResponseBody
	List<String> timesheetApprovalAdjust(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside timesheetApprovalAdjust() method");
		List<String> status = new ArrayList<>();
		List<String> getAddress = new ArrayList<>();
		String mailStatus = "";
		@SuppressWarnings("unused")
		String mailStatusUpdate = "";

		String userName = (String) session.getAttribute("username");
		String[] modulAdjustData = request.getParameterValues("adjustData[]");
		
		String interval = request.getParameter("time_Interval");
		int transactionId = Integer.parseInt(request.getParameter("transc_id"));
		String date = request.getParameter("getCurrentDate");

		for (int i = 0; i < modulAdjustData.length; i++) {
			String[] browsedAttachments = modulAdjustData[i].split(",");
			try {
				status = LMSTimsheetAdjustment.modalAdjust(transactionId,
						browsedAttachments[0], browsedAttachments[1],
						browsedAttachments[2], browsedAttachments[3], userName);
				if (Integer.parseInt(status.get(0)) == 0) {
					getAddress = LMSTimsheetAdjustment.getTimsheetMailAddress(
							transactionId, browsedAttachments[0],
							browsedAttachments[1], browsedAttachments[2]);
					String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
					String formatTableBodyRight = "'border-bottom:1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
					String mailBody = "<div style='font-weight:bold; margin:15px 0px;'>Time Off Adjustment Details :</div><div><table border='0' cellpadding='0' cellspacing='0' style='width: 100%;border:1px solid #888888;border-bottom:0px;border-collapse:separate;border-spacing:0px;margin-top:15px;margin-bottom:15px;margin-left:0px;margin-right:0px;'><tbody><tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Name</td><td valign='middle' style="
							+ formatTableBodyRight
							+ "> "
							+ userName
							+ "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Adjustment Type</td> <td valign='middle' style="
							+ formatTableBodyRight + ">"
							+ browsedAttachments[0] + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Adjustment Time</td> <td valign='middle' style="
							+ formatTableBodyRight + ">"
							+ browsedAttachments[1] + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Date</td><td valign='middle' style="
							+ formatTableBodyRight + "> " + date + "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Interval</td> <td valign='middle' style="
							+ formatTableBodyRight + ">" + interval
							+ "</td></tr>";
					mailBody += "<tr><td valign='middle' style="
							+ formatTableBodyLeft
							+ ">Status</td><td valign='middle' style="
							+ formatTableBodyRight + ">"
							+ browsedAttachments[2] + "</td></table></div>";

					mailStatus = mailSend(getAddress, mailBody);
					mailStatusUpdate = LMSTimsheetAdjustment
							.updateTimsheeetMailStatus(getAddress.get(0),
									mailStatus);
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
				throw new Exception(DashboardConstants.SQL_EXCEPTION);
			}

		}
		LOGGER.info("Exiting timesheetApprovalAdjust() method");
		return status;
	}


	/**
	 * @param mailAddress
	 * @return
	 */
	public String mailSendForInvite(final SendEmailDTO mailAddress) {
		LOGGER.info("Inside mailSendForInvite() method");
		try {
			mailSender.send(new MimeMessagePreparator() {
				@Override
				public void prepare(MimeMessage mimeMessage) throws Exception {
					MimeMessageHelper messageHelper = new MimeMessageHelper(
							mimeMessage, true, "UTF-8");
					messageHelper.setFrom(mailAddress.getFrom().trim());
					messageHelper.addTo(mailAddress.getTo().trim());
					messageHelper.setSubject(mailAddress.getSubject());
					messageHelper.setText(mailAddress.getMsg(), true);
				}
			});
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return "Mail not sent due to " + e.getMessage();
		}
		LOGGER.info("Exiting mailSendForInvite() method");
		return "Email Sent Successfully";
	}

	/**
	 * This method will gets execute when user clicks on "Submit To People Soft" button in "Time Sheet Approval Screen"
	 * @param model
	 * @param request
	 * @param session
	 * @return Map
	 * 1.)List of Record which sends to PeopleSoft for given Agent Id & Date
	 * 2.)People Soft update status(Success/Fail)
	 * @throws Exception
	 */
	@RequestMapping(value = "/submitToPSoft", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, List<?>> submitToPSoft(ModelMap model,	HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside submitToPSoft(ModelMap model,	HttpServletRequest request, HttpSession session)");
		Map<String, List<?>> getModAgentActivities = new HashMap<>();
		List<String> statusmsg = new ArrayList<>();
		try {

			String getDate = request.getParameter("get_Date");
			String agentId = (String) session.getAttribute("userid");
			String psoftStatus = request.getParameter("status");

			String updateStatus = "";
			getModAgentActivities = LMSTimsheetAdjustment.generatePSoftData(agentId, getDate);//Gets List if Agent Activities By Agent Id and Date

			if (psoftStatus.equalsIgnoreCase("false")) {
				if (!getModAgentActivities.isEmpty()) {
					BuildElapsedTimeAddElements gendrateElapsedTimeAddElements = new BuildElapsedTimeAddElements();

					String recordSentToPSStatus = gendrateElapsedTimeAddElements.sendPayrollRecordToPeopleSoft(getModAgentActivities,agentId,getDate);//Sends PayRoll record from TOMS to PeopleSoft

					String seqForPSList = "";
					String agentIdList = "";
					String durDateList = "";
					String psCodeList = "";
					String totalHrsList = "";
					String bupForPSList = "";
					String prjForPSList = "";
					String actForPSList = "";					
									
					statusmsg.add(recordSentToPSStatus.contains("Success") ? "true" : "false");
					
					getModAgentActivities.put("psoftStatus", statusmsg);

					@SuppressWarnings("unchecked")
					List<List<String>> reportList = (List<List<String>>) getModAgentActivities.get(DashboardConstants.psoftColumnValues);
					for (List<String> record : reportList) {
						seqForPSList = seqForPSList.equalsIgnoreCase("") ? (seqForPSList + record.get(0)) : (seqForPSList + "," + record.get(0));
						agentIdList = agentIdList.equalsIgnoreCase("") ? (agentIdList + record.get(1)) : (agentIdList + "," + record.get(1));
						durDateList = durDateList.equalsIgnoreCase("") ? (durDateList + record.get(2)) : (durDateList + "," + record.get(2));
						psCodeList = psCodeList.equalsIgnoreCase("") ? (psCodeList + record.get(3)) : (psCodeList + "," + record.get(3));
						totalHrsList = totalHrsList.equalsIgnoreCase("") ? (totalHrsList + record.get(4)) : (totalHrsList + "," + record.get(4));
						bupForPSList = bupForPSList.equalsIgnoreCase("") ? (bupForPSList + record.get(5)) : (bupForPSList + "," + record.get(5));
						prjForPSList = prjForPSList.equalsIgnoreCase("") ? (prjForPSList + record.get(6)) : (prjForPSList + "," + record.get(6));
						actForPSList = actForPSList.equalsIgnoreCase("") ? (actForPSList + record.get(7)) : (actForPSList + "," + record.get(7));
					}
					
					LOGGER.info(recordSentToPSStatus);
					
					if (recordSentToPSStatus.contains("Success")) {//If Payroll records sends to People Soft is Success.
						
						updateStatus = LMSTimsheetAdjustment.updatePeopleSoftStatus(agentIdList, durDateList, psCodeList, totalHrsList, bupForPSList, prjForPSList, actForPSList);//Update People Soft Success status in TOMS DB
						LOGGER.info(updateStatus);

					}else{//If Payroll records sends to People Soft gets Fail or error.
						
						updateStatus = LMSTimsheetAdjustment.insertIntoPeopleSoftTempTbl(seqForPSList, agentIdList, durDateList, psCodeList, totalHrsList, bupForPSList, prjForPSList, actForPSList);//Update People Soft Success status in TOMS DB
						LOGGER.info(updateStatus);
						
					}
					
				} else {
					LOGGER.info("There is no Payroll record for AgentId = "	+ agentId + " Date = " + getDate);
				}
			}

		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		LOGGER.info("Exit submitToPSoft(ModelMap model,	HttpServletRequest request, HttpSession session)");
		return getModAgentActivities;
	}


	/* Invite Screen Methods Starts*/

	/**
	 * This method will get executed when user clicks on "Invite" link under TOMS in home screen
	 * This will load/show up the "Invite" screen 
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/TOMSInvite", method = RequestMethod.GET)
	public String loadInviteScreen(ModelMap model, HttpServletRequest request, HttpSession session) {

		LOGGER.info("Inside loadInviteScreen(ModelMap model, HttpServletRequest request, HttpSession session)");

		String userId = (String) session.getAttribute("userid");//Current login user ID
		LoadInviteDTO loadInviteDTO = new LoadInviteDTO();
		LinkedHashMap<String, String> supervisorsList = new LinkedHashMap<String, String>();
		LinkedHashMap<String, String> agentsList = new LinkedHashMap<String, String>();
		LinkedHashMap<String, String> selectedDefaultAgents = new LinkedHashMap<String, String>();		
		LinkedHashMap<String, ScheduledInviteDTO> scheduledInvites = new LinkedHashMap<String, ScheduledInviteDTO>();

		try {
			scheduledInvites = dataSourceLMS.getScheduledInvitesByLoginUserID(userId);//Get List of Scheduled Invites 
			supervisorsList = dataSourceLMS.getAllSupervisor(userId);//Get All Supervisors
			selectedDefaultAgents = dataSourceLMS.getAllAgentsForSupervisor(userId);//Get All Agents for given Supervisors Id	

			//Setting all records in an Object
			loadInviteDTO = new LoadInviteDTO(supervisorsList,
					agentsList,
					selectedDefaultAgents,
					scheduledInvites);

			//Setting record to request Attribute
			request.setAttribute(DashboardConstants.RECORD_FOR_LOAD_INVITE_SCREEN, loadInviteDTO);

		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting loadInviteScreen(ModelMap model, HttpServletRequest request, HttpSession session)");
		return "LMS/TOMS_Apply_invite";		
	}	

	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/loadAgents", method = RequestMethod.GET)
	public @ResponseBody LinkedHashMap<String, String> loadAgents(ModelMap model, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Inside loadAgents() method");

		String supervisorId = request.getParameter("supervisorId");
		LinkedHashMap<String, String> agentForsupervisor = new LinkedHashMap<String, String>();
		try {
			agentForsupervisor = dataSourceLMS.getAllAgentsForSupervisor(supervisorId);//Get List of Agents for SupervisorId
			request.setAttribute(DashboardConstants.LMS_AGENTS, agentForsupervisor);
		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		LOGGER.info("Exiting loadAgents() method");

		return agentForsupervisor;
	}

	/**
	 * Used to remove Duplicates from select Participants list in Invite screen
	 * @param model
	 * @param request
	 * @param session
	 * @return selectedParticipantsMap which contains agentsList, supervisorList, agentsSelected
	 */
	@RequestMapping(value = "/removeDuplicates", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, LinkedHashMap<String, String>> removeDuplicates(ModelMap model,	HttpServletRequest request, HttpSession session) {

		LOGGER.info("Inside removeDuplicates() method");

		Map<String, LinkedHashMap<String, String>> selectedParticipantsMap = new HashMap<String, LinkedHashMap<String, String>>();
		String agentsList = request.getParameter("agentsList");
		String supervisorlist = request.getParameter("supervisorlist");
		String agentsSelected = request.getParameter("agentsSelected");
		LinkedHashMap<String, String> agents = new LinkedHashMap<>();
		LinkedHashMap<String, String> selectesAgents = new LinkedHashMap<>();
		LinkedHashMap<String, String> supervisor = new LinkedHashMap<>();

		if(StringUtils.isNotEmpty(supervisorlist)){
			String[] supervisorlistArray=supervisorlist.split(",");
			for(int i=0 ; i<supervisorlistArray.length;i++){
				String array[]=supervisorlistArray[i].split(":");
				if(!supervisor.containsKey(array[0]) && !array[0].equalsIgnoreCase("0")){
					supervisor.put(array[0], array[1]);
				}
			}
		}
		if(StringUtils.isNotEmpty(agentsSelected)){
			String[] agentsSelectedList=agentsSelected.split(",");
			for(int i=0 ; i<agentsSelectedList.length;i++){
				String array[]=agentsSelectedList[i].split(":");
				if(!selectesAgents.containsKey(array[0]) && !array[0].equalsIgnoreCase("0")){
					selectesAgents.put(array[0], array[1]);
				}
			}
		}
		if(StringUtils.isNotEmpty(agentsList)){
			String[] agentListarry=agentsList.split(",");
			for(int i=0 ; i<agentListarry.length;i++){
				String array[]=agentListarry[i].split(":");
				if(!agents.containsKey(array[0]) && !selectesAgents.containsKey(array[0]) && !array[0].equalsIgnoreCase("0")){
					agents.put(array[0], array[1]);
				}				
			}		
		}

		selectedParticipantsMap.put("agentsListData", agents);
		selectedParticipantsMap.put("supervisorListData", supervisor);
		selectedParticipantsMap.put("selectedAgents", selectesAgents);


		LOGGER.info("Exiting removeDuplicates() method");

		return selectedParticipantsMap;
	}


	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/showParticipants", method = RequestMethod.GET)
	public @ResponseBody
	List<String> showParticipants(ModelMap model, HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside showParticipants() method");
		LoadInviteDTO loadInviteDTO = new LoadInviteDTO();
		String timeOffId = request.getParameter("timeOffid");
		List<String> participantslist = new ArrayList<>();
		loadInviteDTO.getAgentsList();
		try {
			participantslist = dataSourceLMS.showParticipants(timeOffId);			
		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting showParticipants() method");

		return participantslist;
	}


	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/cancelRCloseInvite", method = RequestMethod.POST)
	public @ResponseBody
	String cancelRCloseInvite(ModelMap model, HttpServletRequest request, HttpSession session) {
		LOGGER.info("Inside cancelRCloseInvite() method");

		String username = (String) session.getAttribute("username");
		String timeOffId = request.getParameter("timeOffid");
		String eventType = request.getParameter("eventType");
		String remarks = request.getParameter("remarks");

		String status = "";
		try {
			status = dataSourceLMS.cancelRCloseInvite(Integer.parseInt(timeOffId), eventType, remarks, username);

		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting cancelRCloseInvite() method");
		return status;
	}

	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/createNewInvite", method = RequestMethod.POST)
	public @ResponseBody List<String> createNewInvite(ModelMap model, HttpServletRequest request,	HttpSession session) {

		LOGGER.info("Inside createNewInvite() method");
		String responseStatus = "Error in Scheduling";

		List<TeleoptiCheckScheduleDTO> personAsSchedule = new ArrayList<TeleoptiCheckScheduleDTO>();

		List<TeleoptiCheckScheduleDTO> agentInTeleopti = new ArrayList<TeleoptiCheckScheduleDTO>();
		List<String>  responseStatusList=new ArrayList<>();

		String agentNamesNotInTeleopti= "";
		try {
			CreateRUpdateInviteDTO createRUpdateInviteDTO = getCreateRUpdateInviteDTO(request, session, "APPLY_INVITE");

			String personNameAsApprovedTimeOff = "";
			String personNameAsNoSchedule = "";
			String personNameNotInAnyScenario = "";

			if(createRUpdateInviteDTO != null){

				String participantIds = "";

				for(Map.Entry<String, String> participantMap: createRUpdateInviteDTO.getParticipants().entrySet()){ 

					if(StringUtils.isBlank(participantIds)){
						participantIds = participantMap.getKey();
					}else{
						participantIds = participantIds+","+participantMap.getKey();
					}

					TeleoptiCheckScheduleDTO teleoptiCheckScheduleDTO = dataSourceLMS.getAgentsListForSchedule(participantMap.getKey().trim()
							, participantMap.getValue().trim()							
							, createRUpdateInviteDTO.getInviteFromDate()
							, createRUpdateInviteDTO.getInviteToDate()
							, createRUpdateInviteDTO.getInviteStartTime()
							, createRUpdateInviteDTO.getInviteEndTime()
							, createRUpdateInviteDTO.getInviteFormat());

					if(teleoptiCheckScheduleDTO != null){
						if (StringUtils.isNoneEmpty(teleoptiCheckScheduleDTO.getPersonIdInTeleopti(),teleoptiCheckScheduleDTO.getStartDate(), teleoptiCheckScheduleDTO.getEndDate())) {
							agentInTeleopti.add(teleoptiCheckScheduleDTO);

						}else{
							if(StringUtils.isBlank(agentNamesNotInTeleopti)){
								agentNamesNotInTeleopti = participantMap.getValue().trim();
							}else{
								agentNamesNotInTeleopti = agentNamesNotInTeleopti + "," + participantMap.getValue().trim();
							}

						}
					}else{
						if(StringUtils.isBlank(agentNamesNotInTeleopti)){
							agentNamesNotInTeleopti = participantMap.getValue().trim();
						}else{
							agentNamesNotInTeleopti = agentNamesNotInTeleopti + "," + participantMap.getValue().trim();
						}
					}

				}

				if(StringUtils.isBlank(agentNamesNotInTeleopti)){
					if(agentInTeleopti.size()>0){

						for(TeleoptiCheckScheduleDTO teleoptiCheckScheduleDTO : agentInTeleopti){

							String agentScheduleStatus = teleoptiAgentClient.checkScheduleForPerson(teleoptiCheckScheduleDTO.getPersonIdInTeleopti()
									, teleoptiCheckScheduleDTO.getStartDate()
									, teleoptiCheckScheduleDTO.getEndDate());

							switch(agentScheduleStatus){  
							case "Available": 
								personAsSchedule.add(teleoptiCheckScheduleDTO) ;
								break;
							case "Approved Time-Off": 
								if (StringUtils.isBlank(personNameAsApprovedTimeOff)) {
									personNameAsApprovedTimeOff = teleoptiCheckScheduleDTO.getAgentName();
								} else {
									personNameAsApprovedTimeOff = personNameAsApprovedTimeOff + " , "+teleoptiCheckScheduleDTO.getAgentName();
								}
								break;
							case "No Schedule":
								if (StringUtils.isBlank(personNameAsNoSchedule)) {
									personNameAsNoSchedule = teleoptiCheckScheduleDTO.getAgentName();
								} else {
									personNameAsNoSchedule = personNameAsNoSchedule + " , "+teleoptiCheckScheduleDTO.getAgentName();
								}
								break;
							default:
								if (StringUtils.isBlank(personNameNotInAnyScenario)) {
									personNameNotInAnyScenario = teleoptiCheckScheduleDTO.getAgentName();
								} else {
									personNameNotInAnyScenario = personNameNotInAnyScenario + " "+teleoptiCheckScheduleDTO.getAgentName();
								}
							}  
						}

					}
				}else{
					responseStatusList.add("1");
					responseStatusList.add("Agent - "+agentNamesNotInTeleopti+" is not there in Teleopti.");
					return responseStatusList;	
				}


				if(StringUtils.isBlank(personNameAsApprovedTimeOff) && StringUtils.isBlank(personNameAsNoSchedule ) && StringUtils.isBlank(personNameNotInAnyScenario)){

					String result = dataSourceLMS.applyInvite(createRUpdateInviteDTO);
                    
                    if(StringUtils.isNotBlank(result)){
                           responseStatus = result;
                    }else{
                           LOGGER.error("ApplyInvite Stored Procedure Returns Null ");
                    }

					List<TeleoptiWebserviceDto> teleoptiWebserviceDtoList = teleoptiWebserviceData.getEquivalentTeleoptiRecord(createRUpdateInviteDTO);

					@SuppressWarnings("unused")
					List<TeleoptiWebserviceDto> teleoptiWebserviceDtosWithResult = new ArrayList<TeleoptiWebserviceDto>();

					if (teleoptiWebserviceDtoList.size() > 0) {
						teleoptiWebserviceDtosWithResult = addAgentActivityInTeleopti(teleoptiWebserviceDtoList);
					}

				}else{
                      
					responseStatusList.add("1");
					responseStatusList.add(getScheduleResult(personNameAsApprovedTimeOff
							, personNameAsNoSchedule 
							, personNameNotInAnyScenario));
					return responseStatusList;


				}	
			}

		} catch (SQLException | NamingException e) {			
			LOGGER.error(e.getMessage(), e);
			responseStatusList.add("1");
			responseStatusList.add(responseStatus);
			return responseStatusList;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			responseStatusList.add("1");
			responseStatusList.add(responseStatus);
			return responseStatusList;
		}
		LOGGER.info("Exiting createNewInvite() method");
		if(responseStatus.toLowerCase().contains("successfully")){
			responseStatusList.add("0");
		}else{
			responseStatusList.add("1");
		}
		
		responseStatusList.add(responseStatus);
		return responseStatusList;
		
	}

	/**
	 * @param TeleoptiWebserviceDtoList
	 * @return
	 */
	private List<TeleoptiWebserviceDto> addAgentActivityInTeleopti(List<TeleoptiWebserviceDto> TeleoptiWebserviceDtoList){
		LOGGER.info("Inside addAgentActivityInTeleopti() method");

		List<TeleoptiWebserviceDto> TeleoptiWebServDtosWithResult = new ArrayList<TeleoptiWebserviceDto>();

		for (TeleoptiWebserviceDto teleoptiWebserviceDto : TeleoptiWebserviceDtoList) {
			teleoptiWebserviceDto.setAddActivityResult(teleoptiAgentClient.addActivity(teleoptiWebserviceDto.getActivityId(),
					teleoptiWebserviceDto.getAgentId(), 
					teleoptiWebserviceDto.getStartDate(),
					teleoptiWebserviceDto.getEndDate()));
			TeleoptiWebServDtosWithResult.add(teleoptiWebserviceDto);
		}
		LOGGER.info("Exiting addAgentActivityInTeleopti() method");
		return TeleoptiWebServDtosWithResult;
	}

	/**
	 * @param personNameAsApprovedTimeOff
	 * @param personNameAsNoSchedule
	 * @param personNameNotInAnyScenario
	 * @return
	 */
	private String getScheduleResult(String personNameAsApprovedTimeOff
			, String personNameAsNoSchedule 
			, String personNameNotInAnyScenario){
		LOGGER.info("Inside getScheduleResult() method");
		String scheduleResult = "";
		if (StringUtils.isNoneBlank(personNameAsApprovedTimeOff)){

			if(StringUtils.isBlank(scheduleResult)){
				scheduleResult = scheduleResult + "Agent - "
						+ personNameAsApprovedTimeOff
						+ " has an approved Time-Off existing in Teleopti.";
			}else{
				scheduleResult = scheduleResult + " And Agent - "
						+ personNameAsApprovedTimeOff
						+ " has an approved Time-Off existing in Teleopti.";
			}

		} 
		if(StringUtils.isNoneBlank(personNameAsNoSchedule)){
			if(StringUtils.isBlank(scheduleResult)){
				scheduleResult = "Agent - "
						+ personNameAsNoSchedule
						+ " has no schedule for the day in Teleopti.";
			}else{
				scheduleResult = scheduleResult +" And Agent - "
						+ personNameAsNoSchedule
						+ " has no schedule for the day in Teleopti.";
			}

		}
		if(StringUtils.isNoneBlank(personNameNotInAnyScenario)){
			if(StringUtils.isBlank(scheduleResult)){
				scheduleResult ="Either Agent - "
						+ personNameNotInAnyScenario
						+ " has no schedule for the day  or  he/she has an approved Time-Off existing in Teleopti. ";
			}else{
				scheduleResult = scheduleResult +" And Either Agent - "
						+ personNameNotInAnyScenario
						+ " has no schedule for the day or he/she has an approved Time-Off existing in Teleopti. ";
			}

		}

		LOGGER.info("Exiting getScheduleResult() method");
		return scheduleResult + "  Please retry excluding the agent. ";

	}

	/**
	 * @param request
	 * @param session
	 * @param inviteAction
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	private CreateRUpdateInviteDTO getCreateRUpdateInviteDTO(HttpServletRequest request,	HttpSession session , String inviteAction) throws UnsupportedEncodingException{
		LOGGER.info("Inside getCreateRUpdateInviteDTO() method");
		CreateRUpdateInviteDTO createRUpdateInviteDTO = new CreateRUpdateInviteDTO();

		createRUpdateInviteDTO.setLoginId((String) session.getAttribute("userid"));
		createRUpdateInviteDTO.setLoginUserName((String) session.getAttribute("username"));
		if(inviteAction.equalsIgnoreCase("UPDATE_INVITE")){
			createRUpdateInviteDTO.setInviteId(request.getParameter("inviteId"));
		}

		createRUpdateInviteDTO.setStatus("Scheduled");

		createRUpdateInviteDTO.setInviteType((String) request.getParameter("inviteType"));
		createRUpdateInviteDTO.setInviteFormat((String) request.getParameter("inviteFormat"));
		createRUpdateInviteDTO.setInviteFromDate((String) request.getParameter("inviteFromDate"));
		createRUpdateInviteDTO.setInviteToDate((String) request.getParameter("inviteToDate"));
		createRUpdateInviteDTO.setInviteStartTime((String) request.getParameter("inviteStartTime"));	
		createRUpdateInviteDTO.setInviteEndTime((String) request.getParameter("inviteEndTime"));
		createRUpdateInviteDTO.setNumOfDaysRHours((String) request.getParameter("numOfDaysRHours"));
		createRUpdateInviteDTO.setInviteRemarks(URLDecoder.decode((String) request.getParameter("inviteRemarks"),"UTF-8"));
		String agentsDetail = (String) request.getParameter("agentsDetail");
		String participantIds = "";



		LinkedHashMap<String, String> participantsMap = new LinkedHashMap<String, String>();

		if(StringUtils.isNotEmpty(agentsDetail)){
			String[] participantsList=agentsDetail.split(",");
			for(int i=0 ; i<participantsList.length;i++){
				String array[]=participantsList[i].split(":");
				if(!participantsMap.containsKey(array[0])){
					participantsMap.put(array[0], array[1]);

					if(StringUtils.isBlank(participantIds)){
						participantIds = array[0];
					}else{
						participantIds = participantIds + "," + array[0];
					}

				}
			}
		}
		createRUpdateInviteDTO.setParticipants(participantsMap);
		createRUpdateInviteDTO.setParticipantIds(participantIds);
		LOGGER.info("Exiting getCreateRUpdateInviteDTO() method");
		return createRUpdateInviteDTO;
	}


	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = "/modifyInvite", method = RequestMethod.POST)
	public @ResponseBody String updateInvite(ModelMap model, HttpServletRequest request,
			HttpSession session) throws UnsupportedEncodingException {
		LOGGER.info("Inside updateInvite() method");

		String status = "";

		CreateRUpdateInviteDTO createRUpdateInviteDTO = getCreateRUpdateInviteDTO( request, session , "UPDATE_INVITE");

		try {
			if(createRUpdateInviteDTO != null)
				status = dataSourceLMS.updateInvite(createRUpdateInviteDTO);

		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting updateInvite() method");
		return status;
	}

	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = "/getInviteValues", method = RequestMethod.GET)
	public @ResponseBody CreateRUpdateInviteDTO getInviteValues(ModelMap model, HttpServletRequest request,
			HttpSession session) throws UnsupportedEncodingException {
		LOGGER.info("Inside getInviteValues() method");
		CreateRUpdateInviteDTO createRUpdateInviteDTO = new CreateRUpdateInviteDTO();
		String timeOffId = request.getParameter("timeOffId");
		try {
			createRUpdateInviteDTO = dataSourceLMS.getInviteValues(timeOffId);
		} catch (SQLException | NamingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting getInviteValues() method");
		return createRUpdateInviteDTO;
	}

	/**
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value = "/sendInviteEmail", method = RequestMethod.POST)
	public @ResponseBody
	String sendEmail(ModelMap model, HttpServletRequest request,
			HttpSession session) throws UnsupportedEncodingException {
		LOGGER.info("Inside sendEmail() method");
		String status = "";
		String userName = (String) session.getAttribute("username");
		String timeOffId = request.getParameter("timeOFFID");
		String inviteType = request.getParameter("invitetype");
		String remarks = request.getParameter("remarks");

		LOGGER.info(inviteType + " -- " + remarks);
		List<SendEmailDTO> objectList = new ArrayList<>();
		try {

			objectList = dataSourceLMS.sendEmail(timeOffId);
			String transactionIDS = "";
			String emailMsg = "";

			for (SendEmailDTO object : objectList) {

				String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding: 3px 10px;'";
				String formatTableBodyRight = "'border-bottom:1px solid #888888;padding:3px 10px;'";
				String mailBody = "<div style='font-weight:bold;'>Time Off Request Details :</div><div><br><table style='width: 100%; border: 1px solid #888888; border-bottom: 0;border-collapse: separate;border-spacing: 0px;margin: 15px 0;'><tbody><tr><td style="
						+ formatTableBodyLeft
						+ ">Name:</td><td style="
						+ formatTableBodyRight + "> " + userName + "</td></tr>";
				mailBody += "<tr><td style=" + formatTableBodyLeft
						+ ">Invite Type</td> <td style=" + formatTableBodyRight
						+ ">" + inviteType + "</td></tr>";
				mailBody += "<tr><td style=" + formatTableBodyLeft
						+ ">Start Time</td> <td style=" + formatTableBodyRight
						+ ">" + object.getStartDate() + "</td></tr>";
				mailBody += "<tr><td style=" + formatTableBodyLeft
						+ ">End Time</td> <td style=" + formatTableBodyRight
						+ ">" + object.getEndDate() + "</td></tr>";
				mailBody += "<trm><td style=" + formatTableBodyLeft
						+ ">Remarks</td><td style=" + formatTableBodyRight
						+ ">" + remarks + "</td></tr></table></div>";
				// sending mail response and Transaction id for updation of
				// record

				object.setMsg(mailBody);
				transactionIDS += object.getTimeOffStatusId() + ",";
				emailMsg += mailSendForInvite(object) + ",";
			}
			transactionIDS = transactionIDS.substring(0,
					transactionIDS.length() - 1);
			emailMsg = emailMsg.substring(0, emailMsg.length() - 1);

			status = dataSourceLMS.setEmailStatusForInvite(transactionIDS,
					emailMsg);
		}catch (SQLException | NamingException  e) {
			LOGGER.error(e.getMessage(), e);
		}catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("Exiting sendEmail() method");
		return status;
	}
	/* Invite Screen Methods End*/
	
	/**
	 * @Purpose: To show Time Off History Sub Records in Pop-Up
	 * @param model
	 * @param request
	 * @param session
	 * @returnType = Map ; Data = Time Off History Sub Record
	 * @throws Exception
	 */
	@RequestMapping(value = "/LeaveHistorySubRecords", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, List<?>> getLeaveHistoryTableSubRecords(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LOGGER.info("Inside getLeaveHistoryTableSubRecords() method");
		Map<String, List<?>> leaveHistorySubRecords = new HashMap<>();

		try {
			
			
			String parentId = request.getParameter("TimeOff_ID");

			leaveHistorySubRecords = dataSourceLMS.getLeaveHistoryTableSubRecords(parentId);

		
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		LOGGER.info("Exiting getLeaveHistoryTableSubRecords() method");
		return leaveHistorySubRecords;
	}
	/**
	 * This method will get executed when user  clicks on cancel icon(in Time Off history grid) in  TOMS Agent home screen
	 * @param model
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/cancelAppliedRequest", method = RequestMethod.POST)
	public @ResponseBody
	Map<String, Map<String, List<?>>> cancelAppliedRequest(ModelMap model,
			HttpServletRequest request, HttpSession session) throws Exception {
		LinkedHashMap<String, List<?>> timeOffHistorygridRfresh=new LinkedHashMap<String, List<?>>();
		Map<String, Map<String, List<?>>> refreshallGridsMap = new HashMap<String, Map<String, List<?>>>();
		List<String> response=new ArrayList<>();
		String mailStatus="";
		String mailStatusUpdate="";
		Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
		Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();
		cancelAppliedRequestDTO cancelAppliedRequestdto=new cancelAppliedRequestDTO();
		ApplyLeaveResponseDTO cancelRequestMailResponseeDTO=new ApplyLeaveResponseDTO();
		TeleoptiWebserviceDto teleDto = new TeleoptiWebserviceDto();
		
		
		String user=(String)session.getAttribute("username");
		String loginUserId = (String) session.getAttribute("userid");
		
		
		cancelAppliedRequestdto.setTimeOff_id(request.getParameter("timeoffid"));
		cancelAppliedRequestdto.setRequestType(request.getParameter("requestType"));
		cancelAppliedRequestdto.setAgentName(request.getParameter("name"));
		cancelAppliedRequestdto.setStarDate(request.getParameter("fromDate"));
		cancelAppliedRequestdto.setEndDate(request.getParameter("toDate"));
		cancelAppliedRequestdto.setStartTime(request.getParameter("startTime"));
		cancelAppliedRequestdto.setEndTime(request.getParameter("endTime"));
		cancelAppliedRequestdto.setUnits(request.getParameter("units"));
		cancelAppliedRequestdto.setPreviousStatus(request.getParameter("previousStatus"));
		cancelAppliedRequestdto.setCurrentStatus(request.getParameter("currentStatus"));
		LOGGER.info(cancelAppliedRequestdto);
		
		try {
			response=dataSourceLMS.cancelAppliedRequest(cancelAppliedRequestdto.getTimeOff_id(),user);
			if(response.get(4).contains("successfully")){
				String formatTableBodyLeft = "'width:30%;font-weight:bold;border-bottom:1px solid #888888;border-right: 1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
				String formatTableBodyRight = "'border-bottom:1px solid #888888;padding-top:3px;padding-left:10px;padding-bottom:3px;padding-right:10px;'";
				String mailBody = "<div style='font-weight:bold; margin:15px 0px;'>Cancel Time Off :</div><div><table border='0' cellpadding='0' cellspacing='0' style='width: 100%;border:1px solid #888888;border-bottom:0px;border-collapse:separate;border-spacing:0px;margin-top:15px;margin-bottom:15px;margin-left:0px;margin-right:0px;'><tbody><tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Name</td><td valign='middle' style="
						+ formatTableBodyRight
						+ "> "
						+ user.toUpperCase()
						+ "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Request Type</td> <td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getRequestType() + "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">From Date</td> <td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getStarDate() + "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">To Date</td><td valign='middle' style="
						+ formatTableBodyRight + "> " + cancelAppliedRequestdto.getEndDate() + "</td></tr>";
				
				if(cancelAppliedRequestdto.getUnits().equalsIgnoreCase("Hours")){
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Start Time</td> <td valign='middle' style="
						+ formatTableBodyRight + ">" + cancelAppliedRequestdto.getStartTime()
						+ "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">End Time</td><td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getEndTime() + "</td></tr>";
				}
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Units</td><td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getUnits() + "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Previous Status</td><td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getPreviousStatus() + "</td></tr>";
				mailBody += "<tr><td valign='middle' style="
						+ formatTableBodyLeft
						+ ">Current Status</td><td valign='middle' style="
						+ formatTableBodyRight + ">"
						+ cancelAppliedRequestdto.getCurrentStatus() + "</td></tr></table></div>";

				mailStatus = mailSend(response, mailBody);
				cancelRequestMailResponseeDTO.setTransactionId(response.get(0));
				cancelRequestMailResponseeDTO.setStatus(mailStatus);
				mailStatusUpdate = dataSourceLMS.updateEmail(cancelRequestMailResponseeDTO);
				timeOffHistorygridRfresh=dataSourceLMS.leaveHistoryTable(loginUserId);

				// teleopti approve
				if (cancelAppliedRequestdto.getPreviousStatus()
						.equalsIgnoreCase("approved")) {
					teleDto = teleoptiWebserviceData
							.getTeleoptiCancelApproveData(cancelAppliedRequestdto
									.getTimeOff_id());
					if (cancelAppliedRequestdto.getRequestType()
							.equalsIgnoreCase("OVT")) {
						teleoptiAgentClient.cancelOverTimeActivity(
								teleDto.getAgentId(), teleDto.getStartDate(),
								teleDto.getEndDate());
					} else {
						teleoptiAgentClient.cancelAbsence(teleDto.getAgentId(),
								teleDto.getStartDate(), teleDto.getEndDate());
					}
				}
				
				leaveBalanceTableDetailMap = dataSourceLMS.leaveBalnceTable(loginUserId);
				leaveProjectionTableDetailMap = dataSourceLMS.leaveProjectionTable(loginUserId);
				
				refreshallGridsMap.put("timeOffHistory", timeOffHistorygridRfresh);
				refreshallGridsMap.put("timeOffBalance", leaveBalanceTableDetailMap);
				refreshallGridsMap.put("timeOffDetail", leaveProjectionTableDetailMap);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage(), e);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		} 
		
		
		
		return refreshallGridsMap;
	}
}
