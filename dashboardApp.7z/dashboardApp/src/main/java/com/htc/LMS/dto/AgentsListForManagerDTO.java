package com.htc.LMS.dto;

public class AgentsListForManagerDTO {

	String agentId;
	String agentName;
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}



}
