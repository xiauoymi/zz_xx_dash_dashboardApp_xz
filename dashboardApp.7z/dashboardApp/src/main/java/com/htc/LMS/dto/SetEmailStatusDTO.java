package com.htc.LMS.dto;

public class SetEmailStatusDTO {
	public String timeOffId;
	public String emailStatus;
	public String getTimeOffId() {
		return timeOffId;
	}
	public void setTimeOffId(String timeOffId) {
		this.timeOffId = timeOffId;
	}
	public String getEmailStatus() {
		return emailStatus;
	}
	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}


}
