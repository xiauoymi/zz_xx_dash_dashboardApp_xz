package com.htc.LMS.soap.service1;

import org.apache.log4j.Logger;
import org.tempuri.ITeleoptiService;
import org.tempuri.Service1;



public class TeleoptiAgentClient {

	private static final Logger logger = Logger.getLogger(TeleoptiAgentClient.class);

	public int  addActivity(String activityID, String personID, String activityStartTime, String activityEndTime){
		Integer result=0;
		logger.info("Inside TELEOPTIAGENTCLIENT addActivity() method");
		activityStartTime=activityStartTime.substring(0,activityStartTime.length()-2);
		activityStartTime=activityStartTime+"00";
		activityEndTime=activityEndTime.substring(0,activityEndTime.length()-2);
		activityEndTime=activityEndTime+"00";

		logger.info("Activity ID :"+activityID);
		logger.info("Agent ID :"+personID);
		logger.info("Activity start time :"+activityStartTime);
		logger.info("Activity end time :"+activityEndTime);
		Service1 service1= new Service1();
		ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
		if(service.login())
			result = service.addActivity(activityID,personID,activityStartTime, activityEndTime);
		logger.info("Exiting TELEOPTIAGENTCLIENT addActivity() method");
		return result;
	}

	public int  addAbsence(String activityID, String personID, String activityStartTime, String activityEndTime){
		Integer result=0;
		logger.info("Inside TELEOPTIAGENTCLIENT addAbsence() method");
		activityStartTime=activityStartTime.substring(0,activityStartTime.length()-2);
		activityStartTime=activityStartTime+"00";
		activityEndTime=activityEndTime.substring(0,activityEndTime.length()-2);
		activityEndTime=activityEndTime+"00";


		logger.info("Activity ID :"+activityID);
		logger.info("Agent ID :"+personID);
		logger.info("Activity start time :"+activityStartTime);
		logger.info("Activity end time :"+activityEndTime);
		Service1 service1= new Service1();
		ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
		if(service.login())
			result = service.addAbsence(activityID,personID, activityStartTime,activityEndTime);
		logger.info("service.addAbsence  presonId-"+personID+"&reponse of absence method=="+result);
		logger.info("Exiting TELEOPTIAGENTCLIENT addAbsence() method");
		return result;
	}

	/**
	 * This method checks Schedule is there for the person in Teleopti for given Date and Time
	 * @param personID
	 * @param activityStartTime
	 * @param activityEndTime
	 * @return int 
	 * (If it returns 
	 * 1=Available(i.e He/She is Available for that date);
	 * 2=Approved Time-Off;
	 * 3=No Schedule )
	 */
	public String  checkScheduleForPerson( String personID, String activityStartTime, String activityEndTime){
		logger.info("Inside TELEOPTIAGENTCLIENT checkScheduleForPerson() method");
		String status="";

		activityStartTime=activityStartTime.substring(0,activityStartTime.length()-2);
		activityStartTime=activityStartTime+"00";
		activityEndTime=activityEndTime.substring(0,activityEndTime.length()-2);
		activityEndTime=activityEndTime+"00";


		logger.info("Agent ID :"+personID +"\n Activity start time :"+activityStartTime +"\n Activity end time :"+activityEndTime);

		try{
			Service1 service1= new Service1();
			ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
			int result = 0;
			if(service.login())
				result = service.checkScheduleForPerson(personID, activityStartTime, activityEndTime);

			switch(result){  
			case 1: 
				status="Available";
				break;
			case 2: 
				status="Approved Time-Off";
				break;
			case 3:
				status="No Schedule";
				break;
			default:
				status="None";
				break;
			}  

		}catch(Exception e){
			status = "Exception occurred while connectting to Teleopti Service "+e.getMessage();
			logger.error(status + "\n" + e.getMessage(), e);
		}
		logger.info("Exiting TELEOPTIAGENTCLIENT checkScheduleForPerson() method");
		return status;
	}
	public int  cancelAbsence(String personID, String activityStartTime, String activityEndTime){
		Integer result=0;
		logger.info("Inside TELEOPTIAGENTCLIENT cancelAbsence() method");
		activityStartTime=activityStartTime.substring(0,activityStartTime.length()-2);
		activityStartTime=activityStartTime+"00";
		activityEndTime=activityEndTime.substring(0,activityEndTime.length()-2);
		activityEndTime=activityEndTime+"00";


		logger.info("Agent ID :"+personID);
		logger.info("Activity start time :"+activityStartTime);
		logger.info("Activity end time :"+activityEndTime);
		Service1 service1= new Service1();
		ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
		if(service.login())
			result = service.cancelAbsence(personID,activityStartTime,activityEndTime);
		logger.info("service.cancelAbsence presonId-"+personID+"&reponse of absence method=="+result);
		logger.info("Exiting TELEOPTIAGENTCLIENT cancelAbsence() method");
		return result;
	}
	
	public int  addOverTimeActivity(String activityID,String personID, String overtimeStartTime, String overtimeEndTime,String overTimeException){
		Integer result=0;
		logger.info("Inside TELEOPTIAGENTCLIENT addOverTimeActivity() method");
		overtimeStartTime=overtimeStartTime.substring(0,overtimeStartTime.length()-2);
		overtimeStartTime=overtimeStartTime+"00";
		overtimeEndTime=overtimeEndTime.substring(0,overtimeEndTime.length()-2);
		overtimeEndTime=overtimeEndTime+"00";


		logger.info("Activity ID :"+activityID);
		logger.info("Agent ID :"+personID);
		logger.info("Activity start time :"+overtimeStartTime);
		logger.info("Activity end time :"+overtimeEndTime);
		logger.info("Activity overTimeException :"+overTimeException);
		Service1 service1= new Service1();
		ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
		if(service.login())
			result = service.addOvertime(activityID, personID, overtimeStartTime, overtimeEndTime, overTimeException);
		logger.info("service.addOverTimeActivity presonId-"+personID+"&reponse of addOverTimeActivity method=="+result);
		logger.info("Exiting TELEOPTIAGENTCLIENT addOverTimeActivity() method");
		return result;
	}

	public int  cancelOverTimeActivity(String personID, String overtimeStartTime, String overtimeEndTime){
		Integer result=0;
		logger.info("Inside TELEOPTIAGENTCLIENT cancelOverTimeActivity() method");
		overtimeStartTime=overtimeStartTime.substring(0,overtimeStartTime.length()-2);
		overtimeStartTime=overtimeStartTime+"00";
		overtimeEndTime=overtimeEndTime.substring(0,overtimeEndTime.length()-2);
		overtimeEndTime=overtimeEndTime+"00";


		logger.info("Agent ID :"+personID);
		logger.info("Activity start time :"+overtimeStartTime);
		logger.info("Activity end time :"+overtimeEndTime);
		Service1 service1= new Service1();
		ITeleoptiService service = service1.getBasicHttpBindingITeleoptiService();
		if(service.login())
			result = service.cancelOvertime(personID, overtimeStartTime, overtimeEndTime);
		logger.info("service.cancelOverTimeActivity presonId-"+personID+"&reponse of cancelOverTimeActivity method=="+result);
		logger.info("Exiting TELEOPTIAGENTCLIENT cancelOverTimeActivity() method");
		return result;
	}

}
