package com.htc.LMS.soap.service1;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/*
 * Utility class for Toms
 */

public class TomsUtility {
	/*
	 * This method will read the wsdl.properties file and returns the url configured for people soft
	 */
	
	public static String  getPeopleSoftUrl() throws IOException{
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("wsdl.properties");
		final Properties p = new Properties();
		p.load(input);
		String url = p.getProperty("PEOPLESOFT_URL");
		return url;
		
	}
	
	/*
	 * This method will read the wsdl.properties file and returns the url configured for people soft
	 */
	public static String  getTelioptiUrl() throws IOException{
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("wsdl.properties");
		final Properties p = new Properties();
		p.load(input);
		String url = p.getProperty("TELIOPTI_URL");
		return url;
		
	}

}
