package com.htc.LMS.dto;

/**
 * @author gayathria
 *
 */
public class TeleoptiWebserviceDto {

	private String agentId;
	private String activityId;
	private String startDate;
	private String endDate;
	private int addActivityResult;
	private String overTimeException;

	public String getOverTimeException() {
		return overTimeException;
	}
	public void setOverTimeException(String overTimeException) {
		this.overTimeException = overTimeException;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getAddActivityResult() {
		return addActivityResult;
	}
	public void setAddActivityResult(int addActivityResult) {
		this.addActivityResult = addActivityResult;
	}

}
