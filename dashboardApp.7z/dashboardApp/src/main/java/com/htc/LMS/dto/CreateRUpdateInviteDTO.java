package com.htc.LMS.dto;

import java.util.LinkedHashMap;

/**
 * @author gayathria
 *
 */
public class CreateRUpdateInviteDTO {

	private String loginId;
	private String loginUserName;
	private String inviteType;
	private String inviteFormat;
	private String inviteFromDate;
	private String inviteToDate;
	private String inviteStartTime;	
	private String inviteEndTime;
	private String inviteStartMeridiem;	
	private String inviteEndMeridiem;
	private String numOfDaysRHours;
	private String inviteRemarks;
	LinkedHashMap<String, String> participants = new LinkedHashMap<String, String>();
	private String participantIds;
	private String status;


	private String inviteId;

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getLoginUserName() {
		return loginUserName;
	}

	public void setLoginUserName(String loginUserName) {
		this.loginUserName = loginUserName;
	}

	public String getInviteType() {
		return inviteType;
	}

	public void setInviteType(String inviteType) {
		this.inviteType = inviteType;
	}

	public String getInviteFormat() {
		return inviteFormat;
	}

	public void setInviteFormat(String inviteFormat) {
		this.inviteFormat = inviteFormat;
	}

	public String getInviteFromDate() {
		return inviteFromDate;
	}

	public void setInviteFromDate(String inviteFromDate) {
		this.inviteFromDate = inviteFromDate;
	}

	public String getInviteToDate() {
		return inviteToDate;
	}

	public void setInviteToDate(String inviteToDate) {
		this.inviteToDate = inviteToDate;
	}

	public String getInviteStartMeridiem() {
		return inviteStartMeridiem;
	}

	public void setInviteStartMeridiem(String inviteStartMeridiem) {
		this.inviteStartMeridiem = inviteStartMeridiem;
	}

	public String getInviteEndMeridiem() {
		return inviteEndMeridiem;
	}

	public void setInviteEndMeridiem(String inviteEndMeridiem) {
		this.inviteEndMeridiem = inviteEndMeridiem;
	}

	public String getNumOfDaysRHours() {
		return numOfDaysRHours;
	}

	public void setNumOfDaysRHours(String numOfDaysRHours) {
		this.numOfDaysRHours = numOfDaysRHours;
	}

	public String getInviteRemarks() {
		return inviteRemarks;
	}

	public void setInviteRemarks(String inviteRemarks) {
		this.inviteRemarks = inviteRemarks;
	}

	public LinkedHashMap<String, String> getParticipants() {
		return participants;
	}

	public void setParticipants(LinkedHashMap<String, String> participants) {
		this.participants = participants;
	}

	/*public String getInviteAction() {
		return inviteAction;
	}

	public void setInviteAction(String inviteAction) {
		this.inviteAction = inviteAction;
	}*/

	public String getInviteId() {
		return inviteId;
	}

	public void setInviteId(String inviteId) {
		this.inviteId = inviteId;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CreateRUpdateInviteDTO() {

	}

	public String getInviteStartTime() {
		return inviteStartTime;
	}

	public void setInviteStartTime(String inviteStartTime) {
		this.inviteStartTime = inviteStartTime;
	}

	public String getInviteEndTime() {
		return inviteEndTime;
	}

	public void setInviteEndTime(String inviteEndTime) {
		this.inviteEndTime = inviteEndTime;
	}

	public String getParticipantIds() {
		return participantIds;
	}

	public void setParticipantIds(String participantIds) {
		this.participantIds = participantIds;
	}



}
