package com.htc.LMS.dto;

public class SendEmailDTO {
	public String timeOffStatusId;
	public String from;
	public String to;
	public String msg;
	public String subject;
	public String startDate;
	public String endDate;

	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getTimeOffStatusId() {
		return timeOffStatusId;
	}
	public void setTimeOffStatusId(String timeOffStatusId) {
		this.timeOffStatusId = timeOffStatusId;
	}



}
