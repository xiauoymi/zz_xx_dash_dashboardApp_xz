package com.htc.LMS.dto;

import java.util.LinkedHashMap;

/**
 * @author gayathria
 *
 */
public class LoadInviteDTO {

	private LinkedHashMap<String, String> supervisorsList = new LinkedHashMap<String, String>();
	private LinkedHashMap<String, String> agentsList = new LinkedHashMap<String, String>();
	private LinkedHashMap<String, String> selectedDefaultAgents = new LinkedHashMap<String, String>();		
	private LinkedHashMap<String, ScheduledInviteDTO> scheduledInvites = new LinkedHashMap<String, ScheduledInviteDTO>();
	/**
	 * @return the supervisorsList
	 */
	public LinkedHashMap<String, String> getSupervisorsList() {
		return supervisorsList;
	}
	/**
	 * @param supervisorsList the supervisorsList to set
	 */
	public void setSupervisorsList(LinkedHashMap<String, String> supervisorsList) {
		this.supervisorsList = supervisorsList;
	}
	/**
	 * @return the agentsList
	 */
	public LinkedHashMap<String, String> getAgentsList() {
		return agentsList;
	}
	/**
	 * @param agentsList the agentsList to set
	 */
	public void setAgentsList(LinkedHashMap<String, String> agentsList) {
		this.agentsList = agentsList;
	}
	/**
	 * @return the selectedDefaultAgents
	 */
	public LinkedHashMap<String, String> getSelectedDefaultAgents() {
		return selectedDefaultAgents;
	}
	/**
	 * @param selectedDefaultAgents the selectedDefaultAgents to set
	 */
	public void setSelectedDefaultAgents(
			LinkedHashMap<String, String> selectedDefaultAgents) {
		this.selectedDefaultAgents = selectedDefaultAgents;
	}
	/**
	 * @return the scheduledInvites
	 */
	public LinkedHashMap<String, ScheduledInviteDTO> getScheduledInvites() {
		return scheduledInvites;
	}
	/**
	 * @param scheduledInvites the scheduledInvites to set
	 */
	public void setScheduledInvites(
			LinkedHashMap<String, ScheduledInviteDTO> scheduledInvites) {
		this.scheduledInvites = scheduledInvites;
	}
	/**
	 * @param supervisorsList
	 * @param agentsList
	 * @param selectedDefaultAgents
	 * @param scheduledInvites
	 */
	public LoadInviteDTO(
			LinkedHashMap<String, String> supervisorsList,
			LinkedHashMap<String, String> agentsList,
			LinkedHashMap<String, String> selectedDefaultAgents,
			LinkedHashMap<String, ScheduledInviteDTO> scheduledInvites) {

		this.supervisorsList = supervisorsList;
		this.agentsList = agentsList;
		this.selectedDefaultAgents = selectedDefaultAgents;
		this.scheduledInvites = scheduledInvites;
	}
	public LoadInviteDTO() {

	}





}
