package com.htc.LMS.dto;

import java.util.LinkedHashMap;



/**
 * @author gayathria
 *
 */
public class ScheduledInviteDTO {

	private String timeOffId;
	private String inviteType ;
	private String inviteDate;
	private String inviteTime;
	private String inviteRemarks;

	private LinkedHashMap<String,String> participants = new LinkedHashMap<String,String>();

	public ScheduledInviteDTO() {

	}

	/**
	 * @return the timeOffId
	 */
	public String getTimeOffId() {
		return timeOffId;
	}

	/**
	 * @param timeOffId the timeOffId to set
	 */
	public void setTimeOffId(String timeOffId) {
		this.timeOffId = timeOffId;
	}

	/**
	 * @return the inviteType
	 */
	public String getInviteType() {
		return inviteType;
	}

	/**
	 * @param inviteType the inviteType to set
	 */
	public void setInviteType(String inviteType) {
		this.inviteType = inviteType;
	}

	/**
	 * @return the inviteDate
	 */
	public String getInviteDate() {
		return inviteDate;
	}

	/**
	 * @param inviteDate the inviteDate to set
	 */
	public void setInviteDate(String inviteDate) {
		this.inviteDate = inviteDate;
	}

	/**
	 * @return the inviteTime
	 */
	public String getInviteTime() {
		return inviteTime;
	}

	/**
	 * @param inviteTime the inviteTime to set
	 */
	public void setInviteTime(String inviteTime) {
		this.inviteTime = inviteTime;
	}

	/**
	 * @return the inviteRemarks
	 */
	public String getInviteRemarks() {
		return inviteRemarks;
	}

	/**
	 * @param inviteRemarks the inviteRemarks to set
	 */
	public void setInviteRemarks(String inviteRemarks) {
		this.inviteRemarks = inviteRemarks;
	}

	/**
	 * @return the participants
	 */
	public LinkedHashMap<String, String> getParticipants() {
		return participants;
	}

	/**
	 * @param participants the participants to set
	 */
	public void setParticipants(LinkedHashMap<String, String> participants) {
		this.participants = participants;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScheduledInviteDTO [timeOffId=" + timeOffId + ", inviteType="
				+ inviteType + ", inviteDate=" + inviteDate + ", inviteTime="
				+ inviteTime + ", inviteRemarks=" + inviteRemarks
				+ ", participants=" + participants + "]";
	}


	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if(obj == null){
			return result;
		}      
		if(obj  instanceof ScheduledInviteDTO){
			ScheduledInviteDTO other = (ScheduledInviteDTO) obj;
			if(this.timeOffId.equalsIgnoreCase(other.timeOffId)){
				result =true;
			}	
		}
		return result;
	}

	@Override
	public int hashCode() {
		return this.getTimeOffId().hashCode()*31;
	}
	

}
