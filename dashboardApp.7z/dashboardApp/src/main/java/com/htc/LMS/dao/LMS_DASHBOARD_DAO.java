package com.htc.LMS.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.LMS.dto.AgentsListForManagerDTO;
import com.htc.LMS.dto.ApplyLeaveDTO;
import com.htc.LMS.dto.ApplyLeaveResponseDTO;
import com.htc.LMS.dto.ApproveLeaveDTO;
import com.htc.LMS.dto.ApproveLeaveResponseDTO;
import com.htc.LMS.dto.CreateRUpdateInviteDTO;
import com.htc.LMS.dto.ScheduledInviteDTO;
import com.htc.LMS.dto.SendEmailDTO;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;
import com.htc.utility.TeleoptiCheckScheduleDTO;


public class LMS_DASHBOARD_DAO {

	DataSource dataSourceLMS;
	private static final Logger logger = Logger.getLogger(LMS_DASHBOARD_DAO.class);
	public void setDataSourceLMS(DataSource dataSourceLMS) {
		this.dataSourceLMS = dataSourceLMS;
	}
	public Map<String, List<?>> leaveBalnceTable(String clientId) throws SQLException,
	NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO leaveBalnceTable() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveBalancequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveBalanceMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveBalancequery = StoredProcedureConstants.sp_getLeaveBalance;
			callableStatement = connection.prepareCall(leaveBalancequery);
			callableStatement.setString(1, clientId);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveBalanceMap.put(DashboardConstants.LEAVEBALANCEFIELDNAMEs,
					reportDescriptionList);
			leaveBalanceMap.put(DashboardConstants.LEAVEBALANCEFIELDVALUES,
					reportList);

		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO leaveBalnceTable() method");
		return leaveBalanceMap;
	}

	public LinkedHashMap<String, List<?>> leaveHistoryTable(String client) throws SQLException,
	NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO leaveHistoryTable() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.getLeaveHistory;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, client);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDNAMEs,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDVALUES,
					reportList);

		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO leaveHistoryTable() method");
		return leaveHistoryMap;
	}

	public Map<String, List<?>> getRequestAwaitingApprovalManager(String client) throws SQLException,
	NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO getRequestAwaitingApprovalManager() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.sp_getRequestAwaitingApprovalManager;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, client);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDNAMEs,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDVALUES,
					reportList);

		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getRequestAwaitingApprovalManager() method");
		return leaveHistoryMap;
	}


	public Map<String, List<?>> getRequestAwaitingApprovalManagerforAjax(String client) throws SQLException,
	NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO getRequestAwaitingApprovalManagerforAjax() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.sp_getRequestAwaitingApprovalManager;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, client);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				cellList.add("");
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);

				}
				cellList.add("");
				cellList.add("");
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDNAMEs,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDVALUES,
					reportList);

		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getRequestAwaitingApprovalManagerforAjax() method");
		return leaveHistoryMap;
	}

	public Map<String, List<?>> getRequestAwaitingApprovalAgent(String agent) throws SQLException,
	NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO getRequestAwaitingApprovalAgent() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveHistoryequery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveHistoryequery = StoredProcedureConstants.SP_getRequestAwaitingApprovalAgent;
			callableStatement = connection.prepareCall(leaveHistoryequery);
			callableStatement.setString(1, agent);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				cellList.add("");
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				cellList.add("");
				cellList.add("");
				reportList.add(cellList);
			}
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDNAMEs,
					reportDescriptionList);
			leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDVALUES,
					reportList);

		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getRequestAwaitingApprovalAgent() method");
		return leaveHistoryMap;
	}

	public List<String> getLeaveType() throws SQLException,NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO getLeaveType() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		List<String> leaveTypeList = new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SP_GET_LEAVE_TYPE;
			statement = connection.prepareCall(procedure);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				String object = resultSet.getString("PSoft_Code_Desc");
				leaveTypeList.add(object);
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getLeaveType() method");
		return leaveTypeList;
	}
	public List<String> getSupervisor(String supervisorId) throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO getSupervisor() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		List<String> supervisorList = new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SP_GET_SUPERVISOR;
			statement = connection.prepareCall(procedure);
			statement.setString(1,supervisorId.trim());
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				String object = resultSet.getString("Supervisor Name");
				supervisorList.add(object);
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getSupervisor() method");
		return supervisorList;
	}
	public ApplyLeaveResponseDTO applyForLeave(ApplyLeaveDTO applyLeaveDTO)throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO applyForLeave() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		String status ="";
		String transactionId ="";
		String emailSubject="";
		ApplyLeaveResponseDTO responseObject = new ApplyLeaveResponseDTO();
		System.out.println("Agent Id : "+applyLeaveDTO.getAgentID());
		System.out.println("Leave Type : "+applyLeaveDTO.getLeaveType());
		System.out.println("From Date : "+applyLeaveDTO.getFromDate());
		System.out.println("To Date : "+applyLeaveDTO.getToDate());
		System.out.println("Start Time : "+applyLeaveDTO.getStartTime());
		System.out.println("End Time : "+applyLeaveDTO.getEndTime());
		try {


			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SP_APPLY_LEAVE;
			statement = connection.prepareCall(procedure);
			statement.setString(1, applyLeaveDTO.getAgentID());
			statement.setString(2, applyLeaveDTO.getSupervisorName());
			statement.setString(3, applyLeaveDTO.getLeaveType());
			statement.setString(4, applyLeaveDTO.getOverTimeActivity());
			statement.setString(5, applyLeaveDTO.getFromDate());
			statement.setString(6, applyLeaveDTO.getToDate());
			statement.setString(7, applyLeaveDTO.getStartTime());
			statement.setString(8, applyLeaveDTO.getEndTime());
			statement.setString(9, applyLeaveDTO.getNoOfDaysHrs());
			statement.setString(10, applyLeaveDTO.getUnitOfMeasurement());
			statement.setString(11, applyLeaveDTO.getStatus());
			statement.setString(12, applyLeaveDTO.getRemarks());
			statement.setString(13, applyLeaveDTO.getLoginId());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				status = resultSet.getString("Status");

				if(status.equalsIgnoreCase("Your Time Off request has been Applied")){
					emailSubject = resultSet.getString("EMail_Subject");
					transactionId = resultSet.getString("Transaction ID");
				}

			}	

			responseObject.setStatus(status);
			responseObject.setTransactionId(transactionId);
			responseObject.setEmailSubject(emailSubject);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO applyForLeave() method");
		return responseObject;
	}

	public ApproveLeaveResponseDTO approveLeave(ApproveLeaveDTO approveLeaveDTO)throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO approveLeave() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		String status ="";
		String transactionId ="";
		String fromEmail = "";
		String toEmail = "";
		ApproveLeaveResponseDTO responseObject = new ApproveLeaveResponseDTO();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SP_APPROVE_LEAVE;
			statement = connection.prepareCall(procedure);
			statement.setString(1, approveLeaveDTO.getRequestID());
			statement.setString(2, approveLeaveDTO.getSupervisorID());
			statement.setString(3, approveLeaveDTO.getAgentName());
			statement.setString(4, approveLeaveDTO.getStatus());
			statement.setString(5, approveLeaveDTO.getApproverRemarks());
		    statement.setString(6, approveLeaveDTO.getUser());

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				status = resultSet.getString("Status");
				if(status.equalsIgnoreCase("Success"))
					transactionId = resultSet.getString("Transaction ID");
				fromEmail = resultSet.getString("From_Email_Address");
				toEmail = resultSet.getString("To_Email_Address");
			}
			responseObject.setStatus(status);
			responseObject.setTransactionId(transactionId);
			responseObject.setFromEmail(fromEmail);
			responseObject.setToEmail(toEmail);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO approveLeave() method");
		return responseObject;
	}

	public List<AgentsListForManagerDTO> getAgentsListForManager(String approveLeaveDTO) throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO getAgentsListForManager() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		List<AgentsListForManagerDTO> responseList = new ArrayList<>();
		String procedure = "";

		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SP_AgentsListForManager;
			statement = connection.prepareCall(procedure);
			statement.setString(1,approveLeaveDTO);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				AgentsListForManagerDTO object= new AgentsListForManagerDTO();
				object.setAgentId(resultSet.getString("Agent ID"));
				object.setAgentName(resultSet.getString("Agent Name"));
				responseList.add(object);
			}

		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getAgentsListForManager() method");
		return responseList;
	}

	public List<String> getEmailOfSuperviser(ApplyLeaveDTO applyLeaveDTO) throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO getEmailOfSuperviser() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		List<String> supervisorList = new ArrayList<>();
		List<String> reportDescriptionList = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.getMailAddressForApplyAndApprove;
			statement = connection.prepareCall(procedure);
			statement.setString(1,applyLeaveDTO.getAgentID());
			statement.setString(2,applyLeaveDTO.getSupervisorName());
			resultSet = statement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				supervisorList.add("empty");
				supervisorList.add(resultSet.getString("From"));
				supervisorList.add(resultSet.getString("To"));

			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getEmailOfSuperviser() method");
		return supervisorList;
	}

	public String updateEmail(ApplyLeaveResponseDTO applyLeavResponseeDTO) throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO updateEmail() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;

		String procedure = "";
		String status ="";
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.sp_set_email_status;
			statement = connection.prepareCall(procedure);
			statement.setString(1,applyLeavResponseeDTO.getTransactionId());
			statement.setString(2,applyLeavResponseeDTO.getStatus());
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				status = resultSet.getString("Status");
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO updateEmail() method");
		return status;
	}

	/**
	 * Get all supervisors and set current user as in top(Active supervisor) of the list
	 * @param userId
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public LinkedHashMap<String, String> getAllSupervisor(String userId)  throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO getAllSupervisor() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		LinkedHashMap<String, String> supervisors = new LinkedHashMap<String, String>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.GET_SUPERVISOR_NAME;
			statement = connection.prepareCall(procedure);
			statement.setString(1,userId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				supervisors.put(resultSet.getString("Agent_Approver_ID"),resultSet.getString("Supervisor Name") );
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getAllSupervisor() method");
		return supervisors;
	}


	/**
	 * @param request
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public String applyInvite(CreateRUpdateInviteDTO createRUpdateInviteDTO) throws SQLException,NamingException{
		logger.info("Inside LMS_DASHBOARD_DAO applyInvite() method");

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String status="";

		try {
			connection = dataSourceLMS.getConnection();

			statement = connection.prepareCall(StoredProcedureConstants.APPLY_INVITE);
			statement.setString(1,createRUpdateInviteDTO.getLoginId());
			statement.setString(2,createRUpdateInviteDTO.getParticipantIds());
			statement.setString(3,createRUpdateInviteDTO.getInviteType());
			statement.setString(4,createRUpdateInviteDTO.getInviteFromDate());
			statement.setString(5,createRUpdateInviteDTO.getInviteToDate());
			statement.setString(6,createRUpdateInviteDTO.getInviteStartTime());
			statement.setString(7,createRUpdateInviteDTO.getInviteEndTime());
			statement.setString(8,createRUpdateInviteDTO.getNumOfDaysRHours());
			statement.setString(9,createRUpdateInviteDTO.getInviteFormat());
			statement.setString(10,createRUpdateInviteDTO.getStatus());
			statement.setString(11,createRUpdateInviteDTO.getInviteRemarks());
			statement.setString(12,createRUpdateInviteDTO.getLoginUserName());

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				status = resultSet.getString("Status");
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO applyInvite() method");
		return status;
	}

	/**
	 * @param userId
	 * @return
	 * @throws SQLException
	 * @throws NamingException
	 */
	public LinkedHashMap<String, ScheduledInviteDTO> getScheduledInvitesByLoginUserID(String userId)throws SQLException,NamingException {

		logger.info("Inside LMS_DASHBOARD_DAO getScheduledInvitesByLoginUserID() method");

		LinkedHashMap<String, ScheduledInviteDTO> scheduledInvites = new LinkedHashMap< String, ScheduledInviteDTO>();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.GET_SCHEDULED_INVITES;
			statement = connection.prepareCall(procedure);
			statement.setString(1,userId.trim());

			resultSet = statement.executeQuery();

			while (resultSet.next()) {

				if(scheduledInvites.containsKey(resultSet.getString("TimeOff_ID"))){

					ScheduledInviteDTO scheduledInviteDTO = scheduledInvites.get(resultSet.getString("TimeOff_ID"));
					scheduledInviteDTO.getParticipants().put(resultSet.getString("Participant_ID"), resultSet.getString("Participants"));
					scheduledInvites.put(scheduledInviteDTO.getTimeOffId(),scheduledInviteDTO);

				}else{

					ScheduledInviteDTO scheduledInviteDTO = new ScheduledInviteDTO();
					scheduledInviteDTO.setTimeOffId(resultSet.getString("TimeOff_ID"));
					scheduledInviteDTO.setInviteType(resultSet.getString("Invite Type"));				
					scheduledInviteDTO.setInviteDate(resultSet.getString("Date"));
					scheduledInviteDTO.setInviteTime(resultSet.getString("Time"));
					scheduledInviteDTO.setInviteRemarks(resultSet.getString("Remarks"));					
					LinkedHashMap<String, String> participants = new LinkedHashMap<>();				
					participants.put(resultSet.getString("Participant_ID"), resultSet.getString("Participants"));
					scheduledInviteDTO.setParticipants(participants);
					scheduledInvites.put(scheduledInviteDTO.getTimeOffId(),scheduledInviteDTO);

				}		

			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getScheduledInvitesByLoginUserID() method");
		return scheduledInvites;
	}


	public List<String> showParticipants(String timeOffId) throws SQLException,NamingException{
		logger.info("Inside LMS_DASHBOARD_DAO showParticipants() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		List<String> participantsList = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.SHOW_PARTICIPANTS;
			statement = connection.prepareCall(procedure);
			statement.setString(1,timeOffId);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				participantsList.add(resultSet.getString("Participants"));
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO showParticipants() method");
		return participantsList;
	}




	public String cancelRCloseInvite(int timeOffID, String statusREventType, String remarks, String loginId) throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO cancelRCloseInvite() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		String stauts ="";
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.cancel_r_close_invite;
			statement = connection.prepareCall(procedure);
			statement.setInt(1,timeOffID);
			statement.setString(2,statusREventType.trim());
			statement.setString(3,remarks.trim());
			statement.setString(4,loginId.trim());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {                     
				stauts=resultSet.getString("Status");
				System.out.println("##################"+stauts);
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO cancelRCloseInvite() method");
		return stauts;
	}


	public String getUserID(String userName) throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO getUserID() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		String userId ="";
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.getUserID;
			statement = connection.prepareCall(procedure);
			statement.setString(1,userName);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				System.out.println("USer Id == "    +resultSet.getString("ID"));
				userId = resultSet.getString("ID");
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getUserID() method");
		return userId;
	}
	public CreateRUpdateInviteDTO getInviteValues(String timeOffId) throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO getInviteValues() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		CreateRUpdateInviteDTO createRUpdateInviteDTO = new CreateRUpdateInviteDTO();
		LinkedHashMap<String, String> participants = new LinkedHashMap<String, String>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.GET_INVITE_VALUES;
			statement = connection.prepareCall(procedure);
			statement.setString(1,timeOffId);
			resultSet = statement.executeQuery();

			boolean addParticipant = false;
			while (resultSet.next()) {

				if(addParticipant){
					participants.put(resultSet.getString("Participant_Id"),resultSet.getString("Participants"));
				}else{
					createRUpdateInviteDTO.setInviteId(resultSet.getString("TimeOff_ID"));
					createRUpdateInviteDTO.setInviteType(resultSet.getString("Invite Type"));
					createRUpdateInviteDTO.setInviteFromDate(resultSet.getString("From_Date").replaceAll("-", "/"));
					createRUpdateInviteDTO.setInviteToDate(resultSet.getString("To_Date").replaceAll("-", "/"));
					createRUpdateInviteDTO.setInviteFormat(resultSet.getString("Unit"));
					String startTime =resultSet.getString("Start_Time");
					String[] startTokens = startTime.split(" ");

					if(createRUpdateInviteDTO.getInviteFormat().equalsIgnoreCase("Days")){
						createRUpdateInviteDTO.setInviteStartMeridiem(startTokens[0]);		
						createRUpdateInviteDTO.setInviteStartTime("");
					}else if(createRUpdateInviteDTO.getInviteFormat().equalsIgnoreCase("Hours")){
						createRUpdateInviteDTO.setInviteStartTime(startTokens[0]);
						createRUpdateInviteDTO.setInviteStartMeridiem(startTokens[1]);
					}					

					String endTime =resultSet.getString("End_Time");
					String[] endToken = endTime.split(" ");
					if(createRUpdateInviteDTO.getInviteFormat().equalsIgnoreCase("Days")){
						createRUpdateInviteDTO.setInviteEndMeridiem(endToken[0]);	
						createRUpdateInviteDTO.setInviteEndTime("");
					}else if(createRUpdateInviteDTO.getInviteFormat().equalsIgnoreCase("Hours")){
						createRUpdateInviteDTO.setInviteEndTime(endToken[0]);
						createRUpdateInviteDTO.setInviteEndMeridiem(endToken[1]);
					}
					createRUpdateInviteDTO.setNumOfDaysRHours(resultSet.getString("No of days/hrs"));

					createRUpdateInviteDTO.setInviteRemarks(resultSet.getString("Remarks"));
					participants.put(resultSet.getString("Participant_Id"),resultSet.getString("Participants"));
					addParticipant = true;
				}

			}
			createRUpdateInviteDTO.setParticipants(participants);
		} catch(Exception e){
			logger.error(e.getMessage(),e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getInviteValues() method");
		return createRUpdateInviteDTO;
	}
	public String updateInvite(CreateRUpdateInviteDTO createRUpdateInviteDTO)  throws SQLException,NamingException{

		logger.info("Inside LMS_DASHBOARD_DAO updateInvite() method");

		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		String status="";

		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.UPDATE_INVITE;
			statement = connection.prepareCall(procedure);
			statement.setString(1,createRUpdateInviteDTO.getInviteId());
			statement.setString(2,createRUpdateInviteDTO.getLoginId());
			statement.setString(3,createRUpdateInviteDTO.getParticipantIds());
			statement.setString(4,createRUpdateInviteDTO.getInviteType());
			statement.setString(5,createRUpdateInviteDTO.getInviteFromDate());
			statement.setString(6,createRUpdateInviteDTO.getInviteToDate());
			statement.setString(7,createRUpdateInviteDTO.getInviteStartTime());
			statement.setString(8,createRUpdateInviteDTO.getInviteEndTime());
			statement.setString(9,createRUpdateInviteDTO.getNumOfDaysRHours());
			statement.setString(10,createRUpdateInviteDTO.getInviteFormat());
			statement.setString(11,createRUpdateInviteDTO.getStatus());
			statement.setString(12,createRUpdateInviteDTO.getInviteRemarks());
			statement.setString(13,createRUpdateInviteDTO.getLoginUserName());

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				status = resultSet.getString("Status");
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}

		logger.info("Exiting LMS_DASHBOARD_DAO updateInvite() method");
		return status;
	}

	public Date getCutOFFDate() throws SQLException,NamingException{
		logger.info("Inside LMS_DASHBOARD_DAO getCutOFFDate() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		Date date=null;
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.GET_CUTOFF_DATE;
			statement = connection.prepareCall(procedure);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				date = resultSet.getDate("CutOff_Date");
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getCutOFFDate() method");
		return date;
	}

	public List<SendEmailDTO> sendEmail(String timeOffId)throws SQLException,NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO sendEmail() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		List<SendEmailDTO> objectList= new ArrayList<>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.GET_MAIL_ADDRESS_FOR_INVITE;
			statement = connection.prepareCall(procedure);
			statement.setString(1,timeOffId.trim());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				SendEmailDTO object= new SendEmailDTO();
				object.setTimeOffStatusId(resultSet.getString("TimeOffStatus_ID"));
				object.setFrom(resultSet.getString("FROM"));
				object.setTo(resultSet.getString("TO"));
				object.setSubject(resultSet.getString("EMail_Subject"));
				object.setStartDate(resultSet.getString("Start_Date"));
				object.setEndDate(resultSet.getString("End_Date"));
				objectList.add(object);
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO sendEmail() method");
		return objectList;
	}
	public String setEmailStatusForInvite(String transactionIDS, String emailMsg)throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO setEmailStatusForInvite() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		String status="";
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.Set_Email_Status;
			statement = connection.prepareCall(procedure);
			statement.setString(1,transactionIDS.trim());
			statement.setString(2,emailMsg.trim());
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				status = resultSet.getString("Status");
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO setEmailStatusForInvite() method");
		return status;

	}
	/**
	 * @param userId
	 * @return All Agents For Supervisor
	 * @throws SQLException
	 * @throws NamingException
	 */
	public LinkedHashMap<String, String> getAllAgentsForSupervisor(String userId)throws SQLException,NamingException  {
		logger.info("Inside LMS_DASHBOARD_DAO getAllAgentsForSupervisor() method");
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String procedure="";
		LinkedHashMap<String, String> response = new LinkedHashMap<String, String>();
		try {
			connection = dataSourceLMS.getConnection();
			procedure = StoredProcedureConstants.load_Agent_For_Supervisor;
			statement = connection.prepareCall(procedure);
			statement.setString(1,userId);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				response.put(resultSet.getString("Agent ID"),resultSet.getString("Agent Name"));
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getAllAgentsForSupervisor() method");
		return response;
	}
	/**
	 * @param agentName
	 * @param fromDate
	 * @param toDate
	 * @param startTime
	 * @param endTime
	 * @param unit
	 * @return
	 * @throws SQLException
	 */
	//TODO change method name 
	public TeleoptiCheckScheduleDTO getAgentsListForSchedule(String agentId, String agentName,
			String fromDate, String toDate, String startTime, String endTime,String unit) throws SQLException {
		logger.info("Inside LMS_DASHBOARD_DAO getAgentsListForSchedule() method");
		TeleoptiCheckScheduleDTO checkScheduleDTO = new TeleoptiCheckScheduleDTO();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultSet = null;
		String teleoptiQuery="";

		try {
			connection = dataSourceLMS.getConnection();
			teleoptiQuery = StoredProcedureConstants.GET_EQUIVALENT_TELEOPTI_PERSON_ID;
			statement = connection.prepareCall(teleoptiQuery);
			statement.setString(1,agentId);
			statement.setString(2,fromDate);
			statement.setString(3,toDate);
			statement.setString(4,startTime);
			statement.setString(5,endTime);
			statement.setString(6,unit);	

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				checkScheduleDTO.setAgentIdInTOMS(agentId);
				checkScheduleDTO.setAgentName(agentName);
				checkScheduleDTO.setPersonIdInTeleopti(resultSet.getString("Person_ID"));
				checkScheduleDTO.setStartDate(resultSet.getString("Start_Date"));
				checkScheduleDTO.setEndDate(resultSet.getString("End_Date"));				
			}
		} catch(Exception e){
			logger.error(e.getMessage(), e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getAgentsListForSchedule() method");
		return checkScheduleDTO;

	}

	public Map<String, List<?>> leaveProjectionTable(String clientId) throws SQLException,
	NamingException {
		logger.info("Inside LMS_DASHBOARD_DAO leaveProjectionTable() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String leaveProjectionquery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> leaveBalanceMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSourceLMS.getConnection();
			leaveProjectionquery = StoredProcedureConstants.getProjection;
			callableStatement = connection.prepareCall(leaveProjectionquery);
			callableStatement.setString(1, clientId);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
						getColumnVal="--";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			leaveBalanceMap.put(DashboardConstants.PROJECTIONEFIELDNAMEs,
					reportDescriptionList);
			leaveBalanceMap.put(DashboardConstants.PROJECTIONFIELDVALUES,
					reportList);

		}catch(Exception e){
			logger.error(e.getMessage(), e);			
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO leaveProjectionTable() method");
		return leaveBalanceMap;
	}
	
	public Map<String, List<?>> getLeaveHistoryTableSubRecords(String parentId) throws SQLException,
			NamingException {

				logger.info("Inside LMS_DASHBOARD_DAO getLeaveHistoryTableSubRecords() method");
				Connection connection = null;
				CallableStatement callableStatement = null;
				ResultSet resultSet = null;

				String leaveHistoryequery = "";
				List<Object> reportList = new ArrayList<Object>();
				List<String> reportDescriptionList = new ArrayList<String>();
				LinkedHashMap<String, List<?>> leaveHistoryMap = new LinkedHashMap<String, List<?>>();
				List<String> cellList = null;
				try {
					connection = dataSourceLMS.getConnection();
					leaveHistoryequery = StoredProcedureConstants.GETTIMEOFFDETAIL;
					callableStatement = connection.prepareCall(leaveHistoryequery);
					
					callableStatement.setString(1, parentId);
					resultSet = callableStatement.executeQuery();
					ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
					int columnCount = resultSetMetaData.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						String name = resultSetMetaData.getColumnName(i);
						reportDescriptionList.add(name);
					}

					while (resultSet.next()) {
						cellList = new ArrayList<String>();
						for (int i = 0; i < columnCount; i++) {
							String getColumnVal = resultSet
									.getString(reportDescriptionList.get(i));
							if(getColumnVal==null||getColumnVal==""||getColumnVal.equalsIgnoreCase("")){
								getColumnVal="--";
							}
							cellList.add(getColumnVal);
						}
						reportList.add(cellList);
					}
					leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDNAMEs,
							reportDescriptionList);
					leaveHistoryMap.put(DashboardConstants.LEAVEHISTORYFIELDVALUES,
							reportList);

				}finally {
					try {
						if (null != resultSet)
							resultSet.close();
					} catch (SQLException e) {
						logger.error(e.getMessage(), e);
						//e.printStackTrace();
					}
					try {
						if (null != callableStatement)
							callableStatement.close();
					} catch (SQLException e) {
						logger.error(e.getMessage(), e);
						//e.printStackTrace();
					}
					try {
						if (null != connection)
							connection.close();
					} catch (SQLException e) {
						logger.error(e.getMessage(), e);
						//e.printStackTrace();
					}
				}
				logger.info("Exiting LMS_DASHBOARD_DAO getLeaveHistoryTableSubRecords() method");
				return leaveHistoryMap;
			}
	public Map<String,String> getTeleoptiAgentDetails(LoginDetailDTO loginDTO) throws SQLException, NamingException {
		// TODO Auto-generated method stub
		logger.info("Inside LMS_DASHBOARD_DAO getTeleoptiAgentDetails() method");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String query="";
	
		Map<String,String> tabMap=new HashMap<String,String>();
		try {
			connection = dataSourceLMS.getConnection();
			query = StoredProcedureConstants.getTeleoptiAgent_id;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, loginDTO.getUserName());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				tabMap.put(DashboardConstants.AGENT_ID,resultSet.getString("Teleopti_Agent_Id"));
				tabMap.put(DashboardConstants.ROLE,resultSet.getString("Role"));
				
			}

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
				//e.printStackTrace();
			}
		}
		logger.info("Exiting LMS_DASHBOARD_DAO getTeleoptiAgentDetails() method");
		return tabMap;
	}
	
	public List<String> cancelAppliedRequest(String timeOFF_ID,String user) throws NamingException, ParseException {

		logger.info("Inside cancelAppliedRequest(String timeOFF_ID,String user)");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String cancelTimeoff = "";
		List<String> response = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();			
			cancelTimeoff = StoredProcedureConstants.CANCEL_TIMEOFF;
			callableStatement = connection.prepareCall(cancelTimeoff);
			callableStatement.setString(1, timeOFF_ID);			
			callableStatement.setString(2, user);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			
			while (resultSet.next()) {
				response.add(resultSet.getString("Transaction ID"));
				response.add(resultSet.getString("From_Email_Address"));
				response.add(resultSet.getString("To_Email_address"));
				response.add(resultSet.getString("Email_subject"));
				response.add(resultSet.getString("status"));
				
			}
		}catch(SQLException sqlException){
			logger.error(sqlException.getMessage(),sqlException);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
		}
		logger.info("Exit cancelAppliedRequest(String timeOFF_ID,String user)");
		return response;
	}

	
	public List<String> getOverTimeExceptionActivities() throws NamingException, ParseException {

		logger.info("Inside getOverTimeExceptionActivities()");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String overTimeActivities = "";
		List<String> response = new ArrayList<String>();
		try {
			connection = dataSourceLMS.getConnection();			
			overTimeActivities = StoredProcedureConstants.GETOVERTIMEEXCEPTION;
			callableStatement = connection.prepareCall(overTimeActivities);
			resultSet = callableStatement.executeQuery();
			
			while (resultSet.next()) {
				response.add(resultSet.getString(1));
			}
		}catch(SQLException sqlException){
			logger.error(sqlException.getMessage(),sqlException);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
		}
		logger.info("Exit getOverTimeExceptionActivities()");
		return response;
	}

	
	
}
