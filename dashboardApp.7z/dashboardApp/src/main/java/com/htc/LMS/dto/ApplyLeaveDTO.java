package com.htc.LMS.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplyLeaveDTO {

	String agentID;
	String supervisorName;
	String leaveType;
	String fromDate;
	String toDate;
	String startTime;
	String endTime;
	String noOfDaysHrs;
	String  unitOfMeasurement;
	String status;
	String remarks;
	String emailComments;
	String loginId;
	Map<String, List<?>> leaveProjectionTableDetailMap = new HashMap<>();
	String outputStatus;
	Map<String, List<?>> leaveBalanceTableDetailMap = new HashMap<>();
	String overTimeActivity;

	public String getOverTimeActivity() {
		return overTimeActivity;
	}
	public void setOverTimeActivity(String overTimeActivity) {
		this.overTimeActivity = overTimeActivity;
	}
	public String getOutputStatus() {
		return outputStatus;
	}
	public Map<String, List<?>> getLeaveBalanceTableDetailMap() {
		return leaveBalanceTableDetailMap;
	}
	public void setLeaveBalanceTableDetailMap(
			Map<String, List<?>> leaveBalanceTableDetailMap) {
		this.leaveBalanceTableDetailMap = leaveBalanceTableDetailMap;
	}
	public void setOutputStatus(String outputStatus) {
		this.outputStatus = outputStatus;
	}
	public Map<String, List<?>> getLeaveProjectionTableDetailMap() {
		return leaveProjectionTableDetailMap;
	}
	public void setLeaveProjectionTableDetailMap(
			Map<String, List<?>> leaveProjectionTableDetailMap) {
		this.leaveProjectionTableDetailMap = leaveProjectionTableDetailMap;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getAgentID() {
		return agentID;
	}
	public void setAgentID(String agentID) {
		this.agentID = agentID;
	}
	public String getSupervisorName() {
		return supervisorName;
	}
	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getNoOfDaysHrs() {
		return noOfDaysHrs;
	}
	public void setNoOfDaysHrs(String noOfDaysHrs) {
		this.noOfDaysHrs = noOfDaysHrs;
	}
	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}
	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getEmailComments() {
		return emailComments;
	}
	public void setEmailComments(String emailComments) {
		this.emailComments = emailComments;
	}
	@Override
	public String toString() {
		return "ApplyLeaveDTO [agentID=" + agentID + ", supervisorName="
				+ supervisorName + ", leaveType=" + leaveType + ", fromDate="
				+ fromDate + ", toDate=" + toDate + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", noOfDaysHrs=" + noOfDaysHrs
				+ ", unitOfMeasurement=" + unitOfMeasurement + ", status="
				+ status + ", remarks=" + remarks + ", emailComments="
				+ emailComments + "]";
	}




}
