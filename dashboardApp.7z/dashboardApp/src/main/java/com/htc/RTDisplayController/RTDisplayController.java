package com.htc.RTDisplayController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htc.RTDisplayBoardDao.HRTDisplayBoardDao;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  NYHHTable DataSet
 * */

@Controller
public class RTDisplayController {

	private static final Logger logger = Logger
			.getLogger(RTDisplayController.class);
	@Autowired
	HRTDisplayBoardDao nyhhDao;

	@RequestMapping(value = "/nyhhTable", method = RequestMethod.POST)
	public String getNyhhDatatable(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");

		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> nyhhMap = new HashMap<>();
			try {
				nyhhMap = nyhhDao.nyhhClient(DashboardConstants.NYHHQUERYPARAM);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());
			}
			request.setAttribute(DashboardConstants.HEAD_NYHHOakwood, "nyhh");
			request.setAttribute(DashboardConstants.NYHHSESSIONMAP, nyhhMap);
			return "RTDisplayBoard/HRT_DisplayBoard";
		} else {
			return "common/UnAuthoriseAccess";
		}

	}

	@RequestMapping(value = "/nyhhOakwood", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> getPulseAlert(ModelMap model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		String client = request.getParameter("Client");
		String clientname = client.toUpperCase();
		Map<String, List<?>> nyhhMap = new HashMap<>();
		try {

			nyhhMap = nyhhDao.nyhhClient(clientname);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		request.setAttribute(DashboardConstants.NYHHSESSIONMAP, nyhhMap);
		return nyhhMap;
	}

	@RequestMapping(value = "/oakwood", method = RequestMethod.POST)
	public String getOakwoodDatatable(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");

		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> nyhhMap = new HashMap<>();
			try {
				nyhhMap = nyhhDao.nyhhClient(DashboardConstants.OAKWOODPARAM);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}
			request.setAttribute(DashboardConstants.HEAD_NYHHOakwood, "Oakwood");
			request.setAttribute(DashboardConstants.NYHHSESSIONMAP, nyhhMap);

			return "RTDisplayBoard/HRT_DisplayBoard";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/jcmc", method = RequestMethod.POST)
	public String getJcmcDatatable(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");

		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> nyhhMap = new HashMap<>();
			try {
				nyhhMap = nyhhDao.nyhhClient(DashboardConstants.JSMC);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}
			request.setAttribute(DashboardConstants.HEAD_NYHHOakwood, "jcmc");
			request.setAttribute(DashboardConstants.NYHHSESSIONMAP, nyhhMap);

			return "RTDisplayBoard/HRT_DisplayBoard";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}
	
	@RequestMapping(value = "/rwjbh", method = RequestMethod.POST)
	public String geRwJBarnabsDatatable(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");

		if (userName != null && !("".equals(userName))) {
			Map<String, List<?>> nyhhMap = new HashMap<>();
			try {
				nyhhMap = nyhhDao.nyhhClient(DashboardConstants.RWJBH);
			} catch (Exception e) {
				logger.error(e.getMessage());
				throw new Exception(e.getMessage());

			}
			request.setAttribute(DashboardConstants.HEAD_NYHHOakwood, "RWJBH");
			request.setAttribute(DashboardConstants.NYHHSESSIONMAP, nyhhMap);

			return "RTDisplayBoard/HRT_DisplayBoard";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

}
