package com.htc.authentication.dto;

import java.util.List;

public class LoginDetailDTO {

	private String authType;
	private String userName;
	private String password;
	private List<Integer> groupList;
	private  String group;
	private String teleopti_Agent_Id;
	public String getTeleopti_Agent_Id() {
		return teleopti_Agent_Id;
	}

	public void setTeleopti_Agent_Id(String teleopti_Agent_Id) {
		this.teleopti_Agent_Id = teleopti_Agent_Id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	private String role;

	private  String allSecQuestions;
	private  String allSecAnswers;

	//private  String secQuestArray;
	//private  String secAnsArray;

	private  String newPassword;
	private  String newConfirmPassword;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public List<Integer> getGroupList() {
		return groupList;
	}

	public void setGroupList(List<Integer> groupList) {
		this.groupList = groupList;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getAuthType() {
		return authType;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getNewConfirmPassword() {
		return newConfirmPassword;
	}

	public void setNewConfirmPassword(String newConfirmPassword) {
		this.newConfirmPassword = newConfirmPassword;
	}

	public String getAllSecQuestions() {
		return allSecQuestions;
	}

	public void setAllSecQuestions(String allSecQuestions) {
		this.allSecQuestions = allSecQuestions;
	}

	public String getAllSecAnswers() {
		return allSecAnswers;
	}

	public void setAllSecAnswers(String allSecAnswers) {
		this.allSecAnswers = allSecAnswers;
	}

}






