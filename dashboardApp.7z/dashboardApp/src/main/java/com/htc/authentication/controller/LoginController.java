package com.htc.authentication.controller;


import java.io.InputStream;
import java.util.Properties;
import java.security.KeyPair;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.htc.LMS.dao.LMS_DASHBOARD_DAO;
import com.htc.authentication.dao.LoginDetailDAO;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;
import com.htc.utility.JCryptionUtil;

import org.apache.log4j.Logger;

import com.bmc.arsys.api.*;

import java.util.*;

/*
 * HTC_Offshore
 * purpose: return Login DataSet
 * */
@Controller
@SessionAttributes("username")
public class LoginController {

	private static final Logger logger = Logger.getLogger(LoginController.class);


	@Autowired
	private LoginDetailDAO loginDetailDAO;

	@Autowired
	private LoginDetailDAO loginTabsReports;
	
	@Autowired
	LMS_DASHBOARD_DAO dataSourceLMS;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getIndexPage(ModelMap model, HttpServletRequest request){
		logger.info("Logging started:::::");
		KeyPair keys = null;
		keys = JCryptionUtil.generateKeypair(1024);
		String e = JCryptionUtil.getPublicKeyExponent(keys);
		String n = JCryptionUtil.getPublicKeyModulus(keys);
		request.getSession().setAttribute("keys1", e);
		request.getSession().setAttribute("keys2", n);
		request.getSession().setAttribute("keyforDecrypt", keys);
		return "Index";
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "static-access" })
	@RequestMapping(value = "/loginDetailValidation", method = RequestMethod.POST)
	public String getLoginDetail(ModelMap model, HttpServletRequest request,
			HttpSession session) throws Exception {

		String authType = "";
		String userName = "";
		String password = "";

		userName = request.getParameter("hidusername");
		password = request.getParameter("hidpassword");
		authType = request.getParameter("hidauthtype");

		if(userName.isEmpty() && password.isEmpty() && authType.isEmpty()){
			return "common/UnAuthoriseAccess";
		}else{
			String captcha = "";
			int   count=(int) session.getAttribute("CAPTCHECOUNT");
			KeyPair keys = null;
			session.setAttribute("authenticationType", authType);
			keys=(KeyPair) session.getAttribute("keyforDecrypt");
			password=JCryptionUtil.decrypt(password, keys);
			logger.info("After Decryption USERNAME "+userName);
			logger.info("After Decryption PASSWORD "+password);
			captcha = request.getParameter("hidcaptcha");
			String strCaptcha = (String) session
					.getAttribute(DashboardConstants.CAPTCHA);
			if(count >=5 ){
				if (captcha == null || (captcha != null && !captcha.equals(strCaptcha))) { // Block will work for invalid Captcha
					request.setAttribute(DashboardConstants.WARNING_MESSAGE,
							DashboardConstants.WARNING_MESSAGE_CAPTCHA);
					logger.info(DashboardConstants.WARNING_MESSAGE_CAPTCHA);
					return "authentication/Login";
				} 
			}

			//For Remedy Users Starts
			if(DashboardConstants.DASHBOARD_AUTH_TYPE_REMEDY.equals(authType)){  

				ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
				InputStream input = classLoader.getResourceAsStream("dbconfig.properties");
				Properties p = new Properties();
				p.load(input);

				// AR System Call Start
				Integer remedyUserFound = 0;
				String loginAlias = "";
				//String userRequestID = "";
				Integer remedyAuthenticated = 0;
				boolean displayErrorflag = true;
				List<Integer> groupid = new ArrayList<Integer>();
				List<String> groupNames = new ArrayList<String>();
				String displayError = "";
				Integer ldapAuthenticated = 0;
				String userClient = "";
				String userMasterClient = "";
				String ldapRequestID = "";
				String errorText="";
				String technicalText="";
				java.util.Date datestart = new java.util.Date();
				java.util.Date datestop;
				long ddifference;  //used to track the login time			
				Integer ldapFound = 0;


				//get the users IP address
				String ip = request.getHeader("X-Forwarded-For");  
				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
					ip = request.getHeader("Proxy-Client-IP");  
				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
					ip = request.getHeader("WL-Proxy-Client-IP");  
				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
					ip = request.getHeader("HTTP_CLIENT_IP");  
				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
					ip = request.getHeader("HTTP_X_FORWARDED_FOR");  
				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
					ip = request.getRemoteAddr(); 

				String schemaName = "User";
				String queryString = "'Login Name' = \"" + userName
						+ "\" AND 'Status' = \"Current\"";
				try {
					ARServerUser cntx = new ARServerUser(
							p.getProperty("REMEDY_USERNAME"),
							p.getProperty("REMEDY_PWD"), "",
							p.getProperty("REMEDY_SERVER"));

					/*ARServerUser cntx = new ARServerUser(
							DashboardConstants.REMEDY_USERNAME,
							DashboardConstants.REMEDY_PWD, "",
							DashboardConstants.REMEDY_SERVER);*/
					cntx.setPort(5000);
					QualifierInfo qual = cntx.parseQualification("User",
							queryString);
					List<EntryListInfo> eListInfos = cntx.getListEntry("User",
							qual, 0, 0, null, null, false, null);

					for (EntryListInfo eListInfo : eListInfos) {
						logger.info("eListInfo.getEntryID--"+eListInfo.getEntryID());
					}
					if (eListInfos.size() == 0) {
						displayError = "Incorrect user name and/or password.";
						displayErrorflag = false;
						logger.info("userNameValidation : ---> " + displayError);
					}

					for (EntryListInfo eListInfo : eListInfos) {
						Entry record = cntx.getEntry(schemaName,
								eListInfo.getEntryID(), null);

						remedyUserFound = 1;
						loginAlias = record.get(117).toString();

						if (loginAlias == null) {
							loginAlias = "";
						}
						//userRequestID = record.get(1).toString();
					}
				} catch (ARException e) {
					count++;
					displayErrorflag = false;
					displayError = "Incorrect user name and/or password.";
					logger.info("userNameValidation : ---> " + displayError);

				}
				if(remedyUserFound == 1) {
					ARServerUser serveruser = new ARServerUser();
					serveruser.setUser(userName);
					serveruser.setPassword(password);
					serveruser.setServer(p.getProperty("REMEDY_SERVER"));

					try {
						serveruser.setClientType(9);
						serveruser.setPort(5000);
						serveruser.login();
						remedyAuthenticated = 1;
						for (GroupInfo groupInfo : serveruser.getListGroup(
								userName, password)) {
							logger.info("groupInfo : ---> " + groupInfo);
							groupid.add(groupInfo.getId());
							groupNames = groupInfo.getGroupNames();
						}
					} catch (ARException ex) {
						remedyAuthenticated = 0;
						displayError = "Incorrect user name and/or password";
						displayErrorflag = false;
						logger.info("userNameValidation : --->" + displayError);
					}
				}
				// AR System Call End

				if (displayErrorflag) {
					String loginList="";
					String teleopti_Agent_Id="";
					String teleopti_role="";
					Map<String,String> teleopti_agent_role_Map=null;
					List groupTabsList = new ArrayList();
					Map tabReports = new HashMap();
					//List reportsForUserList = new ArrayList();
					String userNameValidation = "";
					logger.info("userName : ---> " + userName);
					logger.info("password : ---> " + password);
					LoginDetailDTO loginDTO = new LoginDetailDTO();
					QueryBuilder querybuilder =new QueryBuilder();
					loginDTO.setUserName(userName);
					loginDTO.setPassword(password);
					loginDTO.setGroupList(groupid);
					loginDTO.setAuthType(authType);
					try {
						loginList=querybuilder.dashboardExecutiveGroupData(loginDTO);
						loginDTO.setGroup(loginList);
						groupTabsList = loginTabsReports.getTabsForUser(loginDTO);
						tabReports = loginTabsReports.getReportsForUser(loginDTO);
						teleopti_agent_role_Map=dataSourceLMS.getTeleoptiAgentDetails(loginDTO);
						if(null!=teleopti_agent_role_Map)
						{
						teleopti_Agent_Id=teleopti_agent_role_Map.get(DashboardConstants.AGENT_ID);
						teleopti_role=teleopti_agent_role_Map.get(DashboardConstants.ROLE);
						}
						logger.info("Teleopti Agent id  ="+teleopti_Agent_Id+"   Role ="+teleopti_role);
						
						logger.info("userNameValidation : ---> "
								+ userNameValidation);
						
						
						
						
					} catch (Exception e) {
						logger.error(e.getMessage());
						throw new Exception(e.getMessage());
					}
					
					
					session.setAttribute("username", loginDTO.getUserName());
					session.setAttribute(DashboardConstants.USER_REPORT_MAP,
							tabReports);
					session.setAttribute(DashboardConstants.USER_TABS,
							groupTabsList);
					session.setAttribute(DashboardConstants.GROUP_IDS, groupid);
					session.setAttribute(DashboardConstants.GROUP_NAMES, groupNames);
					session.setAttribute(DashboardConstants.TELEOPTI_USER_ID, teleopti_Agent_Id);
					session.setAttribute(DashboardConstants.ROLE, teleopti_Agent_Id);
					return "authentication/DashBoardHome";
				}else{ // L DAP Authentication

					//vairables set from LDAP:Accounts Form
					String preUser = "";  
					String postUser = ""; 
					String host = "";     
					String port = "";     
					String authentication_server = "";
					String ldap = "";
					String servername=p.getProperty("REMEDY_USERNAME");


					if (remedyAuthenticated==0 && !loginAlias.equals("")) {
						datestart = new java.util.Date();

						// lookup the ldap information	
						//if LDAP looping is required put the loop here
						//get the master client for the user  CMN:PEO+CMN:CNFO-Join
						// then get the authentication record for client or master client

						try {
							ARServerUser cntx = new ARServerUser(
									p.getProperty("REMEDY_USERNAME"),
									p.getProperty("REMEDY_PWD"), "",
									p.getProperty("REMEDY_SERVER"));

							/*ARServerUser cntx= new ARServerUser(
								DashboardConstants.REMEDY_USERNAME,
								DashboardConstants.REMEDY_PWD, "",
								DashboardConstants.REMEDY_SERVER);*/

							QualifierInfo qual = cntx.parseQualification("CMN:ClientInfo", "'Client' = \""+userName.split("-")[0]+"\"");  
							List<EntryListInfo> eListInfos = cntx.getListEntry("CMN:ClientInfo", qual, 0, 0, null, null, false, null);  

							if (eListInfos.size()==0) {  
								//Client not found using Login ID
								String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
								String[] values={userName,"Login.jsp",userName.split("-")[0],(String)ip,"Remedy","Could not find client '"+userName.split("-")[0]+"' using the Remedy ID '"+userName+"'.","Could not find client '"+userName.split("-")[0]+"' using the Remedy ID '"+userName+"'.","CMN:ClientInfo",(String)request.getHeader("User-Agent"),servername};
								logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs", p.getProperty("REMEDY_USERNAME"),p.getProperty("REMEDY_PWD")));
							}
							else {
								for (EntryListInfo eListInfo : eListInfos) {
									Entry record = cntx.getEntry("CMN:ClientInfo",eListInfo.getEntryID(), null);  
									//record.keySet() is all the data
									//Get information about the users client and LDAP Configuration
									userMasterClient = record.get(536870914).toString( );  //Master Client
									userClient = record.get(536870913).toString( );        //Client
								}
								//now get the ldap record for the client/master client
								QualifierInfo ldapqual = cntx.parseQualification("LDAP:Accounts", "('Client' = \""+userMasterClient+"\" OR 'Client' = \""+userClient+"\") AND 'Status' = \"Enabled\" AND 'AREA LDAP' = \"Yes\"");  
								List<EntryListInfo> LDAPListInfos = cntx.getListEntry("LDAP:Accounts", ldapqual, 0, 0, null, null, false, null);  

								if (LDAPListInfos.size()==0) {
									//LDAP Accounts record(s) not found for this client
									String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
									String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy","Login Alias was found for '"+loginAlias+"' but there was no LDAP:Accounts record for the client.","Login Alias was found for '"+loginAlias+"' but there was no LDAP:Accounts record for the client.","LDAP:Accounts",(String)request.getHeader("User-Agent"),servername};
									logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs", p.getProperty("REMEDY_USERNAME"), p.getProperty("REMEDY_PWD")));
								}
								else {
									ldapFound=1;
									for (EntryListInfo LDAPListInfo : LDAPListInfos) {  
										Entry LDAPrecord = cntx.getEntry("LDAP:Accounts",LDAPListInfo.getEntryID(), null);  
										//LDAPrecord.keySet() is all the data

										ldapRequestID = LDAPrecord.get(1).toString();  //Record ID for logging
										host = LDAPrecord.get(536870914).toString();   //IP address
										port = LDAPrecord.get(536870916).toString();   //port

										//pre and post text could be null so check first
										preUser = LDAPrecord.get(536870939).toString();
										if (preUser == null) 
										{preUser="";}
										postUser = LDAPrecord.get(536870942).toString();
										if (postUser == null) 
										{postUser="";}

										authentication_server = host+":"+port;
										ldap = "LDAP://" + authentication_server + "/";
									}
								}
							}     
						}
						catch (ARException e) {  
							// Master client/LDAP Lookup error:
							String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
							String[] values={userName,"Login.jsp",userName.split("-")[0],(String)ip,"Remedy","Unexpected error when trying to look up the client LDAP record.","Unexpected error when trying to look up the client LDAP record.  Error:"+e.toString().replaceAll("[^\\x0A\\x0D\\x20-\\x7E]", ""),"Remedy",(String)request.getHeader("User-Agent"),servername};
							logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs", p.getProperty("REMEDY_USERNAME"), p.getProperty("REMEDY_PWD")));
						} 

						if (ldapFound==1) {
							try {
								//validate user with LDAP
								Hashtable env = new Hashtable();
								env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
								env.put(Context.PROVIDER_URL, ldap);
								env.put(Context.REFERRAL, "ignore" );
								env.put(Context.SECURITY_AUTHENTICATION,"simple");
								env.put(Context.SECURITY_PRINCIPAL, preUser + loginAlias + postUser); 
								env.put(Context.SECURITY_CREDENTIALS,password); 
								//specify attributes to be returned in binary format
								env.put("java.naming.ldap.attributes.binary","tokenGroups");

								DirContext ctx = new InitialDirContext(env);
								ctx.addToEnvironment(ctx.REFERRAL, "ignore");

								//ctx.addToEnvironment(ctx.setIgnorePartialResultException, true);
								//ctx.ldapTemplate.setIgnorePartialResultException(true); // Active Directory doesn�t transparently handle referrals. This fixes that.  NOT WORKING IN JAVA

								ldapAuthenticated=1;

								datestop = new java.util.Date();
								ddifference =  datestop.getTime() - datestart.getTime();

								String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870918","536870919","536870920"};
								String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy","Successfully authenticated.","'"+loginAlias+"' was successfully authenticated in "+ddifference+" milliseconds.","LDAP:Accounts",ldapRequestID,(String)request.getHeader("User-Agent"),servername};				
								logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs",p.getProperty("REMEDY_USERNAME"), p.getProperty("REMEDY_PWD")));
							}
							catch (NamingException e) {
								//LDAP Error
								count++;
								ldapAuthenticated=0;
								datestop = new java.util.Date();
								ddifference =  datestop.getTime() - datestart.getTime();

								errorText=ldaperror(e.toString());
								technicalText=ldaptechnical(e.toString().replaceAll("[^\\x0A\\x0D\\x20-\\x7E]", ""));
								displayError = errorText;

								String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870918","536870919","536870920"};
								String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy",errorText,technicalText,"LDAP:Accounts",ldapRequestID,(String)request.getHeader("User-Agent"),servername};
								logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs",p.getProperty("REMEDY_USERNAME"),  p.getProperty("REMEDY_PWD")));	  
							}
						}

						if (ldapAuthenticated==1) {
							//if LDAP authenticated then update the users password in Remedy
							try {
								logger.error(" LDAP PASSWORD Updated in Remedy");
								/*ARServerUser cntx= new ARServerUser(
									DashboardConstants.REMEDY_USERNAME,
									DashboardConstants.REMEDY_PWD, "",
									DashboardConstants.REMEDY_SERVER);

							Entry userEntry = cntx.getEntry("User", userRequestID, null);
							userEntry.put(102, new Value(password));  //update the password
							cntx.setEntry("User", userRequestID, userEntry, null, 0);*/
								//cntx.clear(); do this at the end

								String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
								String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy","Remedy password synced with AD.","Remedy password synced with AD. Remedy ID = '"+userName+"', Login Alias = '"+loginAlias+"'.","Remedy",(String)request.getHeader("User-Agent"),servername};
								APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs", p.getProperty("REMEDY_USERNAME"), p.getProperty("REMEDY_PWD"));
								

								request.setAttribute(DashboardConstants.WARNING_MESSAGE,
										DashboardConstants.LDAP_WARNING_MESSAGE_INVALID);
								logger.info("Invalid Credential : ");
								session.setAttribute("CAPTCHECOUNT", count);
								return "authentication/Login";
								//return "authentication/DashBoardHome";
							
							
							}
							catch(NullPointerException e) {
								String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
								String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy","Error syncing Remedy password with AD.","Error syncing Remedy password with AD. Remedy ID = '"+userName+"', Login Alias = '"+loginAlias+"'.  "+e.toString().replaceAll("[^\\x0A\\x0D\\x20-\\x7E]", ""),"Remedy",(String)request.getHeader("User-Agent"),servername};
								logger.info(APILog(fields, values, p.getProperty("REMEDY_SERVER"), "CTS:KS_RQT_Error_logs", p.getProperty("REMEDY_USERNAME"), p.getProperty("REMEDY_PWD")));
							}
							/*	catch(ARException e) {
							// Set users password error
							String ExceptionString = e.toString().replaceAll("[^\\x0A\\x0D\\x20-\\x7E]", "");
							String[] fields={"8","536870924","536870932","536870913","536870914","536870915","536870916","536870917","536870919","536870920"};
							String[] values={loginAlias,"Login.jsp",userClient,(String)ip,"Remedy","Error syncing Remedy password with AD.","Error syncing Remedy password with AD. Remedy ID = '"+userName+"', Login Alias = '"+loginAlias+"'.  "+ExceptionString,"Remedy",(String)request.getHeader("User-Agent"),servername};
							APILog(fields, values, DashboardConstants.REMEDY_SERVER, "CTS:KS_RQT_Error_logs", DashboardConstants.REMEDY_USERNAME, DashboardConstants.REMEDY_PWD);
						}*/
						}else{
							request.setAttribute(DashboardConstants.WARNING_MESSAGE,
									DashboardConstants.LDAP_WARNING_MESSAGE_INVALID);
							logger.info("Invalid Credential : ");
							session.setAttribute("CAPTCHECOUNT", count);
							return "authentication/Login";
						}
					}

					request.setAttribute(DashboardConstants.WARNING_MESSAGE,
							DashboardConstants.WARNING_MESSAGE_INVALID);
					logger.info("Invalid Credential : ");
					session.setAttribute("CAPTCHECOUNT", count);

					return "authentication/Login";
				}
				//}
			}
			//For Remedy Users Ends

			//For External Users Start
			else if(DashboardConstants.DASHBOARD_AUTH_TYPE_EXTERNAL.equals(authType)){ 

				LoginDetailDTO loginDTO = new LoginDetailDTO();
				loginDTO.setUserName(userName);
				loginDTO.setPassword(password);
				loginDTO.setAuthType(authType);
				String secQuesAnsKey = "";
				String secPassValKey = "";
				String userId="";
				String role="";
				List<String> validUser= new ArrayList<String>();

				try {
					validUser = loginTabsReports.getExternalUser(loginDTO);
					logger.info("userNameValidation : ---> "
							+ validUser);
				} catch (Exception e) {
					logger.error(e.getMessage());
					throw new Exception(e.getMessage());
				}
				secPassValKey = validUser.get(0);
				secQuesAnsKey = validUser.get(1);
				/* secPassValKey = "1";
				 secQuesAnsKey = "0";*/
				if("1".equals(secPassValKey) && "1".equals(secQuesAnsKey)){
					List groupTabsList = new ArrayList();
					Map tabReports = new HashMap();
					String userNameValidation = "";
					try {
						groupTabsList = loginTabsReports.getTabsForUser(loginDTO);
						tabReports = loginTabsReports.getReportsForUser(loginDTO);
						logger.info("userNameValidation : ---> "
								+ userNameValidation);
					}catch (Exception e) {
						logger.error(e.getMessage());
						throw new Exception(e.getMessage());
					}
					
				
					try {
						userId = dataSourceLMS.getUserID(loginDTO.getUserName());
					} catch (SQLException e) {
						e.printStackTrace();
					} catch (NamingException e) {
						e.printStackTrace();
					}
					
					session.setAttribute(DashboardConstants.TELEOPTI_USER_ID, userId);
					session.setAttribute(DashboardConstants.ROLE, userId);
					session.setAttribute("username", loginDTO.getUserName());
					session.setAttribute(DashboardConstants.USER_REPORT_MAP,
							tabReports);
					session.setAttribute(DashboardConstants.USER_TABS,
							groupTabsList);
					return "authentication/DashBoardHome";
				}else if("1".equals(secPassValKey) && "0".equals(secQuesAnsKey)){
					List<String> SecurityQuestionList= new ArrayList<String>();
					try {
						SecurityQuestionList = loginTabsReports.getSecQuesForNewUser(loginDTO);
					}catch (Exception e) {
						throw new Exception(e.getMessage());
					}
					request.setAttribute("SecurityQuestion",SecurityQuestionList);
					request.setAttribute("TempUserName",userName);
					return "authentication/SetSecurityQuestion";
				}else{
					count++;
					session.setAttribute("CAPTCHECOUNT", count);
					request.setAttribute(DashboardConstants.WARNING_MESSAGE,
							DashboardConstants.WARNING_MESSAGE_INVALID);
					logger.info("Invalid Credential : ");
					return "authentication/Login";
				}
			}
			//For External Users ends
			else{
				return "common/UnAuthoriseAccess";
			}
		}
	}


	@RequestMapping(value = "/homePage", method = RequestMethod.GET)
	public String getHomePage(ModelMap model, HttpServletRequest request,HttpSession session){
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			logger.info("Home Page is Displaying : ");
			return "authentication/DashBoardHome";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "logout", method = RequestMethod.POST)
	public String getLogout(ModelMap model, HttpServletRequest request, HttpSession session,SessionStatus sessionStatus){
		String userName = (String) session.getAttribute("username");
		if(userName != null && !("".equals(userName))){
			logger.info("Entered to Logout Page : ");
			sessionStatus.setComplete();
			session.invalidate();
			//request.setAttribute(DashboardConstants.WARNING_MESSAGE, DashboardConstants.WARNING_MESSAGE_LOGOUT);
			logger.info("successfully Logged Out: ");
			return "redirect:";
		}else{
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String getLogonPage(ModelMap model, HttpServletRequest request, HttpSession session,SessionStatus sessionStatus){
		logger.info("Login Process started : ");
		sessionStatus.setComplete();
		session.setAttribute(DashboardConstants.SESSION_STATUS_NAME, DashboardConstants.SESSION_STATUS_VAL);
		String warningMsg = request.getParameter(DashboardConstants.SESSION_EXPIRE_NAME);
		request.setAttribute(DashboardConstants.WARNING_MESSAGE, warningMsg);
		session.setMaxInactiveInterval(60*60);
		logger.info("Login Page Landed successfully : ");
		return "authentication/Login";
	}

	private String APILog(String[] fields, String[] values, String RemServerName, String RemedyForm, String RemPrincipal, String RemPassword) {
		String ExceptionString = "";
		String[] ExceptionArray;
		String returnValue="";
		if (fields.length==values.length) {
			try {

				ARServerUser errorcnx=new ARServerUser(RemPrincipal,RemPassword,"",RemServerName);		
				Entry entry = new Entry(); 

				for( int i=0 ; i<fields.length ; i++) {
					entry.put(Integer.parseInt(fields[i]), new Value(values[i]));
				}           
				returnValue = errorcnx.createEntry("CTS:KS_RQT_Error_logs", entry);
				errorcnx.clear();
				return returnValue;
			}
			catch(NullPointerException e) {
				return "Null Pointer exception " + e;
			}
			catch(ARException e) {
				ExceptionString = e.toString();
				ExceptionArray = ExceptionString.split("MessageText:");
				ExceptionArray = ExceptionArray[1].split("AppendedText:");
				if (ExceptionArray[0].length()<5) {
					ExceptionString = e.toString();
					ExceptionArray = ExceptionString.split("AppendedText:");
					return ExceptionArray[1];
				}
				else {
					return ExceptionArray[0];
				}
			}
		}
		else {
			return "Field and value lengths do not match.";
		}
	}


	private String ldaperror( String s ) {
		String rs=s;
		if (s==null) {
			return null;
		}
		else {
			if (s.indexOf("code 1 ")>=0)
			{rs="Server Error:  Unable to properly respond to your request.";}
			if (s.indexOf("code 3 ")>=0)
			{rs="Server Error:  Operational time limit specified by either the client or the server has been exceeded.";}
			if (s.indexOf("code 7 ")>=0)
			{rs="Server Error:  The requested authentication method is not supported by the LDAP server.";}
			if (s.indexOf("code 8 ")>=0)
			{rs="Server Error:  The LDAP server is requesting that only strong authentication be used.";}
			if (s.indexOf("code 48 ")>=0)
			{rs="Server Error:  The authentication method passed to the server cannot be used correctly.";}
			if (s.indexOf("code 49 ")>=0)
			{rs="Incorrect user name and/or password.";}
			if (s.indexOf("code 530 ")>=0)
			{rs="Restrictions on your account are preventing you from logging in at this time.";}
			if (s.indexOf("code 532 ")>=0)
			{rs="Incorrect user name and/or password.";} //The specified account password has expired
			if (s.indexOf("code 533 ")>=0)
			{rs="Incorrect user name and/or password.";} //The specified account has been disabled
			if (s.indexOf("code 701 ")>=0)
			{rs="Incorrect user name and/or password.";} //The specified account expired
			if (s.indexOf("code 773 ")>=0)
			{rs="Incorrect user name and/or password.";} //The password for the specified account must be changed before logging in.
			if (s.indexOf("CommunicationException:")>=0)
			{rs="Communication Error:  Cannot connect to the authentication server.";}
			return rs;
		}
	}


	private String ldaptechnical( String s ) {
		String rs=s;
		if (s==null) {
			return null;
		}
		else {
			if (s.indexOf("data 525")>=0)
			{rs="User not found - ";}	
			if (s.indexOf("data 52e")>=0)
			{rs="Invalid credentials - ";}	
			if (s.indexOf("data 530")>=0)
			{rs="Not permitted to logon at this time - ";}	
			if (s.indexOf("data 531")>=0)
			{rs="Not permitted to logon at this workstation - ";}	
			if (s.indexOf("data 532")>=0)
			{rs="Password expired - ";}	
			if (s.indexOf("data 533")>=0)
			{rs="Account disabled - ";}	
			if (s.indexOf("data 534")>=0)
			{rs="The user has not been granted the requested logon type at this machine - ";}	
			if (s.indexOf("data 701")>=0)
			{rs="Account expired - ";}	
			if (s.indexOf("data 773")>=0)
			{rs="User must reset password - ";}	
			if (s.indexOf("data 775")>=0)
			{rs="User account locked - ";}	
			return rs + s;
		}
	}

	@RequestMapping(value = "/insertSecAnswer", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> setSecurityAnswer(ModelMap model, HttpServletRequest request, HttpSession session,SessionStatus sessionStatus) throws Exception{

		String strTempUserName= request.getParameter("username");
		String strQuestionArray= request.getParameter("hidquestionall");
		String strAnswerArray= request.getParameter("hidanswerall");

		List<String> SecAnsUpdStatus = null;

		if(!"".equals(strQuestionArray) && null != strQuestionArray && !"".equals(strAnswerArray) && null != strAnswerArray ){
			LoginDetailDTO loginDTO= new LoginDetailDTO();
			loginDTO.setAllSecQuestions(strQuestionArray);
			loginDTO.setAllSecAnswers(strAnswerArray);
			SecAnsUpdStatus = new ArrayList<String>();
			try{
				SecAnsUpdStatus = loginTabsReports.setSecAnsForNewUser(loginDTO,strTempUserName);
			}catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			return SecAnsUpdStatus;
		}else{
			SecAnsUpdStatus = new ArrayList<String>();
			SecAnsUpdStatus.add("Unauthorized Access");
			return SecAnsUpdStatus;
		}
	}

	@RequestMapping(value = "/ForgotPassowrd", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getForgotPassowrd(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {

		String strUserName="";
		String strAuthType="";

		strUserName = request.getParameter("username");
		strAuthType = request.getParameter("authtype");
		List<String> securityQuestList = null;

		if((strUserName != null && !("".equals(strUserName))) && (strAuthType != null && !("".equals(strAuthType))) && ("External".equals(strAuthType))){
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			loginDTO.setAuthType(strAuthType);
			loginDTO.setUserName(strUserName);
			securityQuestList = new ArrayList<String>();
			try{
				securityQuestList = loginTabsReports.getSecurityQuestions(loginDTO);
			}catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			return securityQuestList;
		}else{
			securityQuestList = new ArrayList<String>();
			securityQuestList.add("Unauthorized Access");
			return securityQuestList;
		}
	}

	@RequestMapping(value = "/SecurityQuestValidation", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> getSecQuesValidation(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {

		String secQuesArray = request.getParameter("secquesarray");
		String secAnswerArray = request.getParameter("secanswerarray");
		String strUserName = request.getParameter("username");

		List<String> secQuestValResult = null;

		if((secQuesArray != null && !("".equals(secQuesArray))) && (secAnswerArray != null && !("".equals(secAnswerArray)))){
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			secQuestValResult = new ArrayList<String>();
			loginDTO.setAllSecQuestions(secQuesArray);
			loginDTO.setAllSecAnswers(secAnswerArray);
			loginDTO.setUserName(strUserName);
			try{
				secQuestValResult = loginTabsReports.securityQuestAnsVal(loginDTO);
			}catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			return secQuestValResult;
		}else{
			secQuestValResult = new ArrayList<String>();
			secQuestValResult.add("Unauthorized Access");
			return secQuestValResult;
		}
	}

	@RequestMapping(value = "/PasswordReset", method = RequestMethod.POST ,produces="application/json" )
	@ResponseBody
	public List<String> setNewPassword(ModelMap model, HttpSession session, HttpServletRequest request,HttpServletResponse response) throws Exception {

		String strNewPassword = request.getParameter("strresetnewpwd");
		String strConfirmPassword = request.getParameter("strresetconfpwd");
		String strUserName = request.getParameter("username");

		List<String> setNewPwdResult = null ;

		if((strNewPassword != null && !("".equals(strNewPassword))) && (strConfirmPassword != null && !("".equals(strConfirmPassword))) && (strUserName != null && !("".equals(strUserName)))){
			LoginDetailDTO loginDTO = new LoginDetailDTO();
			setNewPwdResult = new ArrayList<String>();
			loginDTO.setNewPassword(strNewPassword);
			loginDTO.setNewConfirmPassword(strConfirmPassword);
			loginDTO.setUserName(strUserName);
			try{
				setNewPwdResult = loginTabsReports.newPasswordUpdate(loginDTO);
			}catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			return setNewPwdResult;
		}else{
			setNewPwdResult = new ArrayList<String>();
			setNewPwdResult.add("Unauthorized Access");
			return setNewPwdResult;
		}
	}
}