package com.htc.authentication.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import javax.naming.NamingException;
import org.springframework.stereotype.Repository;
import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.utility.DashboardConstants;
import com.htc.utility.StoredProcedureConstants;

@Repository
public class LoginDetailDAO {


	private DataSource datasource;


	public void setDataSource(DataSource dataSource) {
		this.datasource = dataSource;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getTabsForUser(LoginDetailDTO loginDTO) throws SQLException, NamingException {
		// TODO Auto-generated method stub
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet  resultSet = null;
		String query="";
		List<String> tabsListGroup=new ArrayList<String>();
		List<String> tabsListImagePath=new ArrayList<String>();
		List<String> tabsListIcon=new ArrayList<String>();
		List  tabsList=new ArrayList();
		try {
			connection = datasource.getConnection();
			query = StoredProcedureConstants.sp_Get_Report_Group_Names;
			statement = connection.prepareCall(query);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				tabsListGroup.add(resultSet.getString("SDM_rpt_grp_name"));
				tabsListImagePath.add(resultSet.getString("SDM_rpt_grp_img_path"));
				tabsListIcon.add(resultSet.getString("SDM_rpt_grp_icon_colors"));
			}
			tabsList.add(tabsListGroup);
			tabsList.add(tabsListImagePath);
			tabsList.add(tabsListIcon);
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tabsList;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map getReportsForUser(LoginDetailDTO loginDTO) throws SQLException, NamingException {
		// TODO Auto-generated method stub
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String query="";
		List<String> groupList=new ArrayList<String>();
		List reportList=new ArrayList();
		Map tabMap=new HashMap();
		try {
			connection = datasource.getConnection();
			query = StoredProcedureConstants.sp_Get_Tabs_List_ForGroupsUsers;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, loginDTO.getUserName());
			callableStatement.setString(2, loginDTO.getAuthType());
			callableStatement.setString(3, loginDTO.getGroup());

			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				groupList.add(resultSet.getString("Group Name"));
				groupList.add(resultSet.getString("Dashboard_Name"));
				groupList.add(resultSet.getString("Report URL"));
				groupList.add(resultSet.getString("Group Image"));
				reportList.add(groupList);
				groupList=new ArrayList<String>();
			}
			tabMap.put(DashboardConstants.USER_REPORTS, reportList);

		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tabMap;
	}

	public List<String> getExternalUser(LoginDetailDTO loginDTO) throws SQLException, NamingException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String query = "";
		List<String> validUser= new ArrayList<String>();
		try {
			connection = datasource.getConnection();
			query = StoredProcedureConstants.sp_User_Authentication_With_Security_Question;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, loginDTO.getUserName());
			callableStatement.setString(2, loginDTO.getPassword());
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				validUser.add(resultSet.getString(1));
				validUser.add(resultSet.getString(2));
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return validUser;
	}

	/*
	 * This method is used for getting security questions for new user. This method will take
	 * one arguments i.e. LoginDetailDTO object. This method will return list type value i.e.
	 * securityQuestions.
	 */
	public List<String> getSecQuesForNewUser(LoginDetailDTO loginDTO) throws SQLException,NamingException{

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String securtyQuesQuery = "";
		List<String> securityQuestions = new ArrayList<String>();

		try {
			connection = datasource.getConnection();
			securtyQuesQuery = StoredProcedureConstants.sp_get_Security_Question_For_Login;
			callableStatement = connection.prepareCall(securtyQuesQuery);
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				securityQuestions.add(resultSet.getString(2)) ;
			}
		}finally{
			try {
				if (null != resultSet)
					resultSet.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return securityQuestions;
	}

	/*
	 * This method is used for setting security answer for new user. This method will take
	 * one arguments i.e. LoginDetailDTO object. This method will return list type value i.e.
	 * SecQuestUpdStatus.
	 */
	public List<String> setSecAnsForNewUser(LoginDetailDTO loginDTO,String strTempUserName) throws SQLException,NamingException{

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String secAnsUpdateQuery = "";
		List<String> SecQuestUpdStatus = new ArrayList<String>();
		try {
			connection = datasource.getConnection();
			secAnsUpdateQuery = StoredProcedureConstants.sp_Assign_User_Security_Question;
			callableStatement = connection.prepareCall(secAnsUpdateQuery);
			callableStatement.setString(1, strTempUserName);
			callableStatement.setString(2, loginDTO.getAllSecQuestions());
			callableStatement.setString(3, loginDTO.getAllSecAnswers());
			callableStatement.setString(4, strTempUserName);
			resultSet = callableStatement.executeQuery();
			while(resultSet.next()){
				SecQuestUpdStatus.add(resultSet.getString(1));
				SecQuestUpdStatus.add(resultSet.getString(2));
			}
		}finally{
			try {
				if (null != resultSet)
					resultSet.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return SecQuestUpdStatus;
	}

	/*
	 * This method is used for getting security questions for existing user at change password time.
	 * and also checking user is a valid user or not before getting security question.
	 * This method will take one arguments i.e. LoginDetailDTO object. This method will return 
	 * list type value i.e. securityQuestions.
	 */
	public List<String> getSecurityQuestions(LoginDetailDTO loginDTO) throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement,callableStatement1;
		callableStatement=callableStatement1= null;
		ResultSet resultSet,resultSet1;
		resultSet = resultSet1= null;

		String userExistQuery,securtyQuesQuery;
		userExistQuery = securtyQuesQuery = "";
		String resultKey = "";
		String resultValue = "";
		List<String> securityQuestions = new ArrayList<String>();

		try {
			connection = datasource.getConnection();
			userExistQuery = StoredProcedureConstants.sp_Check_User_Availability;
			callableStatement = connection.prepareCall(userExistQuery);
			callableStatement.setString(1, loginDTO.getUserName());
			callableStatement.setString(2, loginDTO.getAuthType());
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				resultKey = resultSet.getString(1);
				resultValue = resultSet.getString(2);
				securityQuestions.add(resultKey);
				securityQuestions.add(resultValue);
			}

			if("0".equals(resultKey)){
				securtyQuesQuery = StoredProcedureConstants.sp_Get_Security_Question;
				callableStatement1 = connection.prepareCall(securtyQuesQuery);
				callableStatement1.setString(1, loginDTO.getUserName());
				callableStatement1.setString(2, loginDTO.getAuthType());
				resultSet1 = callableStatement1.executeQuery();
				securityQuestions.clear();
				while(resultSet1.next()){
					securityQuestions.add(resultSet1.getString(2)) ;
				}
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement1)
					callableStatement1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return securityQuestions;
	}

	/*
	 * This method is used for validating security answers against security questions. This method will take
	 * one arguments i.e. LoginDetailDTO object. This method will return list type value i.e.
	 * secuQuestAnsVal.
	 */	
	public List<String> securityQuestAnsVal(LoginDetailDTO loginDTO) throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement= null;
		ResultSet resultSet = null;

		String secQstAnsValQuery = "";
		String resultKey = "";
		String resultValue = "";
		List<String> secuQuestAnsVal = new ArrayList<String>();

		try {
			connection = datasource.getConnection();
			secQstAnsValQuery = StoredProcedureConstants.sp_Validate_User_Security_Answer;
			callableStatement = connection.prepareCall(secQstAnsValQuery);
			callableStatement.setString(1, loginDTO.getUserName());
			callableStatement.setString(2, loginDTO.getAllSecQuestions());
			callableStatement.setString(3, loginDTO.getAllSecAnswers());
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				resultKey = resultSet.getString(1);
				resultValue = resultSet.getString(2);
				secuQuestAnsVal.add(resultKey);
				secuQuestAnsVal.add(resultValue);
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return secuQuestAnsVal;
	}


	/*
	 * This method is used for updating new password. This method will take one arguments i.e.
	 * LoginDetailDTO object. This method will return list type value i.e.
	 * newPasswordUpdStatus.
	 */
	public List<String> newPasswordUpdate(LoginDetailDTO loginDTO) throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement= null;
		ResultSet resultSet = null;

		String newPwdUpdateQuery = "";
		String resultKey = "";
		String resultValue = "";
		List<String> newPasswordUpdStatus = new ArrayList<String>();
		try {
			connection = datasource.getConnection();
			newPwdUpdateQuery = StoredProcedureConstants.sp_Insert_Password;
			callableStatement = connection.prepareCall(newPwdUpdateQuery);
			callableStatement.setString(1, loginDTO.getUserName());
			callableStatement.setString(2, loginDTO.getNewPassword());
			callableStatement.setString(3, loginDTO.getNewConfirmPassword());
			resultSet = callableStatement.executeQuery();

			while(resultSet.next()){
				resultKey = resultSet.getString(1);
				resultValue = resultSet.getString(2);
				newPasswordUpdStatus.add(resultKey);
				newPasswordUpdStatus.add(resultValue);
			}
		}finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return newPasswordUpdStatus;
	}
	
	
}
