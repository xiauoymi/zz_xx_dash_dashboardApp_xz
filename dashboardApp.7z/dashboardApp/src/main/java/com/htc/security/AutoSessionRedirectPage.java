package com.htc.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.htc.utility.DashboardConstants;

public class AutoSessionRedirectPage extends HandlerInterceptorAdapter {
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		String reuestURI = request.getRequestURI();
		if (!(reuestURI.endsWith("/ctmetrics/") || reuestURI.endsWith("/login"))) {
			if (request.getSession().getAttribute(DashboardConstants.SESSION_STATUS_NAME) == null) {
				
				String ajaxHeader = ((HttpServletRequest) request).getHeader("X-Requested-With");
		        boolean isAjax = "XMLHttpRequest".equals(ajaxHeader);
		        if (isAjax) {
		            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Ajax REquest Denied (Session Expired)");
		            
		        } 
		        else{
				response.sendRedirect("?"+DashboardConstants.SESSION_EXPIRE_NAME+"="+DashboardConstants.SESSION_EXPIRE_VAL);
				
		        }
		        
		    	return false;
				
			}
		}
		return true;
	}
}