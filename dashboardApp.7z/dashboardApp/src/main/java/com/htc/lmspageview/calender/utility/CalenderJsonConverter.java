package com.htc.lmspageview.calender.utility;

import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.htc.lmspageview.calender.dto.CalenderLeaveStatusDTO;

import static com.htc.utility.DashboardConstants.DAYS;
import static com.htc.utility.DashboardConstants.HOURS;
import static com.htc.utility.DashboardConstants.PTO;

public class CalenderJsonConverter {
	private static final Logger logger = Logger.getLogger(CalenderJsonConverter.class);

	@SuppressWarnings({ "unchecked"})
	public static String  getJsonList(List<CalenderLeaveStatusDTO> calenderLeaveStatusDTOList) {

		JSONObject obj = null;
		JSONArray jsonArrayList = null;
		StringBuffer tempStr = null;
		jsonArrayList = new JSONArray();
		List<CalenderLeaveStatusDTO> uniqueList = calenderLeaveStatusDTOList;
		logger.info("uniqueList :: "+uniqueList.size());

		if(uniqueList.size() > 0) {
			for (CalenderLeaveStatusDTO calenderLeaveStatusDTORef :  uniqueList) {
				obj = new JSONObject();
				if(calenderLeaveStatusDTORef.getTitle().equals(PTO))  {
					if(calenderLeaveStatusDTORef.getHoursDays() != null) {
						if (calenderLeaveStatusDTORef.getHoursDays().equals(DAYS)) {
							obj.put("title", PTO);	
							tempStr   = new StringBuffer();
							tempStr.append(calenderLeaveStatusDTORef.getStart()).append("T10:00:00");
							obj.put("start", tempStr.toString());

							tempStr   = new StringBuffer();
							tempStr.append(calenderLeaveStatusDTORef.getEnd()).append("T18:00:00");
							obj.put("end", tempStr.toString());

						} else if (calenderLeaveStatusDTORef.getHoursDays().equals(HOURS)) { 
							tempStr   = new StringBuffer();

							tempStr.append(calenderLeaveStatusDTORef.getTitle()).append(" ")
							.append(calenderLeaveStatusDTORef.getStartDayTime())
							.append(" - ")					 
							.append(calenderLeaveStatusDTORef.getEndDayTime()); 					 
							obj.put("title", tempStr.toString());		
							obj.put("start", calenderLeaveStatusDTORef.getStart());
							obj.put("end", calenderLeaveStatusDTORef.getEnd());
						}				

					}
				}
				else{
					tempStr   = new StringBuffer();

					if(null!=calenderLeaveStatusDTORef.getTitle())
					{
						tempStr.append(calenderLeaveStatusDTORef.getTitle()).append(" ")
						.append(calenderLeaveStatusDTORef.getStartDayTime())
						.append(" - ")					 
						.append(calenderLeaveStatusDTORef.getEndDayTime()); 	
						obj.put("title", tempStr.toString());	
					}
					obj.put("start", calenderLeaveStatusDTORef.getStart());
					obj.put("end", calenderLeaveStatusDTORef.getEnd());
				}

				obj.put("color", calenderLeaveStatusDTORef.getColor());
				jsonArrayList.add(obj);
			}
		} else {
			return null;
		}
		String jsonList = 	jsonArrayList.toJSONString();
		return jsonList;
	}
}
