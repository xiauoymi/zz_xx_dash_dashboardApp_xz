package com.htc.lmspageview.calender.dao.impl;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.htc.lmspageview.calender.dto.CalenderLeaveStatusRowMapper;

import static com.htc.utility.DashboardConstants.RESULT_SET;
import static com.htc.utility.DashboardConstants.AGENT_ID;
import static com.htc.utility.DashboardConstants.GET_CALENDAR;

public class CalenderStoredProcedure extends StoredProcedure  {

	@SuppressWarnings("rawtypes")
	public CalenderStoredProcedure(JdbcTemplate jdbcTemplate) {
		super(jdbcTemplate, GET_CALENDAR);

		RowMapper rowMapper = new CalenderLeaveStatusRowMapper();

		declareParameter(new SqlReturnResultSet(RESULT_SET,
				rowMapper));

		declareParameter(new SqlParameter(AGENT_ID, Types.VARCHAR));

		// now compile stored proc
		compile();

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map getCalendar(String agentID) {

		// set the input params
		Map inParameters = new HashMap();
		inParameters.put(AGENT_ID, agentID);
		// now execute
		Map out = execute(inParameters); // Call on parent class

		return out;
	}

}
