package com.htc.lmspageview.calender.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

@SuppressWarnings("rawtypes")
public class CalenderLeaveStatusRowMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int index) throws SQLException {
		CalenderLeaveStatusDTO calenderLeaveStatusDTO = null;
		calenderLeaveStatusDTO = new CalenderLeaveStatusDTO();
		calenderLeaveStatusDTO.setStart(rs.getString(2));
		calenderLeaveStatusDTO.setEnd(rs.getString(3));		
		calenderLeaveStatusDTO.setStartDayTime(rs.getString(4));
		calenderLeaveStatusDTO.setEndDayTime(rs.getString(5));		
		calenderLeaveStatusDTO.setTitle(rs.getString(7));
		calenderLeaveStatusDTO.setColor(rs.getString(8));
		calenderLeaveStatusDTO.isAllDay();
		calenderLeaveStatusDTO.setHoursDays(rs.getString(9));
		return calenderLeaveStatusDTO;
	}

}
