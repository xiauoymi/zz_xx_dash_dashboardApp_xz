package com.htc.lmspageview.calender.dto;

public class CalenderLeaveStatusDTO {

	private String  start;
	private String  end;
	private String  startDayTime;
	private String  endDayTime;
	private String  title;
	private String  color;
	private String  hoursDays;
	private boolean  allDay; 
	public boolean isAllDay() {
		return false;
	}

	public void setAllDay(boolean allDay) {
		this.allDay = allDay;
	}
	public String getStartDayTime() {
		return startDayTime;
	}
	public void setStartDayTime(String startDayTime) {
		this.startDayTime = startDayTime;
	}
	public String getEndDayTime() {
		return endDayTime;
	}
	public void setEndDayTime(String endDayTime) {
		this.endDayTime = endDayTime;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}

	public String getHoursDays() {
		return hoursDays;
	}

	public void setHoursDays(String hoursDays) {
		this.hoursDays = hoursDays;
	}

	@Override
	public String toString() {
		return "CalenderLeaveStatusDTO [start=" + start + ", end=" + end + ", startDayTime=" + startDayTime
				+ ", endDayTime=" + endDayTime + ", title=" + title + ", color=" + color + ", hoursDays=" + hoursDays
				+ ", allDay=" + allDay + "]";
	}

}
