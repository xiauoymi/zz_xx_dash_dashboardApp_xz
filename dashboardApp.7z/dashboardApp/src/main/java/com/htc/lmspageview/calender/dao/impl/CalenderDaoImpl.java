package com.htc.lmspageview.calender.dao.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.jdbc.core.JdbcTemplate;

import com.htc.lmspageview.calender.dao.CalenderDao;
import com.htc.lmspageview.calender.dto.CalenderLeaveStatusDTO;

import static com.htc.utility.DashboardConstants.RESULT_SET;
import static com.htc.utility.DashboardConstants.AGENT_ID;


public class CalenderDaoImpl implements CalenderDao {


	private JdbcTemplate jdbcTemplate;

	private CalenderStoredProcedure calenderStoredProcedure;

	public CalenderDaoImpl() {
	}


	public CalenderStoredProcedure getCalenderStoredProcedure() {
		return calenderStoredProcedure;
	}

	public void setCalenderStoredProcedure(CalenderStoredProcedure calenderStoredProcedure) {
		this.calenderStoredProcedure = calenderStoredProcedure;
	}


	@PostConstruct
	public void postConstruct() {
		calenderStoredProcedure = new CalenderStoredProcedure(jdbcTemplate);
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<CalenderLeaveStatusDTO> getLeaveStatus(String employmentNumber) {

		List<CalenderLeaveStatusDTO> result = null;

		// Call the stored procedure;
		Map data = calenderStoredProcedure.getCalendar(employmentNumber);

		// retrieve the list of objects
		result = (List<CalenderLeaveStatusDTO>) data.get(RESULT_SET);

		return result;
	}


}
