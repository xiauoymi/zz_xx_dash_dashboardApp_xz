package com.htc.lmspageview.calender.dao;

import java.util.List;

import com.htc.lmspageview.calender.dto.CalenderLeaveStatusDTO;

public interface CalenderDao {

	List<CalenderLeaveStatusDTO> getLeaveStatus(String employmentNumber);

}
