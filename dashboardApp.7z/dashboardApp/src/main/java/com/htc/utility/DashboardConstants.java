package com.htc.utility;

import jdk.nashorn.internal.runtime.Timing;

public class DashboardConstants {

	
	public static String HEADER = "<span>CT</span><span>M</span>etrics";
	public static String REPORTS = "Reports";
	public static String REPORTSDESCRIPTION = "ReportsDescription";

	public static String COMBINEDSDDT = "CombinedServiceDeskDataTable";
	public static String COMBINEDSDDTMAP = "CombinedServiceDeskDataTableMap";
	public static String COMBINEDSDDTABLECOLUMNS = "CombinedServiceDeskDataTablecolumn";

	public static String MTDPQT = "MTDPQTable";
	public static String MTDPQTMAP = "MTDPQTableMap";
	public static String MTDPQTABLECOLUMNS = "MTDPQTablecolumn";

	public static String HIOCT = "HIOCTable";
	public static String HIOCTMAP = "HIOCTableMap";
	public static String HIOCTABLECOLUMNS = "HIOCTablecolumn";

	public static String EXECUTIVE_GROUPORG = "ExeGroupOrg";

	public static String EXE_GROUP_LIST = "groupList";
	public static String SESSION_STATUS_VAL = "Active";
	public static String SESSION_STATUS_NAME = "SessionActiveStatus";
	public static String SESSION_EXPIRE_VAL = "Session Expired";
	public static String SESSION_EXPIRE_NAME = "SessionExpMsg";
	public static String WARNING_MESSAGE = "WarnedMsg";
	public static String WARNING_AJAX_MESSAGE = "WarnedAjaxMsg";
	public static String WARNING_MESSAGE_INVALID = "Please enter a valid User-ID and Password.";
	public static String LDAP_WARNING_MESSAGE_INVALID = "Password mismatch in Remedy. Please reset the Password.";
	public static String WARNING_MESSAGE_LOGOUT = "Successfully Logged Out";

	public static String HAEDING_MSG_NAME = "<span>H</span>eadingValue";
	public static String HAEDING_MSG_CSDDMETRICS = "<span>C</span>ombined <span>S</span>ervice <span>D</span>esk <span>D</span>ata <span>M</span>etrics";
	public static String HAEDING_MSG_PRACTIVITY = "<span>P</span>rovisioning <span>A</span>ctive <span>T</span>ickets";
	public static String HAEDING_MSG_PROBLEM_TICKET_ACTIVITY = "<span>P</span>roblem <span>T</span>icket <span>D</span>etails";
	public static String HAEDING_MSG_HIOCRECENTACT = "<span>P</span>ulse <span>A</span>ctive/<span>R</span>ecently <span>R</span>esolved <span>T</span>ickets";
	public static String HAEDING_MSG_TCYEARLY = "<span>T</span>otal <span>C</span>ontacts <span>Y</span>early";
	public static String HAEDING_MSG_TCBYAPPCLIENT = "<span>T</span>otal <span>C</span>ontacts <span>B</span>y <span>A</span>pplication <span>C</span>lient";
	public static String HAEDING_MSG_TCTABLES = "<span>T</span>otal <span>C</span>ontacts <span>T</span>ables";
	public static String HAEDING_MSG_MTDSERVDESK = "<span>M</span>y<span>D</span>ata<span>D</span>ashboard";
	public static String HAEDING_MSG_AGENTDESKDISPLAY = "<span>A</span>gent <span>D</span>esktop <span>D</span>isplay";
	public static String HAEDING_MSG_ADMIN = "<span>A</span>dmin";
	public static String HAEDING_MSG_ORG_MGMT = "<span>O</span>rganization <span>M</span>anagement";
	public static String HAEDING_MSG_OFFERINGS_MGMT = "<span>O</span>fferings <span>M</span>anagement";
	public static String HAEDING_MSG_METRICS_MGMT = "<span>M</span>etrics <span>M</span>anagement";
	public static String HAEDING_MSG_USER_CONFIG = "<span>U</span>ser <span>C</span>onfiguration";
	public static String AGENTDESKDISPALYMAP = "AgentDeskDispalyTableMap";
	public static String AGENTDESKDESKTABLECOLNAME = "AgentDeskDispTableColName";
	public static String AGENTDESKDESKTABLECOLVAL = "AgentDeskDispTableColVal";
	public static String SDCALLDISPLAYMAP = "SDCallDisplayTableMap";
	public static String HAEDING_MSG_SDCALLDISPLAY = "<span>S</span>D <span>C</span>all <span>D</span>isplay";
	public static String SDCALLDISPLAYCOLNAME = "SDCallDisplayTableColName";
	public static String SDCALLDISPLAYCOLVAL = "SDCallDisplayTableColVal";

	public static String CTSSDCUSTOMER_VIEW = "<span>C</span>TS <span>S</span>ervice <span>D</span>esk <span>C</span>ustomer <span>V</span>iew";
	public static String CTSSDCUSTOMER_VIEW_TREE_SELECT = "CTS tree select";

	public static String SUBSCRIPTION = "<span>S</span>ubscrition";

	public static String PULSEALL = "<span>P</span>ulse <span>T</span>ickets/<span>E</span>mails";
	public static String PULSEALLDAY = "<span>P</span>ulse <span>T</span>ickets/<span>E</span>mails <span>B</span>y <span>C</span>lient";
	public static String PULSEALL_SINGLECLIENT = "<span>P</span>ulse <span>A</span>ll <span>A</span>lerts <span>F</span>or <span>S</span>ingle <span>C</span>lient";
	public static String PROVISIONDISPLAYBOARD = "<span>P</span>rovisioning <span>D</span>isplay <span>B</span>oard";

	public static final String REMOVED_LABEL_NAME = "CTS_CLIENT_";

	public static final String TODAY = "TODAY";
	public static final String CURRENT_MONTH = "CURRENTMONTH";
	public static final String PREVIOUS_MONTH = "PREVIOUSMONTH";
	public static final String TYPE_CREATED = "CREATED";
	public static final String TYPE_RESOLVED = "RESOLVED";
	public static final String TYPE_ACTIVE = "ACTIVE";

	public static String PULSEALL_EmailAlerts = "EmailAlerts";
	public static String PULSEALL_CTS_Assigned = "CTS_Assigned";
	public static String PULSEALL_External_Assigned = "External_Assigned";
	public static String PULSEALL_Assigned_Individual = "Assigned_Individual";
	public static String PULSEALL_HOURS = "Hours";
	public static String PULSEALL_Create_Date = "Create_Date";
	public static String PULSEALL_RemedyID = "RemedyID";
	public static String PULSEALL_Minutes = "Minutes";

	public static String USER_TABS = "tabs";
	public static String USER_REPORTS = "userreports";
	public static String USER_URLS = "userurls";

	public static String USER_REPORT_MAP = "usertabdata";

	public static String CAPTCHA = "CAPTCHA";
	public static String WARNING_MESSAGE_CAPTCHA = "Invalid Captcha";
	public static String CAPTCHASALTCHAR = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

	public static String GROUP_IDS = "RemedyOrgIds";
	public static String GROUP_NAMES = "GroupNames";

	public static String datePicker = "datePicker";
	public static String pulseYear = "pulseYear";
	public static String username = "username";
	public static String ClientName = "ClientName";

	public static String NYHHCOLUMNNAMES = "columnNames";
	public static String NYHHCOLUMNVALUES = "columnValues";
	public static String NYHHQUERYPARAM = "nyhh";
	public static String OAKWOODSESSIONMAP = "oakwood";
	public static String OAKWOODPARAM = "Oakwood";
	public static String NYHHSESSIONMAP = "nyhmap";
	public static String JSMC = "jcmc";
	public static String RWJBH = "RWJBH";

	public static String HAEDING_MSG_NYHHTITLE = "<span>N</span>YHH  <span>R</span>eal <span>T</span>ime <span>D</span>isplay";
	public static String HAEDING_MSG_OakwoodTITLE = "<span>O</span>akwood <span>H</span>ealthline <span>R</span>eal <span>T</span>ime <span>D</span>isplay";
	public static String HAEDING_MSG_JCMC_TITLE = "<span>J</span>CMC <span>H</span>ealthline <span>R</span>eal <span>T</span>ime <span>D</span>isplay";
	public static String HAEDING_MSG_RWJ_TITLE = "<span>R</span>WJBH <span>H</span>ealthline <span>R</span>eal <span>T</span>ime <span>D</span>isplay";
	public static String HEAD_NYHHOakwood = "headdecide";
	public static String SPACE = "-";

	public static String DASHBOARD_AUTH_TYPE_REMEDY = "Remedy";
	public static String DASHBOARD_AUTH_TYPE_EXTERNAL = "External";

	public static String YES = "yes";
	public static String NO = "no";

	public static String Heading_csdDisplayBoard = "<span>C</span>SD <span>D</span>ISPLAY <span>B</span>OARD";
	public static String Heading_csdAgentDisplayBoard = "<span>C</span>SD <span>A</span>gent <span>D</span>ISPLAY <span>B</span>OARD";

	public static String RULE_TYPES = "RuleTypes";
	public static String REMEDY_USER = "RemedyUser";
	public static String EXTERNAL_USER = "ExternalUser";
	public static String VIEW_USER_GROUP_NAME = "ViewUserGroup";
	public static String TYPEDROPDOWN = "TypeDropDown";
	public static String TYPEDROPDOWNVALUE = "TypeDropDownValue";
	public static String STATUSDROPDOWN = "StatusDropDown";
	public static String STATUSDROPDOWNVALUE = "StatusDropDownValue";
	public static String JSTREE = "jstree";
	public static String JSTREEMAP = "jstreeMap";
	public static String OFFERTYPEDROPDOWN = "offerTypeDropDown";
	public static String OFFERTYPEDROPDOWNVALUE = "offerTypeDropDownValue";
	public static String OFFERSTATUSDROPDOWN = "offerStatusDropDown";
	public static String OFFERSTATUSDROPDOWNVALUE = "offerStatusDropDownValue";
	public static String OFFERTYPEANDSTATUS = "offerTypeAndStatus";

	public static String EXTERNAL_GROUP_NAMES = "ExternalGroupNames";
	public static String EXTERNAL_USER_DETAILS = "ExternalUserDetails";
	public static String EXTERNAL_NEW_USER_RESULT = "ResultMessage";
	public static String SINGLE_USER_DETAIL = "SingleUserDetail";

	public static String METRICTYPEDROPDOWN = "metricTypeDropDown";
	public static String METRICTYPEDROPDOWNVALUE = "metricTypeDropDownValue";
	public static String METRICSTATUSDROPDOWN = "metricStatusDropDown";
	public static String METRICSTATUSDROPDOWNVALUE = "metricStatusDropDownValue";
	public static String METRICGROUPTYPEDROPDOWN = "metricGroupTypeDropDown";
	public static String METRICGROUPTYPEDROPDOWNVALUE = "metricGroupTypeDropDownValue";
	public static String METRICGROUPSTATUSDROPDOWN = "metricGroupStatusDropDown";
	public static String METRICGROUPSTATUSDROPDOWNVALUE = "metricGroupStatusDropDownValue";
	public static String MCATVALUES = "mcatValue";
	public static String MCATTEXT = "mcatText";
	public static String MBYIDANDMCATBYID = "metricIDAndmcatID";

	public static String AUTHENTICATIONERRORMSG = "Unauthorized access. Please contact administrator.";
	public static String AUTHENTICATIONRIGHTS = "authenticationrights";

	public static String MONITORJOBSNAMES = "monitorjobscolumnnames";
	public static String MONITORJOBSVALUES = "monitorjobscolumnvales";
	public static String HAEDING_MSG_MONITORETLJOB = "<span>M</span>onitor ETL Jobs";

	public static String MONTHENDNAMES = "monthendcolumnnames";
	public static String MONTHENDVALUES = "monthendcolumnvalues";
	public static String MONTHENDREPORTMAP = "monthendreportmap";

	public static String MONTHENDVERIFICATIONREPORTMAP = "monthendverificationreportmap";
	public static String MONTHENDVERIFICATIONREPORTNAMES = "monthendverificationreportnames";
	public static String MONTHENDVERIFICATIONREPORTVALUES = "monthendverificationreportvalues";
	public static String EMAILNO = "emailNo";
	public static String EMAILs = "emails";

	public static String SDMETRICSCOLUMNNAME = "sdmetricscolumnname";
	public static String SDMETRICSCOLUMNVALUE = "sdmetricscolumnvalue";
	public static String SDMETRICGETMAILDETAILS = "sdmetricgetmaildetails";
	public static String SUBJECT = "subject";
	public static String SDMETRICSAAATABLECOLUMNNAME = "sdmetricsaaacolumnname";
	public static String SDMETRICSAAATABLECOLUMNVALUE = "sdmetricsaaacolumnvalue";
	public static String SDMETRICSNOTSENTREPORTCOLUMNNAME = "sdmetricsnotsentreportcolumnname";
	public static String SDMETRICSNOTSENTREPORTCOLUMNVALUE = "sdmetricsnotsentreportcolumnvalue";
	public static String SDMETRICSREPORTCOUNTCOLUMNVALUE = "sdmetricsreportcountcolumnvalue";

	public static String MONITORINGNAMES = "monitoringNames";
	public static String MONITORINGVALUES = "monitoringValues";

	public static String JOBSCHEDULEDNAMES = "jobScheduledNames";
	public static String JOBSCHEDULEDVALUES = "jobScheduledValues";

	// Showing Exception Message Start
	public static String INVALID_EMAIL_EXCEPTION = "Access denied due to invalid email address or attachments";
	public static String SQL_EXCEPTION = "Problem in data base";
	public static String FILE_NOT_FOUND_EXCEPTION = "File not available in particular directory";
	// Showing Exception Message End

	public static String ROLLUP_CLIENT_DATA = "ROLLUP_CLIENT_DATA";
	public static String ROLLUP_FILENAME = "ROLLUP_FILENAME";

	public static String CRYSTALREPORTDETAIL = "crystalReportColumnValues";
	public static String CRYSTALREPORTCLIENTLIST = "clientList";

	public static String CT_REPORTING_EMAIL = "reportingEmail";


	public static String CLIENT_EMAIL_LIST = "clientEmailList";
	public static String CLIENT_EMAIL_SUBJECT_LIST = "clientEmailSubjectList";

	//Executive dashboards jsp page constants
	public static String Ente_From_Date= "Enter From Date.";
	public static String Enter_To_Date= "Enter To Date."; 
	public static String Year_should_be_greaterthan_1999= "Year should be greaterthan 1999."; 
	public static String Invalid_date_format= "Invalid date format."; 
	public static String To_Date_should_be_grater_than_From_Date= "To Date should be grater than From Date."; 
	public static String Please_enter_From_Date= "Please enter From Date.";  
	public static String Please_enter_To_Date= "Please enter To Date."; 
	public static String Please_select_priority= "Please select priority.";
	public static String Please_select_status= "Please select status."; 
	public static String Please_select_SLA= "Please select SLA."; 
	public static String NoGroupsavailable= "'No Groups available. Please contact your administrator to Create a Group.'";
	public static String Please_select_group_and_click_on_search= "'Please select group and click on search.'"; 
	//LMS
	public static String LEAVEBALANCEFIELDNAMEs = "leaveBalanceFieldNames";
	public static String LEAVEBALANCEFIELDVALUES = "leaveBalanceFieldValues";
	public static String LEAVEHISTORYFIELDNAMEs = "leaveHistoryFieldNames";
	public static String LEAVEHISTORYFIELDVALUES = "leaveHistoryFieldValues";
	public static String lEAVEHISTORYTABLEMAP= "leaveHistoryTableDetailMap";
	public static String lEAVEBALANCETABLEMAP= "leaveBalanceTableDetailMap";
	public static String LEAVEPROJECTIONMAP="leaveprojectionmap";

	public static String LEAVE_STATUS_JSON_STRING= "leaveStatusJSON";
	public static final String RESULT_SET = "RESULT_SET";
	public static final String AGENT_ID = "AgentID";
	public static final String GET_CALENDAR = "getCalendar"; 
	public static final String MANAGERAPPROVETREE ="mangerapprovetree";
	public static String AGENTTIMESHEETCOLUMNNAME= "agentTimesheetColumns";
	public static String AGENTTIMESHEETVALUES= "agentTimesheetValues";
	public static String FULLCAL= "fullCalander";
	public static String AGENTLOGINSTATCOLUMNNAME= "agentLoginStatColumnName";
	public static String AGENTLOGINSTATCOLUMNVALUE= "agentLoginStatColumnValue";
	public static final String LMS_INVITE_SUPERVISOR = "supervisorMap";
	public static final String LMS_INVITE_RECORDS = "records";
	
	public static final String AGENTMODIFIEDCOLUMNNAME = "agentModifiedColumnNames";
	public static final String LMS_AGENTS = "agentsForSupervisor";
	public static final String LMS_SELECTED_AGENTS = "selectedAgentsForSupervisor";
	public static String AGENTMODIFIEDCOLUMNVALUE= "agentModifiedColumnValue";
	
	public static final String RECORD_FOR_LOAD_INVITE_SCREEN = "recordForLoadInviteScreen";
	
	public static String MEETING= "Meeting";
	public static String TRAINING= "Training";
	
	public static String APPROVED= "Approved";
	public static String AWAITING_APPROVAL= "Awaiting Approval";

	public static final String DAYS = "Days";
	public static final String HOURS = "Hours";
	public static final String PTO = "PTO";
	public static final String getPeoplesoftCode = "getPeoplesoftCode";
	public static final String psoftColumnNames = "psoftColumnNAmes";
	public static final String psoftColumnValues = "psoftColumnValues";
	public static final String COLUMN_NAMES = "columnNames";
	public static final String COLUMN_VALUES = "columnValues";
	public static String AGENTACTIVITYCOLUMNNAME= "agentActivityColumns";
	public static String AGENTACTIVTYVALUES= "agentActivityValues";
	
	public static String AgentAvayaActivities= "agentAvayaActivities";
	public static String AgentShiftData= "agentShiftActivities";
	public static String AgentLoginActivities= "agentLoginActivities";
	public static String AgentScheduleActivities= "agentScheduleActivities";
	
	public static String PROJECTIONEFIELDNAMEs = "projectionFieldNames";
	public static String PROJECTIONFIELDVALUES = "projectionFieldValues";
	public static String No_Records_Found= "'No Records Found'";
	
	public static String AGENTID= "agent_id";
	public static String ROLE= "Role";
	public static String TELEOPTI_USER_ID= "userid";
	
	public static String OVERTIMEEXCETIONLIST="overTimeExceptionList";
}
