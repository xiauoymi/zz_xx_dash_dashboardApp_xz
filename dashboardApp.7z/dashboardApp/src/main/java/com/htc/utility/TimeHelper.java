package com.htc.utility;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ibm.icu.text.SimpleDateFormat;

public class TimeHelper {

	private static final String SPLITTER="-";
	private static final String SPACE=" ";
	private static final String HOURLY="Hourly";
	private static final String DAILY="Daily";
	private static final String WEEKLY="Weekly";
	private static final String MONTHLY="Monthly";
	
	public static List<List<String>>  convertTo24Hrs(String timeLists,String typeOfScheduler) {
		List<List<String>> finalResultList= new ArrayList<>();
		
		List<String> finalTimeList = new ArrayList<>();
		
		String[] timeTokens = timeLists.split(SPLITTER);
		
		
		List<String> timeList = null;
		List<String> apList = null;
		List<String> dayList = null;
		List<String> monthList = null;
		List<String> dateList  =null;
	
		
		if(typeOfScheduler.equalsIgnoreCase(DAILY)) {
			
			timeList=new ArrayList<>();
			apList = new ArrayList<>();
			
			for(int i=0;i<timeTokens.length;i++) {
				String token = timeTokens[i];
				String[] tokens =token.split(SPACE); 
				   timeList.add(tokens[0].trim());
				   apList.add(tokens[1].trim());
			}
			
			for(int i=0;i<apList.size();i++) {
				String timeObject=timeList.get(i);
				String apObject  =apList.get(i);
				if(apObject.equalsIgnoreCase("PM")) {
					int tempTime = Integer.parseInt(timeObject)+12;
					timeObject = tempTime+"";
					finalTimeList.add(timeObject);
				}else {
					finalTimeList.add(timeObject);
				}
			}
			
			finalResultList.add(finalTimeList);
			
		}
		if(typeOfScheduler.equalsIgnoreCase(WEEKLY)) {
			timeList=new ArrayList<>();
			apList = new ArrayList<>();
			dayList =new ArrayList<>();
			
			for(int i=0;i<timeTokens.length;i++) {
				String token = timeTokens[i];
				String[] tokens =token.split(SPACE); 
				   dayList.add(tokens[0].trim());
				   timeList.add(tokens[1].trim());
				   apList.add(tokens[2].trim());
			}
			
			for(int i=0;i<apList.size();i++) {
				String timeObject=timeList.get(i);
				String apObject  =apList.get(i);
				
				if(apObject.equalsIgnoreCase("PM")) {
					int tempTime = Integer.parseInt(timeObject)+12;
					timeObject = tempTime+"";
					finalTimeList.add(timeObject);
				}else {
					finalTimeList.add(timeObject);
				}
			}
			finalResultList.add(finalTimeList);
			finalResultList.add(dayList);
		}
		if(typeOfScheduler.equalsIgnoreCase(MONTHLY)) {
			timeList=new ArrayList<>();
			apList = new ArrayList<>();
			dateList =new ArrayList<>();
			monthList = new ArrayList<>();
			
			
			for(int i=0;i<timeTokens.length;i++) {
				String token = timeTokens[i];
				String[] tokens =token.split(SPACE); 
				   dateList.add(tokens[0].trim());
				   monthList.add(tokens[1].trim());
				   timeList.add(tokens[2].trim());
				   apList.add(tokens[3].trim());
			}
			
			for(int i=0;i<apList.size();i++) {
				String timeObject=timeList.get(i);
				String apObject  =apList.get(i);
				
				if(apObject.equalsIgnoreCase("PM")) {
					int tempTime = Integer.parseInt(timeObject)+12;
					timeObject = tempTime+"";
					finalTimeList.add(timeObject);
				}else {
					finalTimeList.add(timeObject);
				}
			}
			finalResultList.add(finalTimeList);
			finalResultList.add(dateList);
			finalResultList.add(monthList);
			System.out.println(finalResultList);
		}
		if(typeOfScheduler.equalsIgnoreCase(HOURLY)){
			timeList = new ArrayList<>();
			String[] tokens = timeLists.split(SPACE); 
			timeList.add(tokens[0]);
			finalResultList.add(timeList);
		}
		return finalResultList;
		
		
	}
	
	
	public static java.sql.Date formatDate(String date) throws ParseException{
		java.sql.Date sDate =null;
		if(date!=null && date!=""){
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date parsedStart = format.parse(date);
		    sDate = new java.sql.Date(parsedStart.getTime());
		}
		return sDate;
	}
	
	
}
