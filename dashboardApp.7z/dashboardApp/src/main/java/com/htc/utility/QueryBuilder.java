package com.htc.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.htc.authentication.dto.LoginDetailDTO;
import com.htc.executive.dto.ExecutiveHomeDTO;

public class QueryBuilder {

	public static String getHIOCTableQuery() {

		StringBuffer hiocTableQuery = new StringBuffer();
		hiocTableQuery
				.append("DECLARE @fromw int, @tow int, @tmzone int, @DST int, @chartmzone varchar(8), @grp1 varchar(50), @grp2 varchar(50), @grp3 varchar(50), @grp4 varchar(50), @grp5 varchar(50), @grp6 varchar(50), @grp7 varchar(50),  @clnt varchar(50), @timeclnt varchar(50), @INCLCTS varchar(5)"
						+ " SET @clnt = 'CTS'"
						+ " SET @timeclnt=case when @clnt in ('allclients', 'allclientsplusweb') then 'CTS' else @clnt end"
						+ " SET @fromw = dbo.fn_WhereDatefrom('previousday', @timeclnt)"
						+ " SET @tow =  dbo.fn_WhereDateto('Today', @timeclnt)"
						+ " SET @tmzone = (SELECT replace(Timezone_offset,'-','') FROM CMN_CLientinfo with (nolock) WHERE client = @timeclnt)"
						+ " SET @DST = (SELECT DST FROM CMN_CLientinfo with (nolock) WHERE client = @timeclnt)"
						+ " ;WITH PULSEIndivList (Login_ID)"
						+ " AS (SELECT Login_ID FROM  CMN_Notification_Assignments with (nolock)"
						+ " WHERE group_name='CTS-NOC OPERATIONS'"
						+ " UNION SELECT 'CTS-VANCTS' UNION"
						+ " SELECT 'BVHA-VANTAGE' UNION"
						+ " SELECT 'CBHA-VANTAGE' UNION"
						+ " SELECT 'CHMC-VANTAGE' UNION"
						+ " SELECT 'CMMF-VANTAGE' UNION"
						+ " SELECT 'PHH-VANTAGE' UNION"
						+ " SELECT 'TCH-VANTAGE' UNION"
						+ " SELECT 'OAK-VANTAGE' UNION"
						+ " SELECT 'CHP-VANTAGE' UNION"
						+ " SELECT 'CTS-SOLARWINDS' UNION"
						+ " SELECT 'BVHA-SOLARWINDS' UNION"
						+ " SELECT 'CBHA-SOLARWINDS' UNION"
						+ " SELECT 'CHMC-SOLARWINDS' UNION"
						+ " SELECT 'CHP-SOLARWINDS' UNION"
						+ " SELECT 'CMMF-SOLARWINDS' UNION"
						+ " SELECT 'PHH-SOLARWINDS' UNION"
						+ " SELECT 'SRHS-SOLARWINDS' UNION"
						+ " SELECT 'SLVR-SOLARWINDS' UNION"
						+ " SELECT 'TCH-SOLARWINDS' )"
						+ " SELECT TOP 100 PERCENT"
						+ " case when pt.status < 4 then case___ else case___ end  AS Ticket_Number,"
						+ "dbo.fn_cdate(pt.A_create_date_time,18000,0) AS Date_Time_Created,"
						+ "name_ AS Full_Name,"
						+ "pt.Client,"
						+ "case pt.Priority when 0 then 'Standard' when 1 then 'Medium' when 2 then 'High' when 3 then 'Urgent'  end Priority,"
						+ "case pt.Status when 0 then 'New' when 1 then 'Assigned' when 2 then 'Acknowledged' when 3 then 'Pending' when 4 then 'Resolved' when 5 then 'Closed' when 6 then 'Void' end Status,"
						// +"Summary,"
						+ "Assigned_Individual,"
						+ "Assigned_Group"
						+ " FROM"
						+ " PULSEIndivList notif "
						+ " inner join pt_problemticket pt with (nolock) on pt.login_id=notif.login_id"
						+ " WHERE"
						+ " pt.status < 4 order by Date_Time_Created desc");

		return hiocTableQuery.toString();
	}

	public static String getPRATableQuery() {

		StringBuffer praTableQuery = new StringBuffer();
		praTableQuery
				.append("SELECT TOP 100 PERCENT dbo.fn_cdate(pt.A_create_date_time,18000,0) AS Date_Time_Created,"
						+ "CASE WHEN pt.status < 4 THEN case___ ELSE case___ END AS Ticket_Number,name_ AS Full_Name,pt.Client,"
						+ "CASE pt.Priority WHEN 0 THEN 'Standard' WHEN 1 THEN 'Medium' WHEN 2 THEN 'High' WHEN 3 THEN 'Urgent' END Priority,"
						+ "CASE pt.Status WHEN 0 THEN 'New' WHEN 1 THEN 'Assigned' WHEN 2 THEN 'Acknowledged' WHEN 3 THEN 'Pending' WHEN 4 THEN 'Resolved' WHEN 5 THEN 'Closed' WHEN 6 THEN 'Void' END Status,"
						+ "CASE WHEN pt.Status < 4 THEN 'B'+CAST(pt.A_create_date_time AS VARCHAR) ELSE 'A'+CAST(pt.A_create_date_time AS VARCHAR) END Status_Active, Assigned_Individual, Assigned_Group,"
						+ "CASE pt.Alert_Status WHEN 0 THEN '' WHEN 1 THEN '' WHEN 2 THEN '' WHEN 3 THEN '' WHEN 4 THEN '' WHEN 5 THEN 'Approaching SLA' WHEN 6 THEN 'Missed SLA' WHEN 7 THEN '' END SLA_Status "
						+ "FROM pt_problemticket pt WITH (nolock) WHERE pt.status < 4 AND pt.Assigned_Group IN ('CTS-PROVISIONING','CHP-EMT','AHC-IT-PROVISIONING','AHC-IT-PROVISIONING TERMS','CTS-ENTERPRISE AUDITS')");
		return praTableQuery.toString();
	}


	public static String getSDCallDisplayQuery() {
		// STatic value are given . Have to change to dynamic value in Later
		StringBuffer agentDeskDisplayQuery = new StringBuffer();
		agentDeskDisplayQuery
				.append("DECLARE"
						+ " @fromw INT, @tow INT"
						+ " SET @fromw = dbo.fn_epochqlfy('start','today',-18000,0)"
						+ " SET @tow   = dbo.fn_epochqlfy('end','today',-18000,0)"
						+ " SELECT dbo.fn_Cdate(Create_Date,-18000,0) Create_DateTime,"
						+ " CAST(dbo.fn_Cdate(Create_Date,-18000,0)AS DATE) Create_Date,"
						+ " REPLACE(RIGHT(CONVERT(VARCHAR(20),dbo.fn_Cdate(Create_Date,-18000,0),100 ),7),' ','') Create_Time,"
						+ " Full_Name," + " Team_Lead_Full_Name,"
						+ " Manager_Full_Name," + " Call_In_Type," + " Reason"
						+ " FROM CMN_Call_In WITH(nolock)"
						+ " WHERE Create_Date>=@fromw"
						+ " AND Create_Date <@tow");
		return agentDeskDisplayQuery.toString();
	}

	public static String getCustomerViewTreeSelect(String groupList) {
		if ("".equals(groupList)) {
			groupList = "''";
		}
		StringBuffer treeQuery = new StringBuffer();
		treeQuery
				.append("SELECT ORG_ID    AS node_id ,"
						+ " ORG_Name       AS node_name , "
						+ " ORG_Label      AS node_label ,"
						+ " 'organization' AS node_type ,"
						+ " CASE Parent_ORG_Id"
						+ " WHEN 0"
						+ " THEN NULL"
						+ " ELSE parent_org_id"
						+ " END    AS parent_id ,"
						+ " ROW_NUMBER() OVER(ORDER BY Org_Hier_Sort) AS sort_order"
						+ " FROM fn_PurOrgHier('CTS_SERVICE_DESK_CLIENTS','CTS_CLIENT_', "
						+ groupList + ")" + " WHERE ((Avaya_Client=1 "
						+ " AND Remedy_Client   =1)"
						+ " OR (Parent_org_name ='CTS_CLIENT_BARN'"
						+ " AND Remedy_Client   =1))");
		return treeQuery.toString();
	}

	public static String getClientListQuery() {
		StringBuffer agentDeskDisplayQuery = new StringBuffer();
		agentDeskDisplayQuery.append("SELECT RemedyID AS Optionvalue,"
				+ " RemedyID      AS Optionlabel" + " FROM"
				+ " ( SELECT DISTINCT eml.RemedyID"
				+ " FROM CTS_VAN_EmailAlerts eml"
				+ " WHERE eml.Create_Date>='2017-02-01'"
				+ " AND eml.Create_Date   <DATEADD(MONTH,1,'2017-02-01')"
				+ " ) t" + " ORDER BY 1");
		return agentDeskDisplayQuery.toString();
	}

	public static String dashboardExecutiveGroupData(
			LoginDetailDTO dashBoardHomeDTO) throws SQLException,
			NamingException {
		Connection connection = null;
		ResultSet resultSet = null;
		PreparedStatement psstatemet = null;
		StringBuilder builder = new StringBuilder();
		List<Integer> opentaskGroupList = new ArrayList<Integer>();

		try {

			opentaskGroupList = dashBoardHomeDTO.getGroupList();

			if (null != opentaskGroupList && !opentaskGroupList.isEmpty()) {

				for (int s : opentaskGroupList) {
					builder.append(";" + s);
				}
				builder.append(";");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}

	public String dashboardCTSSGroupData(LoginDetailDTO dashBoardHomeDTO)
			throws SQLException, NamingException {
		Connection connection = null;
		ResultSet resultSet = null;
		PreparedStatement psstatemet = null;
		StringBuilder builder = new StringBuilder();
		List<Integer> opentaskGroupList = new ArrayList<Integer>();

		try {

			opentaskGroupList = dashBoardHomeDTO.getGroupList();

			if (null != opentaskGroupList && !opentaskGroupList.isEmpty()) {
				builder.append("'");
				for (int s : opentaskGroupList) {
					builder.append(";" + s);
				}
				builder.append(";'");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != psstatemet)
					psstatemet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return builder.toString();
	}

	public static String getMetricsOffering() {
		StringBuffer MetricsOffering = new StringBuffer();
		MetricsOffering
				.append("SELECT"
						+ " Bill.sdm_billing_label AS Label,"
						+ " Bill_Rel.SDM_billing_rel_billing_parent AS Parent,"
						+ " Bill_Rel.SDM_billing_rel_billing_child AS Child"
						+ " FROM"
						+ " SDM_billing Bill ,SDM_billing_rel Bill_Rel "
						+ " WHERE Bill_Rel.SDM_billing_rel_billing_Child = Bill.SDM_billing_SK");
		return MetricsOffering.toString();
	}

	public static String getAAATable(String client) {
		StringBuffer aaaTable = new StringBuffer();

		aaaTable.append("SELECT "
				+ "[Client],"
				+ "ID,"
				+ "Title,"
				+ "Report,"
				+ "No,"
				+ "[Date Due],"
				+ "[Date Completed],"
				+ "[Completed By],"
				+ "[Distribution List],"
				+ "CASE "
				+ "WHEN [Metrics Excel] = '1' "
				+ "THEN 'Metrics Excel, '"
				+ " ELSE ''"
				+ " END +"
				+ " CASE"
				+ " WHEN [Metrics (Word)] = '1'"
				+ " THEN 'Metrics (Word), '"
				+ " ELSE ''"
				+ " END +"
				+ " CASE"
				+ " WHEN [PT & SR Review] = '1'"
				+ " THEN 'PT & SR Review, '"
				+ " ELSE ''"
				+ " END +"
				+ " CASE"
				+ " WHEN [DR & VIP PT Review] = '1'"
				+ "THEN 'DR & VIP PT Review, '"
				+ " ELSE ''"
				+ " END +"
				+ " CASE "
				+ "WHEN [DR PT Review] = '1'"
				+ "THEN 'DR PT Review, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [PM for Physicians] = '1' "
				+ "THEN 'PM for Physicians, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All Survey Details] = '1' "
				+ "THEN 'All Survey Details, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs only Survey Details] = '1' "
				+ "THEN 'DRs only Survey Details, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only Survey Details] = '1' "
				+ "THEN 'Vip Only Survey Details,' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All Survey Summary] = '1' "
				+ "THEN 'All Survey Summary, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs only Survey Summary] = '1' "
				+ "THEN 'DRs only Survey Summary, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only Survey Summary] = '1' "
				+ "THEN 'Vip Only Survey Summary, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All Grp] = '1' "
				+ "THEN 'All Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs only Grp] = '1' "
				+ "THEN 'DRs only Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only Grp] = '1' "
				+ "THEN 'Vip Only Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All SLA Grp] = '1' "
				+ "THEN 'All SLA Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs Only SLA Grp] = '1' "
				+ "THEN 'DRs Only SLA Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only SLA Grp] = '1' "
				+ "THEN 'Vip Only SLA Grp, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All SLA-Priority] = '1' "
				+ "THEN 'All SLA-Priority, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs Only SLA-Priority] = '1' "
				+ "THEN 'DRs Only SLA-Priority, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only SLA-Priority] ='1' "
				+ "THEN 'Vip Only SLA-Priority, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [All SLA-Cabling] = '1' "
				+ "THEN 'All SLA-Cabling, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [DRs Only SLA-Cabling] = '1' "
				+ "THEN 'DRs Only SLA-Cabling, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Vip Only SLA-Cabling] = '1' "
				+ "THEN 'Vip Only SLA-Cabling, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Supplemental Report Other] = '1' "
				+ "THEN 'Supplemental Report Other, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [PULSE Reports Other] = '1' "
				+ "THEN 'PULSE Reports Other, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Score Card Other] = '1' "
				+ "THEN 'Score Card Other, ' "
				+ "ELSE '' "
				+ "END + "
				+ "CASE "
				+ "WHEN [Survey Raw Data] = '1' "
				+ "THEN 'Survey Raw Data, ' "
				+ "ELSE '' "
				+ "END AS [Listed_Attachements] "
				+ "FROM "
				+ "[BI].[dbo].[RIMS_AAA] "
				+ "WHERE "
				+ "MonthProcessed ="
				+ "("
				+ "SELECT "

				+ "CAST(REPLACE((CONVERT(VARCHAR(8),DATEADD(m,-1,GETDATE()),111)),'/','') "
				+ "AS " + "VARCHAR(20)) " + ") " + " AND client = '" + client
				+ "' ");

		return aaaTable.toString();
	}

	
	public static String getExecutiveClientGroupList()
	{
		StringBuffer execClientGroupListQuery=new StringBuffer();
		execClientGroupListQuery.append("DECLARE @LOGIN_ID VARCHAR(MAX);"
				+" SET @LOGIN_ID = ? "
				+" DECLARE @ID VARCHAR(max);"
				+" DECLARE @StartIndex INT, @EndIndex INT, @Input varchar(max), @Character char(1)"
				+" DECLARE  @Output table (GroupName NVARCHAR(1000),GroupID NVARCHAR(100))"
				+" SET @Input = (SELECT SUBSTRING(group_list,2,LEN(group_list)-2)  from ("
				+" Select RTRIM(LTRIM(REPLACE(group_list,';',','))) as group_list from user_x usr with (nolock) where"
				+" login_name = @LOGIN_ID) as res)"
				+" SET @Character = ','"
				+" SET @StartIndex = 1"
				+" IF SUBSTRING(@Input, LEN(@Input) - 1, LEN(@Input)) <> @Character"
				+" BEGIN"
				+" SET @Input = @Input + @Character"
				+" END"
				+" WHILE CHARINDEX(@Character, @Input) > 0"
				+" BEGIN"
				+" SET @EndIndex = CHARINDEX(@Character, @Input)"
				+" INSERT INTO @Output(GroupName,GroupID)  SELECT [Group_Name],[Group_ID]"
				+" FROM [ARSystem_Reporting].[dbo].[Group_x] WITH (NOLOCK)"
				+" WHERE group_id = (SELECT SUBSTRING(@Input, @StartIndex, @EndIndex - 1))"
				+" SET @Input = SUBSTRING(@Input, @EndIndex + 1, LEN(@Input))"
				+" END SELECT * FROM @Output where GroupName like (SELECT SUBSTRING(@LOGIN_ID, 1, CHARINDEX('-', @LOGIN_ID))+'%') ");

		return execClientGroupListQuery.toString();
	}

	public static String getOpenTaskByGroup(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"SELECT SRT.Assigned_Group ,COUNT(*) AS \"Open Task\" "
				 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON SRT.Parent_Request_ID = SR.Request___ "
				 +" WHERE " 
				 +" SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				 +" AND SRT.status is not null "
				 +" AND SRT.Status NOT IN (4,5,6) "
				 +" GROUP BY SRT.Assigned_Group "
				 +" order by SRT.Assigned_Group");
			
				
		return openTaskbygroupQuery.toString();
	}

public static String getTasks_PAST_SLA(ExecutiveHomeDTO executiveHomeDTO){
		
		StringBuffer tasks_PAST_SLA_Query=new StringBuffer();
		tasks_PAST_SLA_Query.append(" Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				 +" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) " 
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 
				 +" SELECT SRT.Assigned_Group, COUNT(SR.Alert_Status) As \"Status\" "
				 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON SRT.Parent_Request_ID = SR.Request___ "
				 +" WHERE "
				 +" SR.status is not null "
				 +" and SR.Alert_Status='6' "
				 +" and SRT.[Complete_Date_Time] >=  @StartEpoch "
				 +" and SRT.[Complete_Date_Time] <=  @EndEpoch "
				 +" and SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				 +" GROUP BY SRT.Assigned_Group "
				 +" order by Assigned_Group "

		
		);

		return tasks_PAST_SLA_Query.toString();
	}

	public static String getSLAPerformance(ExecutiveHomeDTO executiveHomeDTO){
		
		System.out.println("QueryBuilder");
		StringBuffer slaPerformance_Week_Query=new StringBuffer();
		slaPerformance_Week_Query.append(
				"Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				 +" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) "
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 

				 +" SELECT  [Assigned Group], ROUND((CAST(Task_Resolved AS float) / CAST(Total AS float)) * 100,0) AS [Percent] "
				 +" FROM "
				 +" ( "
				 +" SELECT T1.[Assigned Group], T1.Task_Resolved,T2.Total "
				 +" FROM "
				 +" ( "
				 +" SELECT SRT.Assigned_Group As \"Assigned Group\", "
				 +" COUNT(*) AS Task_Resolved "
				 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON (SRT.Parent_Request_ID = SR.Request___) "
				 +" WHERE SRT.Status is not null "
				 +" and [Complete_Date_Time] >=  @StartEpoch "
				 +" and [Complete_Date_Time] <=  @EndEpoch "
				 +" AND Alert_Status NOT IN (6) " 
				 +" AND SRT.Status =4  "
				 +" AND SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				 +" GROUP BY "
				 +" SRT.[Assigned_Group] "
				 +"  ) T1, "
				 +"  ( "
				 +"  SELECT SRT.[Assigned_Group] As \"Assigned Group\", COUNT(*) AS Total "
				 +"  FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON (SRT.Parent_Request_ID = SR.Request___) "
				 +" WHERE SRT.Status is not null "
				 +" and [Complete_Date_Time] >=  @StartEpoch "
				 +" and [Complete_Date_Time] <=  @EndEpoch "
				 +" AND SRT.Status =4 " 
				 +" AND SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				 +" GROUP BY "
				 +" SRT.[Assigned_Group] "
				 +" ) T2 "
				 +" WHERE T1.[Assigned Group] = T2.[Assigned Group] "
				 +" )cal"
);

		return slaPerformance_Week_Query.toString();
	}

	

	public static String getOpenRequestsByTeam(ExecutiveHomeDTO executiveHomeDTO){
		
		StringBuffer open_Requests_By_Team_Query=new StringBuffer();
		open_Requests_By_Team_Query.append("SELECT SR. Request___ as \"SR Number\",SRT.Task_ID as \"Task ID\",SRT.Task as \"Description\",SR.Client as \"Client\",SR.Assigned_Group as \"Assigned Group\", "
				 +" case " 
				 +" when SR.Priority=0 then 'Standard' "
				 +" when SR.Priority=1 then 'Medium' "
				 +" when SR.Priority=2 then 'High' "
				 +" when SR.Priority=3 then 'Urgent' "
				 +" END as \"Task Priority\", "
				 +" CASE " 
				         +" WHEN SRT.status=0 THEN 'New' "
				         +" WHEN SRT.status=1 THEN 'Assigned' "
				         +" WHEN SRT.status=2 THEN 'Acknowledged' "
				         +" WHEN SRT.status=3 THEN 'Pending' "
				         +" WHEN SRT.status=4 THEN 'Resolved' "
				         +" WHEN SRT.status=5 THEN 'Closed' "
				         +" WHEN SRT.status=6 THEN 'Void' "
				         +" END as \"Current Status\", "
				         +" case " 
				 +" when SR.alert_status =6 then 'SLA Missed' "
				 +" else 'Within SLA' "
				 +" END as \"SLA\", "
				 +" ([dbo].[EpochToStandard] (SRT.Create_Date, 120)) as \"Task Created Date\", "
				 +" ([dbo].[EpochToStandard] (SRT.Assigned_Date_Time, 120)) as \"Task Assigned Date\", "
				 +" ([dbo].[EpochToStandard] (SRT.Complete_Date_Time, 120)) as \"Task Completed Date\" "
				 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON (SRT.Parent_Request_ID = SR.Request___) "
				 +" WHERE SRT.status is not null "
				 +" and SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				 +" AND SRT.Status NOT IN (4,5,6) "
				 +" order by \"Task Created Date\" desc");
		System.out.println(open_Requests_By_Team_Query.toString());
		return open_Requests_By_Team_Query.toString();
	}
	
	public static String getSelectedGroups(String groupNames)
	{
		StringBuffer activeGroupNamesQuery=new StringBuffer();
		activeGroupNamesQuery.append("SELECT Group_Id,Group_Name from Group_X WITH (NOLOCK) where Group_Name IN ("+groupNames+")");
		//System.out.println(activeGroupNamesQuery.toString());
		return activeGroupNamesQuery.toString();
	}

	public static String getClosedRequests(ExecutiveHomeDTO executiveHomeDTO){
		
		StringBuffer closed_Requests_Query=new StringBuffer();
		closed_Requests_Query.append("Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				+" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				+" IF(@Condition='LASTWEEK') "
				+"  BEGIN "
				+" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				+" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				+" END "
				+" IF(@Condition='LASTMONTH') "
				+" BEGIN "
				+" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				+" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				+" END "
				+" SET @StartDate = @StartDate+' 00:00:00' "
				+" SET @EndDate = @EndDate+' 23:59:59' "
				+" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) "
				+" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 
				+" SELECT " 
				+" SRT.[Assigned_Group] as \"Group Name\", COUNT(*) as \"Tasks Count\" "
			    +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
			    +" INNER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				+" ON (SRT.Parent_Request_ID = SR.Request___) "
				+" WHERE "
				+" SRT.status is not null "
				+" and SRT.[Complete_Date_Time] >=  @StartEpoch "
				+" and SRT.[Complete_Date_Time] <=  @EndEpoch "
				+" AND SRT.Status = 5 "
				+" AND SRT.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") "
				+" GROUP BY  SRT.Assigned_Group "
				+" order by SRT.Assigned_Group "
);
		System.out.println(closed_Requests_Query.toString());
		return closed_Requests_Query.toString();
	}
	
	public static String getProvisionDisplayDay()
	{
		StringBuffer monthAndYear=new StringBuffer();

		monthAndYear.append("SELECT *, "
               +" CONVERT(DECIMAL(5,2),(Minutes/CAST(60 AS FLOAT))) AS Hours "
               +" FROM CTS_Provisioning WITH (nolock) "
               +" WHERE Metric_Date_char=CONVERT(VARCHAR(10),DATEADD(DAY, DATEDIFF(DAY, '19000101', CURRENT_TIMESTAMP), '19000101'),121)");

		return monthAndYear.toString();
	}
	
	
	
    
	public static String getProvisionDisplayMonthAndYear(String value)
	{
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append("SELECT MAX(Assigned_Individual)  AS Assigned_Individual, "
                 +" SUM(Minutes)  AS Minutes, "
                 +" CONVERT(DECIMAL(5,2),(SUM(Minutes)/CAST(60 AS FLOAT))) AS Hours "
                 +" FROM CTS_Provisioning WITH (nolock) "
                 +" WHERE Metric_Date_char>=DATEADD("+value+", DATEDIFF("+value+", '19000201', CURRENT_TIMESTAMP), '19000101') "
                 +" AND Metric_Date        <DATEADD("+value+", DATEDIFF("+value+", '19000101', CURRENT_TIMESTAMP), '19000101') "
                 +" GROUP BY zAssignLogin "); 
		return openTaskbygroupQuery.toString();
	}
public static String getSummary(ExecutiveHomeDTO ldto)
	{
		
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append("Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20) "
+" SET @StartDate = '"+ldto.getFromDate()+"' "
+" SET @EndDate = '"+ldto.getToDate()+"' "
+" SET @StartDate = @StartDate+' 00:00:00' "
+" SET @EndDate = @EndDate+' 23:59:59' "
+" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) " 
+" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) "


+" SELECT totalAssignedGroup as  GroupName,  "
+" ISNULL(totalTaskCnt,0) as Total, "
+" ISNULL(standardTaskCnt,0) as Standard, "
+" ISNULL(mediumTaskCnt,0) as Medium, "
+" ISNULL(highTaskCnt,0) as High, "
+" ISNULL(urgentTaskCnt,0) as Urgent, "
+" ISNULL(newTaskCnt,0) as New, "
+" ISNULL(assignedTaskCnt,0) as Assigned, "
+" ISNULL(acknowledgedTaskCnt,0) as Acknowledged, "
+" ISNULL(pendingTaskCnt,0) as Pending, "
+" ISNULL(resolvedTaskCnt,0) as Resolved, "
+" ISNULL(closedTaskCnt,0) as Closed, "
+" ISNULL(SLAMissedTaskCnt,0) as SLAMissed, "
+" CAST(ISNULL(totalTaskCnt,0) as INT)  - ISNULL(SLAMissedTaskCnt,0) as WithinSLA "
+" FROM( "
+" SELECT Group_Name as totalAssignedGroup from Group_X WITH (NOLOCK) where Group_Name IN (" +ldto.getGroup()+" " 
 
/*+" (22037, "
+" 122122, "
+" 122097, "
+" 122107, "
+" 22061, "
+" 22039, "
+" 122102, "
+" 22067, "
+" 122103, "
+" 22041, "
+" 122104, "
+"22073, "
+" 22044"*/
+ ") "
 +" ) as assignedGroups "
+" LEFT OUTER JOIN "
+" (SELECT assigned_group ,COUNT(*) as totalTaskCnt FROM SR_Join_SR_and_SRT with (nolock) "  
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+"Group by assigned_group) as totalTasks "
+" ON totalAssignedGroup = totalTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as standardTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and priority = 0 "
+"Group by assigned_group) as standardTasks "
+" ON totalAssignedGroup = standardTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as mediumTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and priority = 1 "
+"Group by assigned_group) as mediumTasks "
+" ON totalAssignedGroup = mediumTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as highTaskCnt  FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and priority = 2 "
+"Group by assigned_group) as highTasks "
+" ON totalAssignedGroup = highTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as urgentTaskCnt  FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and priority = 3 "
+"Group by assigned_group) as urgentTasks "
+" ON totalAssignedGroup = urgentTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as newTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 0 "
+"Group by assigned_group) as newTasks "
+" ON totalAssignedGroup = newTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as assignedTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 1 "
+"Group by assigned_group) as assignedTasks "
+" ON totalAssignedGroup = assignedTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as acknowledgedTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 2 "
+"Group by assigned_group) as acknowledgedTasks "
+" ON totalAssignedGroup = acknowledgedTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as pendingTaskCnt FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 3 "
+"Group by assigned_group) as pendingTasks "
+" ON totalAssignedGroup = pendingTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as resolvedTaskCnt  FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 4 "
+"Group by assigned_group) as resolvedTasks "
+" ON totalAssignedGroup = resolvedTasks.assigned_Group "
+" LEFT OUTER JOIN "

+" (SELECT assigned_group,COUNT(*) as closedTaskCnt  FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and SRT_Status = 5 "
+"Group by assigned_group) as closedTasks "
+" ON totalAssignedGroup = closedTasks.assigned_Group "
+" LEFT OUTER JOIN "
+" (SELECT assigned_group,COUNT(*) as SLAMissedTaskCnt  FROM SR_Join_SR_and_SRT with (nolock) " 
+" where SRT_status is not null and SRT_Create_Date >= @StartEpoch "
+" and SRT_Create_Date <= @EndEpoch "
+" and alert_Status = 6 "
+"Group by assigned_group) as SLAMissedTasks "
+" ON totalAssignedGroup = SLAMissedTasks.assigned_Group "
+" order by GroupName"); 
		return openTaskbygroupQuery.toString();
	}
	
public static String getTaskDetailsInSummaryPageQuery(ExecutiveHomeDTO executiveHomeDTO)
{
	StringBuffer taskDetailsQuery=new StringBuffer();

	taskDetailsQuery.append("Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20)"
			+" Declare @Attribute varchar(50),@Value varchar(50), @GroupName varchar(max),@SqlQuery nvarchar(max),@AttributeValue varchar(max)"
			+" SET @StartDate = '"+executiveHomeDTO.getFromDate()+" 00:00:00'"
			+" SET @EndDate = '"+executiveHomeDTO.getToDate()+" 23:59:59'"
			+" SET @GroupName = '"+executiveHomeDTO.getGroupName()+"'"
			+" SET @Attribute = '"+executiveHomeDTO.getAtttribute()+"'"
			+" IF(@Attribute  ='Total')"
			+" BEGIN"
			+" SET @AttributeValue = '1 = 1'"
			+" END"
			+" IF(@Attribute ='Standard')"
			+" BEGIN"
			+" SET @AttributeValue = 'priority = 0'"
			+" END"
			+" IF(@Attribute ='Medium')"
			+" BEGIN"
			+" SET @AttributeValue = 'priority = 1'"
			+" END"
			+" IF(@Attribute ='High')"
			+"  BEGIN"
			+" SET @AttributeValue = 'priority = 2'"
			+" END"
			+" IF(@Attribute ='Urgent')"
			+" BEGIN"
			+" SET @AttributeValue = 'priority = 3'"
			+" END"
			+" IF(@Attribute ='New')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 0'"
			+" END"
			+" IF(@Attribute ='Assigned')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 1'"
			+" END"
			+" IF(@Attribute ='Acknowledged')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 2'"
			+" END"
			+" IF(@Attribute ='Pending')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 3'"
			+" END"
			+" IF(@Attribute ='Resolved')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 4'"
			+" END"
			+" IF(@Attribute ='Closed')"
			+" BEGIN"
			+" SET @AttributeValue = 'SRT_status = 5'"
			+" END"
			+" IF(@Attribute ='SLAMissed')"
			+" BEGIN"
			+" SET @AttributeValue = 'alert_status = 6'"
			+" END"
			+" IF(@Attribute ='WithinSLA')"
			+" BEGIN"
			+" SET @AttributeValue = 'alert_status != 6'"
			+" END"
			+" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0)" 
			+" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0)" 
			+" SET @SqlQuery = 'SELECT Request___ as \"SR Number\",SRT_Task_ID as \"Task ID\",SRT_Task as \"Description\",Client as \"Client\","
			+" case" 
			+" when Priority=0 then '+'''Standard'''+'"
			+" when Priority=1 then '+'''Medium'''+'"
			+" when Priority=2 then '+'''High'''+'"
			+" when Priority=3 then '+'''Urgent'''+'"
			+" END as \"Task Priority\","
			+" case" 
			+" when alert_status =6 then '+'''SLA Missed'''+'"
			+" else '+'''Within SLA'''+'"
			+" END as \"SLA\","
			+"	([dbo].[EpochToStandard] (SRT_Create_Date, 120)) as \"Task Created Date\",([dbo].[EpochToStandard] (Assigned_Date_Time, 120)) as \"Task Assigned Date\",([dbo].[EpochToStandard] (Complete_Date_Time, 120)) as \"Task Completed Date\" FROM SR_Join_SR_and_SRT WITH (NOLOCK)" 
			+" WHERE SRT_status is not null and SRT_Create_Date >= '+@StartEpoch+"
			+" ' and SRT_Create_Date <= '+@EndEpoch+"
			+" ' and assigned_group = '''+@GroupName+"
			+" ''' and '+@AttributeValue"
			+" EXEC sp_executesql @SqlQuery");
	return taskDetailsQuery.toString();
}

	
	
	public static String chartSave(ExecutiveHomeDTO dashboardhomedto)
	{
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append("INSERT INTO [SD_Metrics].[dbo].[ExecDB_ClientProfile] (userid, profileName, profileValue, created_date)"
                + " VALUES (?, ?, ?, ?)");
		return openTaskbygroupQuery.toString();
	}

	public static String getSavedQuery(ExecutiveHomeDTO executiveHomeDTO)
	{
		StringBuffer savedQuery=new StringBuffer();
   
		savedQuery.append("SELECT rowid,profileName,profileValue,created_date,userid "
                +" FROM"
                +" ("
                +" SELECT ROW_NUMBER() OVER (PARTITION BY userid ORDER BY Created_date DESC) AS CreatedDate,* "
                +" FROM SD_Metrics.[dbo].[ExecDB_ClientProfile] "
	            +" where userid= '"+executiveHomeDTO.getClientName()+"'"
                +" ) as profileList "
                +" where profileList.createddate < = 10");
		return savedQuery.toString();
	}
	
	public static String getSavedProfileValue(ExecutiveHomeDTO executiveHomeDTO)
	{
		StringBuffer profileValue=new StringBuffer();

		profileValue.append("SELECT profileValue "
				+" FROM SD_Metrics.dbo.ExecDB_ClientProfile"
				+" where rowid ="+executiveHomeDTO.getRowid()
				+ " AND userid like('"+ executiveHomeDTO.getUserId()+"')");
		return profileValue.toString();
	}
	
	
	public static String getOpenTaskOnClick(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"SELECT  Request___ as \"SR Number\",SRT.Task_ID as \"Task ID\",SRT.Task as \"Description\",SR.Client as \"Client\",SRT.Assigned_Group as \"Assigned Group\", "
				 +" case "
				 +" when Priority=0 then 'Standard' "
				 +" when Priority=1 then 'Medium' "
				 +" when Priority=2 then 'High' "
				 +" when Priority=3 then 'Urgent' "
				 +" END as \"Task Priority\", "
				 +" CASE " 
				          +"  WHEN SRT.Status=0 THEN 'New' "
				          +" WHEN SRT.status=1 THEN 'Assigned' "
				          +" WHEN SRT.status=2 THEN 'Acknowledged' "
				          +" WHEN SRT.Status=3 THEN 'Pending' "
				          +" WHEN SRT.Status=4 THEN 'Resolved' "
				          +" WHEN SRT.Status=5 THEN 'Closed' "
				          +" WHEN SRT.Status=6 THEN 'Void' "
				          +" END as \"Current Status\", "
				          +"case " 
				  +" when alert_status =6 then 'SLA Missed' "
				  +" else 'Within SLA' "
				  +" END as \"SLA\", "
				  +" ([dbo].[EpochToStandard] (SRT.Create_Date, 120)) as \"Task Created Date\", "
				  +" ([dbo].[EpochToStandard] (Assigned_Date_Time, 120)) as \"Task Assigned Date\" , "
				  +" ([dbo].[EpochToStandard] (Complete_Date_Time, 120)) as \"Task Completed Date\" "
						  +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
						  +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				  +" ON SRT.Parent_Request_ID = SR.Request___ "
				  +" WHERE "
				  +" SRT.Assigned_Group IN ('"+executiveHomeDTO.getGroupName()+"') "
				  +" AND SRT.status is not null "
				  +" AND SRT.Status NOT IN (4,5,6)");
			
				
		return openTaskbygroupQuery.toString();
	}

	public static String getTaskPastSLAOnClick(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				 +" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) " 
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) "
				 
				 +" SELECT  Request___ as \"SR Number\",SRT.Task_ID as \"Task ID\",SRT.Task as \"Description\",SR.Client as \"Client\",SRT.Assigned_Group as \"Assigned Group\", "
				 +" case " 
				 +" when Priority=0 then 'Standard' "
				 +" when Priority=1 then 'Medium' "
				 +" when Priority=2 then 'High' "
				 +" when Priority=3 then 'Urgent' "
				 +" END as \"Task Priority\", "
				 +" CASE " 
				          +" WHEN SRT.Status=0 THEN 'New' "
				          +" WHEN SRT.status=1 THEN 'Assigned' "
				          +" WHEN SRT.status=2 THEN 'Acknowledged' "
				          +" WHEN SRT.Status=3 THEN 'Pending' " 
				          +" WHEN SRT.Status=4 THEN 'Resolved' "
				          +" WHEN SRT.Status=5 THEN 'Closed' "
				          +" WHEN SRT.Status=6 THEN 'Void' "
				          +" END as \"Current Status\", "
				          +" case " 
				 +" when alert_status =6 then 'SLA Missed' "
				 +" else 'Within SLA' "
				 +" END as \"SLA\", "
				 +" ([dbo].[EpochToStandard] (SRT.Create_Date, 120)) as \"Task Created Date\", "
				 +" ([dbo].[EpochToStandard] (Assigned_Date_Time, 120)) as \"Task Assigned Date\" , "
				 +" ([dbo].[EpochToStandard] (Complete_Date_Time, 120)) as \"Task Completed Date\" "
				 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
				 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON SRT.Parent_Request_ID = SR.Request___ "
				 +"  WHERE "
				 +" SRT.status is not null "
				 +" and SR.Alert_Status='6' "
				 +" and SRT.[Complete_Date_Time] >=  @StartEpoch "
				 +" and SRT.[Complete_Date_Time] <=  @EndEpoch "
				 +" and SRT.Assigned_Group IN ('"+executiveHomeDTO.getGroupName()+"')");
			
				
		return openTaskbygroupQuery.toString();
	}

	public static String getClosedRequestOnClick(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				+"  SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) "
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 	 
				 
 +" SELECT SR. Request___ as \"SR Number\",SRT.Task_ID as \"Task ID\",SRT.Task as \"Description\",SR.Client as \"Client\",SR.Assigned_Group as \"Assigned Group\", "
 +" case " 
				 +" when SR.Priority=0 then 'Standard' "
				 +" when SR.Priority=1 then 'Medium' "
				 +" when SR.Priority=2 then 'High' "
				 +" when SR.Priority=3 then 'Urgent' "
				 +" END as \"Task Priority\", "
				 +" CASE " 
				          +" WHEN SRT.status=0 THEN 'New' "
				          +" WHEN SRT.status=1 THEN 'Assigned' "
				          +" WHEN SRT.status=2 THEN 'Acknowledged' "
				          +" WHEN SRT.status=3 THEN 'Pending' "
				          +" WHEN SRT.status=4 THEN 'Resolved' "
				          +" WHEN SRT.status=5 THEN 'Closed' "
				          +" WHEN SRT.status=6 THEN 'Void' "
				          +" END as \"Current Status\", "
				          +" case " 
				 +" when SR.alert_status =6 then 'SLA Missed' "
				 +" else 'Within SLA' "
				 +" END as \"SLA\", "
				 +" ([dbo].[EpochToStandard] (SRT.Create_Date, 120)) as \"Task Created Date\", "
				 +" ([dbo].[EpochToStandard] (SRT.Assigned_Date_Time, 120)) as \"Task Assigned Date\", "
				 +" ([dbo].[EpochToStandard] (SRT.Complete_Date_Time, 120)) as \"Task Completed Date\" "
						 +" FROM [ARSystem_Reporting].dbo.SR_ServiceRequest SR WITH (NOLOCK) "
						 +" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
				 +" ON (SRT.Parent_Request_ID = SR.Request___) "
				 +" WHERE "
				 +" SRT.status is not null "
				 +" and SRT.[Complete_Date_Time] >=  @StartEpoch "
				 +" and SRT.[Complete_Date_Time] <=  @EndEpoch "
				 +" AND SRT.Status = 5 "
				 +" AND SRT.Assigned_Group IN ('"+executiveHomeDTO.getGroupName()+"')");
			
				
		return openTaskbygroupQuery.toString();
	}
	
	
	public static String getRequestWaitingForAppoval(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				 +" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') " 
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) " 
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) "
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 
+" SELECT SR.Assigned_Group as \"Assigned Group\",COUNT(*) AS [Request Awaiting Approval] "
				
+" FROM ks_srv_customersurvey_base KSSRV WITH (NOLOCK) "
+" INNER JOIN SR_ServiceRequest SR WITH (NOLOCK) "
+" ON KSSRV.Attribute1= SR.Request___ "
+" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
+" ON (SRT.Parent_Request_ID = SR.Request___) "
+" WHERE KSSRV.submit_type = 'Approval' AND KSSRV.Status = 1 AND KSSRV.ValidationStatus = 'Awaiting Approval' " 
+" and SRT.Create_Date >=  @StartEpoch "
+" and SRT.Create_Date <=  @EndEpoch "
+"  and SR.Assigned_Group IN ("+executiveHomeDTO.getGroupName()+") AND SRT.Status NOT IN (4,5,6) "
+" Group By SR.Assigned_Group");
			
				
		return openTaskbygroupQuery.toString();
	}
	
	
	public static String getRequestWaitingForAppovalOnClick(ExecutiveHomeDTO executiveHomeDTO){
		StringBuffer openTaskbygroupQuery=new StringBuffer();

		openTaskbygroupQuery.append(
				"Declare @StartDate varchar(20),@EndDate varchar(20),@StartEpoch varchar(20),@EndEpoch varchar(20),@Condition varchar(30) "
				 +" SET @Condition = '"+executiveHomeDTO.getDropdownOption()+"' "
				 +" IF(@Condition='LASTWEEK') "
				 +" BEGIN " 
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),-1),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1,DATEADD(WEEK,DATEDIFF(WEEK,7,GETDATE()),6)),120) "
				 +" END "
				 +" IF(@Condition='LASTMONTH') "
				 +" BEGIN "
				 +" SET @StartDate = CONVERT(VARCHAR(10),DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE()) - 2, 0),120) "
				 +" SET @EndDate = CONVERT(VARCHAR(10),DATEADD(ss, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)),120) "
				 +" END "
				 +" SET @StartDate = @StartDate+' 00:00:00' "
				 +" SET @EndDate = @EndDate+' 23:59:59' "
				 +" SET @StartEpoch= [dbo].[fn_DateToEpoch](@StartDate,-18000,0) "
				 +" SET @EndEpoch= [dbo].[fn_DateToEpoch](@EndDate,-18000,0) " 
+" SELECT SR. Request___ as \"SR Number\",SRT.Task_ID as \"Task ID\",SRT.Task as \"Description\",SR.Client as \"Client\",SR.Assigned_Group as \"Assigned Group\", "
+" case " 
				 +" when SR.Priority=0 then 'Standard' "
				 +" when SR.Priority=1 then 'Medium' "
				 +" when SR.Priority=2 then 'High' "
				 +" when SR.Priority=3 then 'Urgent' "
				 +" END as \"Task Priority\", "
				 +" CASE " 
				          +" WHEN SRT.status=0 THEN 'New' "
				          +" WHEN SRT.status=1 THEN 'Assigned' "
				          +" WHEN SRT.status=2 THEN 'Acknowledged' "
				          +" WHEN SRT.status=3 THEN 'Pending' "
				          +" WHEN SRT.status=4 THEN 'Resolved' "
				          +" WHEN SRT.status=5 THEN 'Closed' "
				          +" WHEN SRT.status=6 THEN 'Void' "
				          +" END as \"Current Status\", "
				          +" case " 
				 +" when SR.alert_status =6 then 'SLA Missed' "
				 +" else 'Within SLA' "
				 +" END as \"SLA\", "
				 +" ([dbo].[EpochToStandard] (SRT.Create_Date, 120)) as \"Task Created Date\", "
				 +" ([dbo].[EpochToStandard] (SRT.Assigned_Date_Time, 120)) as \"Task Assigned Date\" "
				
+" FROM ks_srv_customersurvey_base KSSRV WITH (NOLOCK) "
+" INNER JOIN SR_ServiceRequest SR WITH (NOLOCK) "
+" ON KSSRV.Attribute1= SR.Request___"
+" LEFT OUTER JOIN [ARSystem_Reporting].dbo.SR_Task SRT WITH (NOLOCK) "
+" ON (SRT.Parent_Request_ID = SR.Request___) "
+" WHERE KSSRV.submit_type = 'Approval' AND KSSRV.Status = 1 AND KSSRV.ValidationStatus = 'Awaiting Approval' " 
+" and SRT.Create_Date >=  @StartEpoch "
+" and SRT.Create_Date <=  @EndEpoch "
+" and SR.Assigned_Group IN ('"+executiveHomeDTO.getGroupName()+"') AND SRT.Status NOT IN (4,5,6)");
			
				
		return openTaskbygroupQuery.toString();
	}
	
	
	
	
}
