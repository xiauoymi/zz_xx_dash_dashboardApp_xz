package com.htc.utility;


public class TeleoptiCheckScheduleDTO {
	
	public String personIdInTeleopti;
	public String startDate;
	public String endDate;
	public String agentIdInTOMS;
	public String agentName;
	
	
	
	public String getPersonIdInTeleopti() {
		return personIdInTeleopti;
	}
	public void setPersonIdInTeleopti(String personIdInTeleopti) {
		this.personIdInTeleopti = personIdInTeleopti;
	}
	public String getAgentIdInTOMS() {
		return agentIdInTOMS;
	}
	public void setAgentIdInTOMS(String agentIdInTOMS) {
		this.agentIdInTOMS = agentIdInTOMS;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	

}
