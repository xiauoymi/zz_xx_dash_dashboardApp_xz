package com.htc.utility;

public class StoredProcedureConstants {

	/* MTD */
	public static String MTD_Daily_Per_Client = "{call sp_db_Basic_MTD_Daily_Per_Client(?,?)}";
	public static String MTD_Daily_Per_Queue = "{call sp_db_Basic_MTD_Daily_Per_Queue(?,?)}";
	public static String MTD_Per_Client = "{call sp_db_MTD_Per_Client(?,?)}";
	public static String MTD_Per_Queue = "{call sp_db_MTD_Per_Queue(?,?)}";
	public static String sp_get_Report_List_ForGroupsUsers = "{call sp_get_Report_List_ForGroupsUsers(?,?,?,?)}";

	/* TotalContacts */
	public static String TotalContacts = "{call sp_db_TotalContacts(?)}";
	public static String TotalContactsBYApplicationClient = "{call sp_db_TotalContactsBYApplicationClient(?)}";
	public static String TotalContacts_Yearly = "{call sp_db_TotalContacts_Yearly(?)}";

	/* CSDDataTable */
	public static String sp_SDDateTable = "{call sp_SDDateTable(?)}";
	public static String sp_SDDateTable_by_AppID = "{call sp_SDDateTable_by_AppID(?)}";

	/* CTSSCustomerView */
	public static String sp_db_SD_CustomerView_SLAPerformance = "{call sp_db_SD_CustomerView_SLAPerformance(?,?)}";
	public static String sp_db_SD_CustomerView_CallSummary = "{call sp_db_SD_CustomerView_CallSummary(?,?)}";
	public static String sp_Get_Top5_CTIs = "{call sp_Get_Top5_CTIs(?,?,?)}";
	public static String sp_Get_Top5_Incidents = "{call sp_Get_Top5_Incidents(?,?,?)}";
	public static String sp_Get_CTIs_PT_List = "{call sp_Get_CTIs_PT_List(?,?,?,?,?,?,?)}";
	public static String sp_Get_Incidents_PT_List = "{call sp_Get_Incidents_PT_List(?,?,?,?,?)}";

	// public static String sp_htc_Get_Tabs_List="{call sp_Get_Tabs_List(?,?)}";
	public static String sp_Get_Tabs_List_ForGroupsUsers = "{call sp_Get_Tabs_List_ForGroupsUsers(?,?,?)}";
	public static String sp_htc_authenticate_external_user = "{call sp_authenticate_external_user(?,?,?)}";
	public static String sp_Get_Report_Group_Names = "{call sp_Get_Report_Group_Names}";

	/* CTSSCustomerViewChart */
	public static String sp_CustomerView_SLAPerformance_Chart = "{call sp_CustomerView_SLAPerformance_Chart(?,?,?)}";
	public static String sp_CustomerView_CallSummary_Chart = "{call sp_CustomerView_CallSummary_Chart(?,?,?)}";

	/* csdAgentDeskTop */
	public static String sp_Agent_Desktop_Display = "{call  sp_Agent_Desktop_Display(?)}";

	/* CSDAgentDisplayBoard */
	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Top = "{call sp_Caretech_Service_Desk_Agent_Display_Board_Top(?)}";
	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Bottom = "{call sp_Caretech_Service_Desk_Agent_Display_Board_Bottom(?)}";
	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Side = "{call sp_Caretech_Service_Desk_Agent_Display_Board_Side}";
	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Middle = "{call sp_Caretech_Service_Desk_Agent_Display_Board_Middle(?)}";

	/* history recent procedure changed to remedy reporting start 6-21-2017 */
	// public static String
	// sp_Caretech_Service_Desk_Agent_Display_Board_Historical
	// ="{call sp_Caretech_Service_Desk_Agent_Display_Board_Historical}";
	// public static String sp_Caretech_Service_Desk_Agent_Display_Board_Recent
	// ="{call sp_Caretech_Service_Desk_Agent_Display_Board_Recent}";
	/* history recent procedure changed to remedy reporting End 6-21-2017 */

	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Historical = "{call sp_SDM_symon_uhticker_min(?)}";
	public static String sp_Caretech_Service_Desk_Agent_Display_Board_Recent = "{call sp_SDM_symon_uhticker_min(?)}";

	/* CSDDsplayBoard */
	public static String sp_Caretech_Service_Desk_Display_Board_Top = "{call sp_Caretech_Service_Desk_Display_Board_Top}";
	public static String sp_Caretech_Service_Desk_Display_Board_Middle = "{call sp_Caretech_Service_Desk_Display_Board_Middle}";
	public static String sp_Caretech_Service_Desk_Display_Board_Side = "{call sp_Caretech_Service_Desk_Display_Board_Side}";
	public static String sp_Caretech_Service_Desk_Display_Board_Historical = "{call sp_Caretech_Service_Desk_Display_Board_Historical}";
	public static String sp_Caretech_Service_Desk_Display_Board_Recent = "{call sp_Caretech_Service_Desk_Display_Board_Recent}";
	

	public static String sp_Agent_SkillsetDetails_Dev = "{call sp_Agent_SkillsetDetails_Dev(?)}";
	public static String sp_Assign_Report_To_GroupAndUser_with_Access = "{call sp_Assign_Report_To_GroupAndUser_with_Access(?,?,?,?,?,?)}";
	public static String SP_VIEW_RULES = "{call sp_ViewRules(?)}";

	/* organization */
	public static String sp_get_Type = "{call sp_get_Type 7}";
	public static String sp_get_Status = "{call sp_get_Status 7}";
	public static String sp_get_Organizations_Tree = "{call sp_get_Organizations_Tree}";
	public static String sp_Get_Organization_By_ID = "{call sp_Get_Organization_By_ID(?)}";
	public static String sp_organizations_DML_INSERT = "{call sp_organizations_DML ('INSERT','',?,?,?,?,?,?,?,?,?,?)}";
	public static String sp_organizations_DML_DELETE = "{call sp_organizations_DML ('DELETE',?,'','','','','','','','','','')}";
	public static String sp_organizations_DML_UPDATE = "{call sp_organizations_DML ('UPDATE',?,?,?,?,?,?,?,?,?,?,?)}";

	public static String sp_Get_SDM_GroupName_External = "{call sp_Get_SDM_GroupName_External()}";
	public static String sp_Get_SDM_GroupName_Remedy = "{call sp_Get_SDM_GroupName_Remedy()}";

	/* offering */
	public static String sp_get_Type_1 = "{call sp_get_Type 1}";
	public static String sp_get_Status_1 = "{call sp_get_Status 1}";
	public static String sp_get_billing_ByID = "{call sp_get_billing_ByID(?)}";
	public static String sp_billing_DML_INSERT = "{call sp_billing_DML(?,'INSERT','',?,?,?,?,?,?,?)}";
	public static String sp_billing_DML_UPDATE = "{call sp_billing_DML(?,'UPDATE',?,?,?,?,?,?,?,?)}";
	public static String sp_billing_DML_DELETE = "{call sp_billing_DML(?,'DELETE',?,'','','','','','','')}";

	public static String sp_create_group_user = "{call sp_create_group_user('User',?,?,'',?,?,?,?,?,?)}";
	public static String sp_Assign_User_To_Group = "{call sp_Assign_User_To_Group(?,?,?)}";
	public static String sp_Get_User_Name_For_External = "{call sp_Get_User_Name_For_External()}";
	public static String sp_Get_External_User_Information_With_Group = "{call sp_Get_External_User_Information_With_Group(?)}";
	public static String sp_Delete_or_Update_External_User = "{call sp_Delete_or_Update_External_User(?,?,?,?,?,?,?)}";
	public static String sp_Get_SDM_Report_Name = "{call sp_Get_SDM_Report_Name()}";
	public static String sp_Get_User_Name_For_Remedy = "{call sp_Get_User_Name_For_Remedy()}";

	/* Metrics */
	public static String sp_get_Metrics_Tree = "{call sp_get_Metrics_Tree }";
	public static String sp_get_metric_groups = "{call sp_get_metric_groups }";
	public static String sp_get_mCat_BymID = "{call sp_get_mCat_BymID(?) }";
	public static String sp_get_Status_METRIC = "{call sp_get_Status(3) }";
	public static String sp_get_Status_METRIC_GROUP = "{call sp_get_Status(4) }";
	public static String sp_get_Type_METRIC = "{call sp_get_Type(3) }";
	public static String sp_get_Type_METRIC_GROUP = "{call sp_get_Type(4) }";
	public static String sp_get_metrics_ByID = "{call sp_get_metrics_ByID(?) }"; /*
																				 * metric
																				 * tree
																				 * click
																				 */
	public static String sp_get_metric_groups_ByID = "{call sp_get_metric_groups_ByID(?) }"; /*
																							 * metricgroup
																							 * tree
																							 * click
																							 */
	public static String sp_metric_groups_DML_INSERT = "{call sp_metric_groups_DML(?,'INSERT','',?,?,?,?,?,?) }";
	public static String sp_metric_groups_DML_DELETE = "{call sp_metric_groups_DML(?,'DELETE',?,'','','','','','') }";
	public static String sp_metric_groups_DML_UPDATE = "{call sp_metric_groups_DML(?,'UPDATE',?,?,?,?,?,?,?) }";
	public static String sp_metrics_DML_INSERT = "{call sp_metrics_DML(?,'INSERT','',?,'','',?,?,?,?,?,?,?) }";
	public static String sp_metrics_DML_DELETE = "{call sp_metrics_DML(?,'DELETE',?,'','','','','','','','','','') }";
	public static String sp_metrics_DML_UPDATE = "{call sp_metrics_DML(?,'UPDATE',?,?,'','',?,?,?,?,?,?,?) }";

	public static String sp_get_CTS_Provisioning_Daily = "{call sp_get_CTS_Provisioning_Daily}";
	public static String sp_get_CTS_Provisioning_Weekly_Monthly = "{call sp_get_CTS_Provisioning_Weekly_Monthly(?)}";
	// PulseEmailAlertBY All
	public static String sp_get_PulseCharts_All_ByID = "{call sp_get_PulseCharts_All_ByID(?,?,'ALL','ID')}";
	public static String sp_get_PulseCharts_AllbyClient_ByID = "{call sp_get_PulseCharts_AllbyClient_ByID(?,?,'AllbyClient','ID')}";
	public static String sp_get_PulseCharts_ByName = "{call sp_get_PulseCharts_ByName(?,?,?,'Name')}";

	// PulseEmailAlertByClient
	public static String sp_get_Remedy_IDs = "{call sp_get_Remedy_IDs}";
	public static String sp_get_PulseCharts_ByClient_ByID = "{call sp_get_PulseCharts_ByClient_ByID(?,?,?,'ID')}";

	public static String sp_Check_User_Availability = "{call sp_Check_User_Availability(?,?)}";
	public static String sp_Get_Security_Question = "{call sp_Get_Security_Question(?,?)}";
	public static String sp_get_Security_Question_For_Login = "{call sp_get_Security_Question_For_Login()}";

	public static String sp_User_Authentication_With_Security_Question = "{call sp_User_Authentication_With_Security_Question(?,?)}";
	public static String sp_Assign_User_Security_Question = "{call sp_Assign_User_Security_Question(?,?,?,?)}";
	public static String sp_Validate_User_Security_Answer = "{call sp_Validate_User_Security_Answer(?,?,?)}";
	public static String sp_Insert_Password = "{call sp_Insert_Password(?,?,?)}";

	public static String sp_Monitoring_AA_Screen1 = "{call sp_Monitoring_AA_Screen1}";
	public static String sp_Monitoring_AA_Screen2 = "{call sp_Monitoring_AA_Screen2}";
	public static String sp_Monitoring_AR_Screen1 = "{call sp_Monitoring_AR_Screen1}";
	public static String sp_Monitoring_AR_Screen2 = "{call sp_Monitoring_AR_Screen2}";
	public static String sp_Monitoring_SDM_Screen1 = "{call sp_Monitoring_SDM_Screen1}";
	public static String sp_Monitoring_SDM_Screen2 = "{call  sp_Monitoring_SDM_Screen2}";
	public static String sp_Monitoring_RTD_Screen1 = "{call sp_Monitoring_RTD_Screen1}";
	public static String sp_Monitoring_RTD_Screen2 = "{call sp_Monitoring_RTD_Screen2}";
	public static String sp_etl_monitoring = "{call sp_etl_monitoring}";
	public static String sp_monitoring_notify = "{call sp_monitoring_notify(?,?,?)}";
	public static String sp_monitoring_fix = "{call sp_monitoring_fix(?,?,?)}";
	public static String sp_monitoring_not_run_jobs = "{call sp_monitoring_not_run_jobs}";
	public static String sp_get_ETL_Monitoring_help = "{call sp_get_ETL_Monitoring_help(?,?)}"; // dummy
																								// procedure
																								// remove
																								// this
																								// and
																								// add
																								// new
																								// procedure

	// MonthEndREport
	public static String sp_MonthEndReportClients_DQL = "{call sp_MonthEndReportClients_DQL('STATUSDISP','')}";

	// MonthEndVerificationReport
	public static String sp_Client_Report_Count = "{call sp_Client_Report_Count}";
	public static String sp_get_Reports_For_Clients = "{call sp_get_Reports_For_Clients(?)}";
	public static String sp_Insert_Report_Verification_Details = "{call sp_Insert_Report_Verification_Details(?,?,?,?)}";
	public static String sp_get_client_emails_list = "{call sp_get_client_emails_list(?)}";

	// Phone Queue
	public static String sp_htc_get_SDM_SDCustomerSLA_ByID = "{call sp_get_SDM_SDCustomerSLA_ByID(?)}";
	public static String sp_htc_SDM_SDCustomerSLA_DML = "{call sp_SDM_SDCustomerSLA_DML(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	// SDMetrics Report
	public static String sp_client_tree = "{call sp_client_tree(?,?,?)}";
	public static String sp_Report_Send_Details_With_Status = "{call sp_Report_Send_Details_With_Status(?)}";
	public static String sp_Report_Send_Details_Report = "{call sp_get_Report_Status(?)}";
	public static String sp_Insert_Report_Send_Status = "{call sp_Insert_Report_Send_Status(?,?,?,?)}";
	public static String sp_Send_Mail = "{call sp_Send_Mail(?,?)}";
	public static String sp_Insert_New_EMailAddress = "{call sp_Insert_New_EMailAddress(?,?,?)}";
	public static String sp_Remove_Email_Address_for_Mail_Subject = "{call sp_Remove_Email_Address_for_Mail_Subject(?,?,?)}";
	public static String sp_get_Not_Sent_Reports = "{call sp_get_Not_Sent_Reports(?)}";
	public static String sp_get_Report_Counts = "{call sp_get_Report_Counts(?)}";

	// rollup report
	public static String sp_get_Rollup_Reports = "{call sp_get_Rollup_Reports ()}";
	public static String sp_get_SDM_Rollup_Reports = "{call sp_get_SDM_Rollup_Reports(?)}";
	public static String sp_get_client_list = "{call getClientList(?)}";
	public static String sp_get_CrystalReport_Detail = "{call getReportInformationforClient(?)}";
	public static String sp_getMailSubject_andEmail_forReport = "{call getMailSubjectandEmailforReport(?)}"; 
	public static String sp_Insert_Schedule = "{call InsertSchedule(?,?,?,?,?,?,?,?,?)}";
	public static String sp_load_Reports = "{call getReportstoSchedule}";

	//executiveDashboards
	public static String Open_Task  = "{call Open_Task (?,?)}";
	public static String Task_Past_SLA  = "{call Task_Past_SLA (?,?)}";
	public static String SLA_Performance  = "{call SLA_Performance (?,?)}";
	public static String Open_Request  = "{call Open_Request (?,?)}";
	public static String Closed_Request  = "{call Closed_Request (?,?)}";
	public static String Open_Tasks_Drill_Down  = "{call Open_Tasks_Drill_Down (?,?)}";
	public static String Task_past_SLA_Drill_Down  = "{call Task_past_SLA_Drill_Down (?,?)}"; 
	public static String Closed_Request_Drill_Down  = "{call Closed_Request_Drill_Down (?,?)}"; 
	public static String Requests_Awaiting_Approval_Drill_Down  = "{call Requests_Awaiting_Approval_Drill_Down (?,?)}"; 
	public static String Requests_Awaiting_Approval  = "{call Requests_Awaiting_Approval (?,?)}";
	public static String Group_List_by_User  = "{call Group_List_by_User (?)}";


	
	//LMS SP
	public static final String SP_GET_LEAVE_TYPE = "{call getLeaveType}";
	public static final String SP_GET_SUPERVISOR = "{call getSupervisor(?)}";
	public static final String sp_getLeaveBalance = "{call sp_getLeaveBalance(?)}";
	public static final String getLeaveHistory = "{call getLeaveHistory(?)}";
	public static final String SP_APPLY_LEAVE = "{call ApplyLeave(?,?,?,?,?,?,?,?,?,?,?,?,?)}"; 
	public static final String getMailAddressForApplyAndApprove = "{call getMailAddressForLeaveApply(?,?)}"; 
	public static final String sp_set_email_status = "{call Set_Email_Status(?,?)}";
	public static final String sp_getRequestAwaitingApprovalManager = "{call getRequestAwaitingApprovalManager(?)}";
	public static final String SP_APPROVE_LEAVE = "{call Approve_Leave(?,?,?,?,?,?)}";
	public static final String SP_AgentsListForManager = "{call AgentsListForManager(?)}";
	public static final String SP_getRequestAwaitingApprovalAgent = "{call getRequestAwaitingApprovalAgent(?)}";
	public static final String getAgentActivities = "{call getAgentActivities(?,?)}";
	public static final String AgentActivityModification = "{call AgentActivityModification(?,?,?,?,?,?)}";
	public static final String getLoginStats  = "{call getLoginStats (?,?)}";
	public static final String GET_SUPERVISOR_NAME="{call getSupervisorName(?)}";
	public static final String load_Agent_For_Supervisor="{call AgentsListForManager (?)}";
	public static final String APPLY_INVITE = "{call ApplyInvite (?,?,?,?,?,?,?,?,?,?,?,?)}";
	
	public static final String GET_SCHEDULED_INVITES = "{call getScheduleInvites (?)}";
	public static final String SHOW_PARTICIPANTS =  "{call getParticipants(?)}";
	public static final String cancel_r_close_invite="{call Cancel_or_Close_Invite (?,?,?,?)}";
	public static final String getAgentsByMgrID   = "{call getAgentsByMgrID  (?)}";
	public static final String getUserID   = "{call getID  (?)}";
	public static final String getAgentModifiedActivities   = "{call getAgentModifiedActivities  (?)}";
	public static final String GET_INVITE_VALUES =  "{call getScheduleInvitesInformation(?)}";
	public static final String UPDATE_INVITE = "{call UpdateSchedule(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	public static final String GET_CUTOFF_DATE = "{call getBlockDate}";;
	public static final String GET_MAIL_ADDRESS_FOR_INVITE = "{call getMailAddressForInvite(?)}";
	public static final String Set_Email_Status ="{call Set_Email_Status_For_Invite(?,?)}";
	public static final String getEmailAddressForTimesheet ="{call getEmailAddressForTimesheet(?,?,?,?)}";
	public static final String setEmailStatusTimesheet ="{call setEmailStatusTimesheet(?,?)}";
	public static final String getLeaveDataForTeleopti ="{call getLeaveDataForTeleopti(?)}"; 
	public static String getInviteScheduledDataForTeleopti="{call getInviteScheduledDataForTeleopti(?,?)}";

	public static final String GET_EQUIVALENT_TELEOPTI_RECORD="{call getNewInviteDataForTeleopti(?,?,?,?,?,?,?,?)}";
	public static final String getDateForTimesheet="{call getDateForTimesheet}";
	public static final String getPeoplesoftCode="{call getPeoplesoftCode}";
	public static final String generatePSoftData    = "{call generatePSoftData   (?,?)}";
	public static final String PEOPLE_SOFT_DATA_PUSH_TRACK = "{call PeoplesoftDataPushTrack (?,?,?,?,?,?,?)}"; 
	public static final String PEOPLE_SOFT_DATA_PUSH_TO_TEMP_TBL = "{call PeoplesoftDataPushFail (?,?,?,?,?,?,?,?)}"; 
	public static final String PS_PUSH_BUTTON_ENABLE_CHECK = "{call PeoplesoftPushButtonEnableCheck(?,?)}"; 
	public static final String CHECK_SCHEDULE_IN_TELEOPTI = "{call CheckScheduleInTeleopti(?,?,?,?,?,?)}";
	public static final String GET_EQUIVALENT_TELEOPTI_PERSON_ID = "{call CheckScheduleInTeleoptiWithAgentID(?,?,?,?,?,?)}";
	public static final String generateAgentShiftData  = "{call generateAgentShiftData (?,?)}";
	public static final String AgentAvayaActivities  = "{call AgentAvayaActivities (?,?)}";
	public static final String AgentLoginStats   = "{call AgentLoginStats  (?,?)}";
	public static final String getAgentScheduleForTimesheet   = "{call getAgentScheduleForTimesheet  (?,?)}";
	public static final String getProjection ="{call getProjection (?)}"; 
	public static final String GETTIMEOFFDETAIL ="{call getTimeOffDetail (?)}"; 
	public static final String getTeleoptiAgent_id ="{call getEmployeeIDForRemedyUser (?)}";
	public static final String GET_RECORDS_TO_LOAD_INTO_TELEOPTI ="{call MonetExceptionAbsence()}";
	public static final String CANCEL_TIMEOFF ="{call Cancel_TimeOff(?,?)}";
	public static final String GETCANCELLEDLEAVEDATATOTELEOPTI="{call getCancelledLeaveDataToTeleopti(?)}";
	
	public static final String GETOVERTIMEEXCEPTION="{call getOvertimeExceptions}";
	
	
}
