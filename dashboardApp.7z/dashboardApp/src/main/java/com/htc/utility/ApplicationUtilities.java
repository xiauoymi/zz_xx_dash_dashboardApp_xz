package com.htc.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

public class ApplicationUtilities {
	
	private static final Logger logger = Logger.getLogger(ApplicationUtilities.class);
	
	public static String month_year(String today) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		int mm = cal.get(Calendar.MONTH);
		mm= mm+1;
		int yyyy = cal.get(Calendar.YEAR);
		if (mm < 10) {
			today = yyyy + "-" + "0" + mm;
		} else {
			today = yyyy + "-" + mm;
		}
		return today;
	}

	public static String currentMonth_year() {
		String today="";
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		int mm = cal.get(Calendar.MONTH);
		mm= mm+1;
		int yyyy = cal.get(Calendar.YEAR);
		if (mm < 10) {
			today = yyyy + "-" + "0" + mm;
		} else {
			today = yyyy + "-" + mm;
		}
		return today;
	}

	public static Map<String, String> selMonthYear() {
		TreeMap<String, String> treeMap = new TreeMap<String, String>(Collections.reverseOrder());
		Calendar cal = Calendar.getInstance();
		int month = 0;
		int tempMonth = 0;
		String year_month = "";
		for (int i = 0; i <=12; i++) {
			cal.add(Calendar.MONTH, -1);
			month = cal.get(Calendar.MONTH);
			tempMonth = month + 1;
			if (tempMonth < 10) {
				year_month = cal.get(Calendar.YEAR) + "-" + "0" + tempMonth;
			} else {
				year_month = cal.get(Calendar.YEAR) + "-" + tempMonth;
			}
			String month1[] = { "January", "Febrauary", "March", "April", "May", "June", "July", "August", "September",
					"October", "November", "December" };
			treeMap.put(year_month, month1[month] + " " + cal.get(Calendar.YEAR));
		}
		return treeMap;
	}

	public static List<Integer> selYear() {
		List<Integer> list = new ArrayList<Integer>();
		Calendar cal = Calendar.getInstance();
		for (int i = 4; i > 0; i--) {
			//cal.add(Calendar.YEAR, -1);
			int year = cal.get(Calendar.YEAR);
			cal.add(Calendar.YEAR, -1);
			list.add(year);
		}
		return list;
	}

	public static String mtdMonthYear() {
		String today="";
		Calendar cal = Calendar.getInstance();
		int mm = cal.get(Calendar.MONTH)+1;
		int yyyy = cal.get(Calendar.YEAR);
		if (mm < 10) {
			today = yyyy + "-" + "0" + mm;
		} else {
			today = yyyy + "-" + mm;
		}
		today=today+"-01";
		return today;
	}
	public static Map<String, String> mtdSelMonthYear() {
		TreeMap<String, String> treeMap = new TreeMap<String, String>(Collections.reverseOrder());
		Calendar cal = Calendar.getInstance();
		int month = 0;
		int tempMonth = 0;
		String year_month = "";
		for (int i = 0; i <12; i++) {
			month = cal.get(Calendar.MONTH);
			tempMonth = month + 1;
			if (tempMonth < 10) {
				year_month = cal.get(Calendar.YEAR) + "-" + "0" + tempMonth;
			} else {
				year_month = cal.get(Calendar.YEAR) + "-" + tempMonth;
			}
			year_month = year_month+"-01";
			String month1[] = { "January", "Febrauary", "March", "April", "May", "June", "July", "August", "September",
					"October", "November", "December" };
			treeMap.put(year_month, month1[month] + " " + cal.get(Calendar.YEAR));
			cal.add(Calendar.MONTH, -1);
		}
		return treeMap;
	}

	public static Map<String, String> getWeakFirstDate() {
		TreeMap<String, String> treeMap = new TreeMap<String, String>(Collections.reverseOrder());
		Calendar cal = Calendar.getInstance();
		int month = 0;
		String month1[] = { "January", "Febrauary", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };
		month=cal.get(Calendar.MONTH)-1;
		Date date = new Date();
		cal.setTime(date);
		int i = cal.get(Calendar.DAY_OF_WEEK) - cal.getFirstDayOfWeek();
		cal.add(Calendar.DATE, -i - 7);
		Date start = cal.getTime();
		cal.add(Calendar.DATE, 6);

		SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
		treeMap.put("mnth-year", month1[month]+" "+cal.get(Calendar.YEAR) );
		treeMap.put("yy-mm-dd", dt1.format(start) );


		return treeMap;
	}
	
	public static String currentCalMonth_year() {
		String today="";
		Calendar cal = Calendar.getInstance();
		int mm = cal.get(Calendar.MONTH)+1;
		int yyyy = cal.get(Calendar.YEAR);
		if (mm < 10) {
			today = yyyy + "" + "0" + mm;
		} else {
			today = yyyy + "" + mm;
		}
		
		return today;
	}
	
	public static Map<String, String> currentcalMnthAndyr() {
		TreeMap<String, String> treeMap = new TreeMap<String, String>(Collections.reverseOrder());
		Calendar cal = Calendar.getInstance();
		int month = 0;
		int tempMonth = 0;
		String year_month = "";
		for (int i = 0; i <12; i++) {
			month = cal.get(Calendar.MONTH);
			tempMonth = month + 1;
			if (tempMonth < 10) {
				year_month = cal.get(Calendar.YEAR) + "" + "0" + tempMonth;
			} else {
				year_month = cal.get(Calendar.YEAR) + "" + tempMonth;
			}
			year_month = year_month;
			String month1[] = { "January", "Febrauary", "March", "April", "May", "June", "July", "August", "September",
					"October", "November", "December" };
			treeMap.put(year_month, month1[month] + " " + cal.get(Calendar.YEAR));
			cal.add(Calendar.MONTH, -1);
		}
		return treeMap;
	}
	
	public static List<String> getFullCalendar() {
		List<String> fullCalendar=new ArrayList<>();
		
		
		String month1[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
				"Oct", "Nov", "Dec" };
		Calendar cal = Calendar.getInstance();
		   int mnth=cal.get(Calendar.MONTH);
		   int year=cal.get(Calendar.YEAR);
		   
	    
	    
	    int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	    SimpleDateFormat df = new SimpleDateFormat("MMM");
	    for (int i = 1; i <=maxDay; i++) {
	    	if (i < 10) {
	    		fullCalendar.add(year+"-"+month1[mnth]+"-0"+i);
			} else{
				fullCalendar.add(year+"-"+month1[mnth]+"-"+i);
			}
	    	
	    }

		
		return fullCalendar;
	}
	
	/**
	 * Convert String to java Util Date 
	 * @param stringDate
	 * @param format
	 * @return Util Date
	 */
	public static Date stringToUtilDate(String stringDate, String format){
		logger.info("Inside stringToUtilDate(String stringDate, String format)");
		try {
			
			DateFormat formatter = new SimpleDateFormat(format);		
			return formatter.parse(stringDate);
			
		} catch (ParseException e) {			
			logger.error(e.getMessage(), e);
		}
		logger.info("Inside stringToUtilDate(Exit stringDate, String format)");
		return null;	
		
	}

}