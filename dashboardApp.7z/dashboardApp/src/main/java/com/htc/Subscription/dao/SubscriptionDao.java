package com.htc.Subscription.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.utility.StoredProcedureConstants;

public class SubscriptionDao {
	private static final Logger logger = Logger
			.getLogger(SubscriptionDao.class);
	
	DataSource dataSource;

	

	public void setBeaumont(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public StringBuilder getSDMetricsReportTree(String FilterType)
			throws SQLException, NamingException {
		logger.info("SD Metrics Report Tree Structure from DB starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMetricsTreequery = "";
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			sdMetricsTreequery = StoredProcedureConstants.sp_client_tree;
			callableStatement = connection.prepareCall(sdMetricsTreequery);
			callableStatement.setString(1, FilterType);
			callableStatement.setString(2, "");
			callableStatement.setString(3, "");
			resultSet = callableStatement.executeQuery();

			while (resultSet.next()) {
				builder.append("{id:'" + resultSet.getString(2) + "',parent:'");
				if (resultSet.getString(1).equalsIgnoreCase("Clients")) {
					builder.append("#',text:");
				} else
					builder.append(resultSet.getString(1) + "',text:");
				String SDM_org_lbl = resultSet.getString(3).replace("\n", " ");
				SDM_org_lbl = SDM_org_lbl.replace("'", "");
				builder.append("'" + SDM_org_lbl + "',");
				builder.append("'state' : {checkbox_disabled : true, checked :"
						+ resultSet.getString(4).toLowerCase() + "} },");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics Report Tree Structure from DB Ends");
		return builder;
	}
}
