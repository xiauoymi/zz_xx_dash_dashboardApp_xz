package com.htc.Subscription.Controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.htc.monthEnd.dao.SDMetricsReportDAO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;

/*
 * HTC_Offshore
 * purpose: return  NYHHTable DataSet
 * */

@Controller
public class SubsciptionController {

	
	@Autowired
	SDMetricsReportDAO sdMetricsReportDAO;
	@SuppressWarnings("unused")
	private static final Logger logger = Logger
			.getLogger(SubsciptionController.class);

	@RequestMapping(value = "/subscription", method = RequestMethod.GET)
	public String getSubscription(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		
		String userName = (String) session.getAttribute("username");
		String month = request.getParameter("options");
		String clickedClient="";
		String reportId="";
		
		clickedClient=request.getParameter("clickedClient");
		reportId=request.getParameter("reportId");


		String filterType = request.getParameter("FilterType");

		if (null == filterType || "".equals(filterType)) {
			filterType = "";
		}
		if (userName != null && !("".equals(userName))) {
			StringBuilder sdMetricsReportTree = new StringBuilder();
			Map<String, List<?>> notSentReportAndCountMap = new LinkedHashMap<String, List<?>>();
			List<Object> reportCount = new ArrayList<>();
			try {
				logger.info("Get SD Metrics Report Tree Structure : Before ");
				sdMetricsReportTree = sdMetricsReportDAO
						.getSDMetricsReportTree(filterType);
				logger.info("Get SD Metrics Report Tree Structure : After ");

			} catch (Exception e) {
				logger.info("Exception arise while Getting SD Metrics Report Tree");
				throw new Exception(DashboardConstants.SQL_EXCEPTION);
			}
			if ("".equals(sdMetricsReportTree)) {
				logger.info("No Tree Structure For SD Metrics Report");
			} else {
				request.setAttribute("SUBSCRIPTIONTREE", sdMetricsReportTree);
				logger.info("Tree Structure For SD Metrics Report are available::--> "
						+ sdMetricsReportTree);
			}
			
			return "subscription/subscription";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}
		
		

	

}
