package com.htc.monthEnd.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.internet.MimeMessage;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.htc.monthEnd.dao.SDMetricsReportDAO;
import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;

@Controller
public class SDMetricsReportController {

	@Autowired
	SDMetricsReportDAO sdMetricsReportDAO;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	SDMetricsReportDAO sdMetricsReportRollup;

	@Autowired
	SDMetricsReportDAO sdMetricsReportsAAATable;

	private static final Logger logger = Logger
			.getLogger(SDMetricsReportController.class);

	@RequestMapping(value = "/SDMetricsReport", method = RequestMethod.GET)
	public String SDMetricsReportTree(ModelMap model, HttpSession session,
			HttpServletRequest request) throws Exception {

		String userName = (String) session.getAttribute("username");
		String month = request.getParameter("options");
		String clickedClient="";
		String reportId="";
		
		clickedClient=request.getParameter("clickedClient");
		reportId=request.getParameter("reportId");


		String filterType = request.getParameter("FilterType");

		if (null == filterType || "".equals(filterType)) {
			filterType = "";
		}
		if (userName != null && !("".equals(userName))) {
			StringBuilder sdMetricsReportTree = new StringBuilder();
			Map<String, List<?>> notSentReportAndCountMap = new LinkedHashMap<String, List<?>>();
			List<Object> reportCount = new ArrayList<>();
			try {
				logger.info("Get SD Metrics Report Tree Structure : Before ");
				sdMetricsReportTree = sdMetricsReportDAO
						.getSDMetricsReportTree(filterType);
				logger.info("Get SD Metrics Report Tree Structure : After ");

				if (null == month) {
					month = ApplicationUtilities.currentCalMonth_year();
				}
				logger.info("Get SD Metrics not sentbreport and count  : Before ");
				notSentReportAndCountMap = sdMetricsReportDAO
						.getNotSentReportsAndCount(month);
				logger.info("Get SD Metrics not sentbreport and count : After ");

				logger.info("Get SD Metrics not sentbreport and count  : Before ");
				reportCount = sdMetricsReportDAO.getReportsCount(month);
				logger.info("Get SD Metrics not sentbreport and count : After ");
				session.setAttribute("datePicker", month);
			} catch (Exception e) {
				logger.info("Exception arise while Getting SD Metrics Report Tree");
				throw new Exception(DashboardConstants.SQL_EXCEPTION);
			}
			if ("".equals(sdMetricsReportTree)) {
				logger.info("No Tree Structure For SD Metrics Report");
			} else {
				request.setAttribute("SDMETRICSREPORTTREE", sdMetricsReportTree);
				logger.info("Tree Structure For SD Metrics Report are available::--> "
						+ sdMetricsReportTree);
			}
			request.setAttribute("SDMETRICSNOTSENTREPORTANDCOUNT",
					notSentReportAndCountMap);
			logger.info("SDMETRICSNOTSENTREPORTANDCOUNT are available::--> "
					+ notSentReportAndCountMap);
			request.setAttribute("SDMETRICSREPORTANDCOUNT", reportCount);
			request.setAttribute("FILTERBY", filterType);
			request.setAttribute("CLICKEDCLIENT", clickedClient);
			request.setAttribute("REPORTID", reportId);
			logger.info("SDMETRICSCOUNT are available::--> " + reportCount);
			return "monthEnd/SDMetricsReport";
		} else {
			return "common/UnAuthoriseAccess";
		}
	}

	@RequestMapping(value = "/rollReportDetail", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Map<String, Map<String, List<?>>> rollReportDetails(ModelMap model,
			HttpSession session, HttpServletRequest request,
			HttpServletResponse response) throws Exception

	{
		String reportID = "";
		String client = "";
		reportID = request.getParameter("reportid");
		client = request.getParameter("Client");

		Map<String, List<?>> rollupsReportDetailMap = new HashMap<>();
		Map<String, List<?>> sdMetricsAAATableDetailMap = new HashMap<>();
		Map<String, Map<String, List<?>>> sdMetricRollupandAAATable = new HashMap<String, Map<String, List<?>>>();

		List<String> rollUpReport = new ArrayList<String>();
		try {
			logger.info("Get SD Metrics rollup Detail : Before ");
			rollUpReport = sdMetricsReportDAO.getRollUpIDs(reportID);
			logger.info("Get SD Metrics rollup Detail : After ::-->"
					+ rollUpReport);

			sdMetricsAAATableDetailMap = sdMetricsReportsAAATable
					.getAAATable(client);
			logger.info("Get SD Metrics AAA Table Detail : After ::-->"
					+ sdMetricsAAATableDetailMap);
		} catch (Exception e) {
			logger.info("Exception arise while Getting SD Metrics rollup Detail");
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}

		for (String rollup : rollUpReport) {
			if (rollup.equals(reportID)) {

				rollupsReportDetailMap = rollUpDeails(client);

			}

		}

		if (null != rollupsReportDetailMap) {
			session.setAttribute(DashboardConstants.ROLLUP_CLIENT_DATA,
					rollupsReportDetailMap);
		}
		sdMetricRollupandAAATable.put("sdMetricsRollupDetail",
				rollupsReportDetailMap);
		sdMetricRollupandAAATable.put("sdMetricsAAATableDetail",
				sdMetricsAAATableDetailMap);

		return sdMetricRollupandAAATable;

	}

	@RequestMapping(value = "/SDMetricsReportDetail", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Map<String, Map<String, List<?>>> SDMetricsReportDetails(
			ModelMap model, HttpSession session, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String reportID = "";
		String Client = "";
		reportID = request.getParameter("reportid");
		Client = request.getParameter("Client");
		Map<String, List<?>> sdMetricsReportDetailMap = new HashMap<>();
		Map<String, List<?>> sdMetricsAAATableDetailMap = new HashMap<>();
		Map<String, Map<String, List<?>>> sdMetricReportandAAATable = new HashMap<String, Map<String, List<?>>>();
		try {
			logger.info("Get SD Metrics Report Detail : Before ");
			sdMetricsReportDetailMap = sdMetricsReportDAO
					.getSDMetricsReportDeatil(reportID);
			sdMetricReportandAAATable.put("sdMetricsReportDetail",
					sdMetricsReportDetailMap);
			logger.info("Get SD Metrics Report Detail : After ::-->"
					+ sdMetricsReportDetailMap);
			sdMetricsAAATableDetailMap = sdMetricsReportsAAATable
					.getAAATable(Client);
			logger.info("Get SD Metrics AAA Table Detail : After ::-->"
					+ sdMetricsAAATableDetailMap);
			sdMetricReportandAAATable.put("sdMetricsAAATableDetail",
					sdMetricsAAATableDetailMap);
		} catch (Exception e) {
			logger.info("Exception arise while Getting SD Metrics Report Details");
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return sdMetricReportandAAATable;
	}

	private Map<String, List<?>> rollUpDeails(String reportID) throws Exception {
		// TODO Auto-generated method stub
		Map<String, List<?>> rollupsReportDetailMap = new HashMap<>();
		try {
			logger.info("Get SD Metrics Report Detail : Before ");
			rollupsReportDetailMap = sdMetricsReportRollup
					.getSDMetricsRollupDeatil(reportID);
			logger.info("Get SD Metrics Report Detail : After ::-->"
					+ rollupsReportDetailMap);
		} catch (Exception e) {
			logger.info("Exception arise while Getting SD Metrics Report Details");
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}

		return rollupsReportDetailMap;
	}

	@RequestMapping(value = "/mailSend", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> sendEmail(HttpServletRequest request,
			HttpSession session, MultipartHttpServletRequest requestFile)
			throws Exception {
		List<String> status = new ArrayList<String>();

		final MultiValueMap<String, MultipartFile> attachMap = requestFile
				.getMultiFileMap();
		// reads form input
		String userName = (String) session.getAttribute("username");
		String emailTo = request.getParameter("emails");
		String subject = request.getParameter("subject");
		String message = request.getParameter("message");
		String path = request.getParameter("attachments");
		String reportNames = request.getParameter("reportNames");
		final String mailCc = request.getParameter("cc");
		final String mailBcc = request.getParameter("bcc");
		final String[] browsedAttachments=reportNames.split(",");

		if (reportNames.contains("&amp;")) {
			reportNames = reportNames.replace("&amp;", "&");
		}

		if (message.contains("&amp;")) {
			message = message.replace("&amp;", "&");
		}
		if (subject.contains("&amp;")) {
			subject = subject.replace("&amp;", "&");
		}
		if (path.contains("&amp;")) {
			path = path.replace("&amp;", "&");
		}

		final String[] emailIds = emailTo.split(",");

		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();
		InputStream input = classLoader
				.getResourceAsStream("EmailProperties.properties");
		final Properties p = new Properties();
		p.load(input);

		try {

			final String messageAmp = message;
			final String subjectAmp = subject;
			final String pathAmp = path;
			mailSender.send(new MimeMessagePreparator() {

				@Override
				public void prepare(MimeMessage mimeMessage) throws Exception {

					MimeMessageHelper messageHelper = new MimeMessageHelper(
							mimeMessage, true, "UTF-8");

					messageHelper.setFrom(p
							.getProperty("SDMETRICS_FROM_MAIL_ADDRESS"));
					for (int i = 0; i < emailIds.length; i++) {
						messageHelper.addTo(emailIds[i]);
					}

					if (!"".equals(mailCc) && null != mailCc) {
						final String[] mailCclist = mailCc.split(";");
						for (String ccmail : mailCclist) {
							messageHelper.addCc(ccmail);
						}
					}
					if (!"".equals(mailBcc) && null != mailBcc) {
						final String[] mailBCclist = mailBcc.split(";");
						for (String bccmail : mailBCclist) {
							messageHelper.addBcc(bccmail);
						}
					}
					messageHelper.setSubject(subjectAmp);
					messageHelper.setText(messageAmp);

					// determines if there is an upload file, attach it to the
					// e-mail
					//String attachName = attachFile.getOriginalFilename();
					for (Map.Entry<String, List<MultipartFile>> entry : attachMap
							.entrySet()) {
						final List<MultipartFile> multipartFile1 = entry
								.getValue();
						final MultipartFile attachMultipart = multipartFile1
								.get(0);
						String attachName = attachMultipart
								.getOriginalFilename();

						if (!multipartFile1.equals("")) {

							
							 for(String bAttachmentName:browsedAttachments){
							 
							 
							 if(bAttachmentName.trim().equals(attachName.trim()
							  )){
							 

							messageHelper.addAttachment(attachName,
									new InputStreamSource() {

										@Override
										public InputStream getInputStream()
												throws IOException {
											return attachMultipart
													.getInputStream();
										}
									});
						}
						
						 } }
						 

					}
					if (null != pathAmp && !pathAmp.equals("")) {
						final String[] attachments = pathAmp.split(",");
						for (int i = 0; i < attachments.length; i++) {
							try {
								FileSystemResource file = new FileSystemResource(
										attachments[i]);
								messageHelper.addAttachment(file.getFilename(),
										file);
							} catch (Exception e) {
								logger.info("Exception arise while searchinng file in particular directory: "
										+ e.getMessage());
								throw new Exception(
										DashboardConstants.FILE_NOT_FOUND_EXCEPTION);
							}
						}
					}
				}

			});
		} catch (Exception e) {
			logger.info("Exception arise while sending emails to client: "
					+ e.getMessage());
			throw new Exception(DashboardConstants.INVALID_EMAIL_EXCEPTION);
		}

		try {
			sdMetricsReportDAO.insertReportEmailDetail(reportNames, emailTo,
					userName);
		} catch (Exception e) {
			logger.info("inserting transation table : Exception raised report sent email details::->"
					+ " filename= "
					+ path
					+ " EmailIDS= "
					+ emailTo
					+ " Username" + userName);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);

		}
		logger.info("Report details inserted to DB successfully: After");
		status.add("0");
		status.add("Thank you, mail sent successfully");

		return status;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/sdMetricsMails", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody
	Map<String, List<?>> getMails(@RequestParam("treeid") String reportId,
			@RequestParam("reportNamess") String reportNames, ModelMap model,
			HttpSession session, HttpServletRequest request) throws Exception {

		if (reportId.equals("") || null == reportId) {
			reportId = "";
		}

		reportNames = URLDecoder.decode(reportNames,
				StandardCharsets.UTF_8.toString());
		if (reportNames.equals("") || null == reportNames) {
			reportNames = "";
		}
		if (reportNames.contains("&amp;")) {
			reportNames = reportNames.replace("&amp;", "&");
		}

		if (reportNames.contains("&acirc;&#128;&#147;")) {
			reportNames = reportNames.replace("&acirc;&#128;&#147;", "-");
		}
		logger.info("reportNames-----" + reportNames);
		Map<String, List<?>> getMailList = new HashMap<String, List<?>>();
		try {
			getMailList = sdMetricsReportDAO.getMails(reportId, reportNames);
			logger.info("getMailList-----" + getMailList);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}

		if (null != session.getAttribute(DashboardConstants.ROLLUP_CLIENT_DATA)) {
			Map<String, List<?>> rollupsReportDetailMap = new HashMap<>();
			rollupsReportDetailMap = (Map<String, List<?>>) session
					.getAttribute(DashboardConstants.ROLLUP_CLIENT_DATA);
			getMailList.put(DashboardConstants.SDMETRICSCOLUMNNAME,
					rollupsReportDetailMap
							.get(DashboardConstants.SDMETRICSCOLUMNNAME));
			getMailList.put(DashboardConstants.SDMETRICSCOLUMNVALUE,
					rollupsReportDetailMap
							.get(DashboardConstants.SDMETRICSCOLUMNVALUE));

		}
		return getMailList;
	}

	@RequestMapping(value = "/addNewMail", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody
	List<String> insertMail(@RequestParam("newClientMail") String mailId,
			@RequestParam("subject") String subject, ModelMap model,
			HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status = new ArrayList<String>();
		String userName = (String) session.getAttribute("username");

		if (mailId.equals("") || null == mailId) {
			mailId = "";
		}
		subject = URLDecoder.decode(subject, StandardCharsets.UTF_8.toString());
		if (subject.contains("&amp;")) {
			subject = subject.replace("&amp;", "&");
		}
		logger.info("newMailId-----" + mailId);
		logger.info("subject-----" + subject);
		logger.info("user-----" + userName);
		try {
			status = sdMetricsReportDAO
					.insertNewMail(mailId, subject, userName);
			logger.info("status-----" + status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return status;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/mailSendRollup", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public List<String> sendEmailRollUp(HttpServletRequest request,
			HttpSession session, MultipartHttpServletRequest requestFile)
			throws Exception {
		List<String> status = new ArrayList<String>();

		final MultiValueMap<String, MultipartFile> attachMap = requestFile
				.getMultiFileMap();
		// reads form input
		String userName = (String) session.getAttribute("username");
		String emailTo = request.getParameter("emails");
		String subject = request.getParameter("subject");
		String message = request.getParameter("message");
		String path = request.getParameter("attachments");
		String reportNames = request.getParameter("reportNames");
		String fileNameRoll = request.getParameter("fileNameRoll");
		final String mailCc = request.getParameter("cc");
		final String mailBcc = request.getParameter("bcc");
		final String[] browsedAttachments=reportNames.split(",");

		if (reportNames.contains("&amp;")) {
			reportNames = reportNames.replace("&amp;", "&");
		}

		StringBuffer messegetext = new StringBuffer();

		if (fileNameRoll.contains("&amp;")) {
			fileNameRoll = fileNameRoll.replace("&amp;", "&");
		}

		if (message.contains("&amp;")) {
			message = message.replace("&amp;", "&");

		} else {

			if (null != session
					.getAttribute(DashboardConstants.ROLLUP_CLIENT_DATA)) {
				Map<String, List<?>> rollupsReportDetailMap = new HashMap<>();
				rollupsReportDetailMap = (Map<String, List<?>>) session
						.getAttribute(DashboardConstants.ROLLUP_CLIENT_DATA);
				rollupsReportDetailMap = (Map<String, List<?>>) session
						.getAttribute(DashboardConstants.ROLLUP_CLIENT_DATA);
				List<String> column = new ArrayList();
				List rollvalues = new ArrayList();
				column = (List<String>) rollupsReportDetailMap
						.get(DashboardConstants.SDMETRICSCOLUMNNAME);
				rollvalues = rollupsReportDetailMap
						.get(DashboardConstants.SDMETRICSCOLUMNVALUE);
				messegetext.append("<table  border=\"1\"><thead><tr>");
				for (int i = 0; i < column.size(); i++) {
					String colname = (String) column.get(i);
					messegetext.append("<th align='left'>" + colname + "</th>");
				}
				messegetext.append("</tr></thead><tbody>");
				for (int j = 0; j < rollvalues.size(); j++) {
					messegetext.append("<tr>");
					List<String> rollvalues1 = new ArrayList();
					rollvalues1 = (List) rollvalues.get(j);
					for (int k = 0; k < rollvalues1.size(); k++) {

						if (rollvalues1.get(k).equals("Total Contacts")) {
							messegetext.append("<td> <strong>"
									+ rollvalues1.get(k) + "</strong></td>");
						} else {
							messegetext.append("<td>" + rollvalues1.get(k)
									+ "</td>");
						}
					}
					messegetext.append("</tr>");
				}

				messegetext.append("</tbody></table>");
			}

			message = messegetext.toString();

		}

		if (subject.contains("&amp;")) {
			subject = subject.replace("&amp;", "&");
		}
		if (path.contains("&amp;")) {
			path = path.replace("&amp;", "&");
		}

		final String[] emailIds = emailTo.split(",");

		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();
		InputStream input = classLoader
				.getResourceAsStream("EmailProperties.properties");
		final Properties p = new Properties();
		p.load(input);

		try {

			final String messageAmp = message;
			final String subjectAmp = subject;
			final String pathAmp = path;
			mailSender.send(new MimeMessagePreparator() {

				@Override
				public void prepare(MimeMessage mimeMessage) throws Exception {

					MimeMessageHelper messageHelper = new MimeMessageHelper(
							mimeMessage, true, "UTF-8");

					messageHelper.setFrom(p
							.getProperty("SDMETRICS_FROM_MAIL_ADDRESS"));
					for (int i = 0; i < emailIds.length; i++) {
						messageHelper.addTo(emailIds[i]);
					}
					if (!"".equals(mailCc) && null != mailCc) {
						final String[] mailCclist = mailCc.split(";");
						for (String ccmail : mailCclist) {
							messageHelper.addCc(ccmail);
						}
					}
					if (!"".equals(mailBcc) && null != mailBcc) {
						final String[] mailBCclist = mailBcc.split(";");
						for (String bccmail : mailBCclist) {
							messageHelper.addBcc(bccmail);
						}
					}
					messageHelper.setSubject(subjectAmp);
					messageHelper.setText(messageAmp, true);

					// determines if there is an upload file, attach it to the
					// e-mail
					 //String attachName = attachFile.getOriginalFilename();
					for (Map.Entry<String, List<MultipartFile>> entry : attachMap
							.entrySet()) {
						final List<MultipartFile> multipartFile1 = entry
								.getValue();
						final MultipartFile attachMultipart = multipartFile1
								.get(0);
						String attachName = attachMultipart
								.getOriginalFilename();
						if (!multipartFile1.equals("")) {

							
							 for(String bAttachmentName:browsedAttachments){
							 
							 
							  if(bAttachmentName.trim().equals(attachName.trim()
							  )){
							 

							messageHelper.addAttachment(attachName,
									new InputStreamSource() {

										@Override
										public InputStream getInputStream()
												throws IOException {
											return attachMultipart
													.getInputStream();
										}
									});
							
							  } }
							 
						}
					}
					if (null != pathAmp && !pathAmp.equals("")) {
						final String[] attachments = pathAmp.split(",");
						for (int i = 0; i < attachments.length; i++) {
							try {
								FileSystemResource file = new FileSystemResource(
										attachments[i]);
								messageHelper.addAttachment(file.getFilename(),
										file);
							} catch (Exception e) {
								logger.info("Exception arise while searchinng file in particular directory: "
										+ e.getMessage());
								throw new Exception(
										DashboardConstants.FILE_NOT_FOUND_EXCEPTION);
							}
						}
					}
				}

			});
		} catch (Exception e) {
			logger.info("Exception arise while sending emails to client: "
					+ e.getMessage());
			throw new Exception(DashboardConstants.INVALID_EMAIL_EXCEPTION);
		}

		try {
			sdMetricsReportDAO.insertReportEmailDetail(fileNameRoll, emailTo,
					userName);
		} catch (Exception e) {
			logger.info("inserting transation table : Exception raised report sent email details::->"
					+ " filename= "
					+ path
					+ " EmailIDS= "
					+ emailTo
					+ " Username" + userName);
			throw new Exception(DashboardConstants.SQL_EXCEPTION);

		}
		logger.info("Report details inserted to DB successfully: After");
		status.add("0");
		status.add("Thank you, mail sent successfully");

		return status;
	}

	@RequestMapping(value = "/deleteEmail", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody
	List<String> deleteMail(
			@RequestParam("removeClientMail") String removeMailId,
			@RequestParam("subject") String subject, ModelMap model,
			HttpSession session, HttpServletRequest request) throws Exception {

		List<String> status = new ArrayList<String>();
		String userName = (String) session.getAttribute("username");

		if (removeMailId.equals("") || null == removeMailId) {
			removeMailId = "";
		}
		subject = URLDecoder.decode(subject, StandardCharsets.UTF_8.toString());

		logger.info("newMailId-----" + removeMailId);
		logger.info("subject-----" + subject);
		logger.info("user-----" + userName);
		try {
			status = sdMetricsReportDAO.deleteMail(removeMailId, subject,
					userName);
			logger.info("status-----" + status);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new Exception(DashboardConstants.SQL_EXCEPTION);
		}
		return status;
	}

	@RequestMapping(value = "/downloadSDMetricsReport", method = RequestMethod.GET)
	public @ResponseBody
	void downloadDocs(ModelMap model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		String fileName = request.getParameter("filePath");
		ServletOutputStream sos;
		fileName = URLDecoder.decode(fileName,
				StandardCharsets.UTF_8.toString());
		File f = new File(fileName);
		FileInputStream istr = new FileInputStream(f);
		BufferedInputStream bstr = new BufferedInputStream(istr);
		int size = (int) f.length(); // get the file size (in bytes)
		byte[] data = new byte[size];
		bstr.read(data, 0, size); // read into byte array
		bstr.close();
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ fileName + "\"");
		sos = response.getOutputStream();
		sos.write(data);
		sos.flush();
		sos.close();

	}

	@RequestMapping(value = "/downloadZipSDMetricsReport", method = RequestMethod.GET)
	public @ResponseBody
	void downloadZip(ModelMap model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		String fileName = request.getParameter("filePath");
		String clickedClient = request.getParameter("clickedClient");
		fileName = URLDecoder.decode(fileName,
				StandardCharsets.UTF_8.toString());
		String fileArray[] = fileName.split(",");
		// Set the response type and specify the boundary string
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		response.setContentType("Content-type: text/zip");
		response.setHeader("Content-Disposition", "attachment; filename="
				+ clickedClient + "(" + dateFormat.format(date) + ").zip");

		// List of files to be downloaded
		List<File> files = new ArrayList<File>();
		for (int i = 0; i < fileArray.length; i++) {
			files.add(new File(fileArray[i].toString()));
		}

		ServletOutputStream out = response.getOutputStream();
		ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(out));

		for (File file : files) {

			logger.info("Adding " + file.getName());
			zos.putNextEntry(new ZipEntry(file.getName()));

			// Get the file
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);

			} catch (FileNotFoundException fnfe) {
				// If the file does not exists, write an error entry instead of
				// file
				// contents
				zos.write(("ERRORld not find file " + file.getName())
						.getBytes());
				zos.closeEntry();
				logger.info("Couldfind file " + file.getAbsolutePath());
				continue;
			}

			BufferedInputStream fif = new BufferedInputStream(fis);

			// Write the contents of the file
			int data = 0;
			while ((data = fif.read()) != -1) {
				zos.write(data);
			}
			fif.close();

			zos.closeEntry();
			logger.info("Finishedng file " + file.getName());
		}

		zos.close();
	}

}
