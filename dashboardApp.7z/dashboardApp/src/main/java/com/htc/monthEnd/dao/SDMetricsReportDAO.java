package com.htc.monthEnd.dao;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.htc.utility.ApplicationUtilities;
import com.htc.utility.DashboardConstants;
import com.htc.utility.QueryBuilder;
import com.htc.utility.StoredProcedureConstants;

public class SDMetricsReportDAO {

	private static final Logger logger = Logger
			.getLogger(SDMetricsReportDAO.class);

	DataSource dataSource;

	DataSource datasourceSdm;
	DataSource datasourceBi;

	public void setBeaumont(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void setDataSource(DataSource datasourceSdm) {
		this.datasourceSdm = datasourceSdm;
	}

	public void setDataSourceBi(DataSource datasourceBi) {
		this.datasourceBi = datasourceBi;
	}

	public StringBuilder getSDMetricsReportTree(String FilterType)
			throws SQLException, NamingException {
		logger.info("SD Metrics Report Tree Structure from DB starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMetricsTreequery = "";
		StringBuilder builder = new StringBuilder();
		try {
			connection = dataSource.getConnection();
			sdMetricsTreequery = StoredProcedureConstants.sp_client_tree;
			callableStatement = connection.prepareCall(sdMetricsTreequery);
			callableStatement.setString(1, FilterType);
			callableStatement.setString(2, "");
			callableStatement.setString(3, "");
			resultSet = callableStatement.executeQuery();

			while (resultSet.next()) {
				builder.append("{id:'" + resultSet.getString(2) + "',parent:'");
				if (resultSet.getString(1).equalsIgnoreCase("Clients")) {
					builder.append("#',text:");
				} else
					builder.append(resultSet.getString(1) + "',text:");
				String SDM_org_lbl = resultSet.getString(3).replace("\n", " ");
				SDM_org_lbl = SDM_org_lbl.replace("'", "");
				builder.append("'" + SDM_org_lbl + "',");
				builder.append("'state' : {checkbox_disabled : true, checked :"
						+ resultSet.getString(4).toLowerCase() + "} },");
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics Report Tree Structure from DB Ends");
		return builder;
	}

	public Map<String, List<?>> getSDMetricsReportDeatil(String reportID)
			throws SQLException, NamingException {

		logger.info("SD Metrics Report Detail from DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMtericsDetailquery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> ClientReportCountMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		long fileSize = 0;
		try {
			connection = dataSource.getConnection();
			sdMtericsDetailquery = StoredProcedureConstants.sp_Report_Send_Details_Report;
			callableStatement = connection.prepareCall(sdMtericsDetailquery);
			callableStatement.setString(1, reportID);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));

					if ("FilePath".equalsIgnoreCase(reportDescriptionList
							.get(i))) {
						File file = new File(getColumnVal);
						// Get length of file in bytes
						long fileSizeInBytes = file.length();
						logger.info("fileSizeIn Bytes---" + fileSizeInBytes);
						fileSize = fileSizeInBytes;
					}
					if ("FileSizeInBytes"
							.equalsIgnoreCase(reportDescriptionList.get(i))) {
						if (null == getColumnVal) {
							getColumnVal = fileSize + "";
							fileSize = 0;
						}
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			ClientReportCountMap.put(DashboardConstants.SDMETRICSCOLUMNNAME,
					reportDescriptionList);
			ClientReportCountMap.put(DashboardConstants.SDMETRICSCOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics Report Detail from DB Ends");
		return ClientReportCountMap;
	}

	public void insertReportEmailDetail(String reportName, String emailId,
			String userId) throws SQLException, NamingException {

		logger.info("Insert Report Detail into DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		List<String> resultMsg = new ArrayList<String>();
		String insrtReportEmlDtlQry = "";
		insrtReportEmlDtlQry = StoredProcedureConstants.sp_Insert_Report_Send_Status;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(insrtReportEmlDtlQry);
			callableStatement.setString(1, reportName);
			callableStatement.setString(2, emailId);
			callableStatement.setString(3, "1");
			callableStatement.setString(4, userId);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg.add(resultSet.getString(1));
				logger.info("Report detail is inserted into DB or not ? ::--> "
						+ resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("Insert Report Detail into DB Ends");
	}

	@SuppressWarnings("rawtypes")
	public Map<String, List<?>> getMails(String reportID, String reportName)
			throws SQLException, NamingException {

		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMtericsDetailquery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		List<String> emailList = new ArrayList<String>();
		List<String> subject = null;
		LinkedHashMap<String, List<?>> ClientReportCountMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		List<String> filnameList = new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			sdMtericsDetailquery = StoredProcedureConstants.sp_Send_Mail;
			callableStatement = connection.prepareCall(sdMtericsDetailquery);
			callableStatement.setString(1, reportID);
			callableStatement.setString(2, reportName);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				subject = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if ("EMail_Address".equalsIgnoreCase(reportDescriptionList
							.get(i))) {
						emailList.add(getColumnVal);
					} else if ("Subject".equalsIgnoreCase(reportDescriptionList
							.get(i))) {
						subject.add(getColumnVal);
					}

					cellList.add(getColumnVal);
				}
				filnameList.add(resultSet.getString("FileName"));
				reportList.add(cellList);
			}

			List deduped = emailList.stream().distinct()
					.collect(Collectors.toList());
			ClientReportCountMap.put(DashboardConstants.SDMETRICGETMAILDETAILS,
					deduped);
			ClientReportCountMap.put(DashboardConstants.SUBJECT, subject);
			ClientReportCountMap.put(DashboardConstants.ROLLUP_FILENAME,
					filnameList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}

		return ClientReportCountMap;
	}

	public List<String> insertNewMail(String mailId, String subject, String user)
			throws SQLException, NamingException {

		logger.info("Insert mail Detail into DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		List<String> resultMsg = new ArrayList<String>();
		String insrtReportEmlDtlQry = "";
		insrtReportEmlDtlQry = StoredProcedureConstants.sp_Insert_New_EMailAddress;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(insrtReportEmlDtlQry);
			callableStatement.setString(1, mailId);
			callableStatement.setString(2, subject);
			callableStatement.setString(3, user);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg.add(resultSet.getString(1));
				resultMsg.add(resultSet.getString(2));
				logger.info("mail detail is inserted into DB or not ? ::--> "
						+ resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("Insert mail Detail into DB Ends");
		return resultMsg;
	}

	public List<String> getRollUpIDs(String reportID) throws SQLException,
			NamingException {
		logger.info("SD Metrics Rollupids from DB starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		String sdMetricsRollup = "";
		List<String> rollUpReport = new ArrayList<String>();
		try {
			connection = dataSource.getConnection();
			sdMetricsRollup = StoredProcedureConstants.sp_get_Rollup_Reports;
			callableStatement = connection.prepareCall(sdMetricsRollup);
			resultSet = callableStatement.executeQuery();

			while (resultSet.next()) {

				rollUpReport.add(resultSet.getString("Mail_Subject_ID").trim());

			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics Rollupids from DB startsEnds");
		return rollUpReport;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String, List<?>> getSDMetricsRollupDeatil(String reportID)
			throws SQLException, NamingException {
		// TODO Auto-generated method stub
		logger.info("SD Metrics Report Detail from DB Starts");
		Connection connection = null;
		ResultSet resultSet = null;
		CallableStatement callableStatement = null;

		String query = "";
		List reportList = new ArrayList();
		List<String> reportDescriptionList = new ArrayList<String>();

		LinkedHashMap<String, List<?>> ClientReportCountMap = new LinkedHashMap<String, List<?>>();

		try {
			connection = datasourceSdm.getConnection();
			query = StoredProcedureConstants.sp_get_SDM_Rollup_Reports;
			callableStatement = connection.prepareCall(query);
			callableStatement.setString(1, reportID);
			resultSet = callableStatement.executeQuery();

			TreeMap<String, String> treeMap = new TreeMap<String, String>(
					Collections.reverseOrder());
			treeMap = (TreeMap<String, String>) ApplicationUtilities
					.selMonthYear();
			String month = treeMap.get((ApplicationUtilities.month_year("")))
					+ " Month-End";
			reportDescriptionList.add(month);
			while (resultSet.next()) {
				List<String> values = new ArrayList<String>();
				values.add(resultSet.getString("metric_name"));
				values.add(resultSet.getString("metric_value"));

				reportList.add(values);
			}
			reportDescriptionList.add(reportID);

			ClientReportCountMap.put(DashboardConstants.SDMETRICSCOLUMNNAME,
					reportDescriptionList);
			ClientReportCountMap.put(DashboardConstants.SDMETRICSCOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics Report Detail from DB Ends");
		return ClientReportCountMap;
	}

	public List<String> deleteMail(String mailId, String subject, String user)
			throws SQLException, NamingException {

		logger.info("delete mail Detail into DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;

		List<String> resultMsg = new ArrayList<String>();
		String insrtReportEmlDtlQry = "";
		insrtReportEmlDtlQry = StoredProcedureConstants.sp_Remove_Email_Address_for_Mail_Subject;
		try {
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(insrtReportEmlDtlQry);
			callableStatement.setString(1, subject);
			callableStatement.setString(2, mailId);
			callableStatement.setString(3, user);
			resultSet = callableStatement.executeQuery();
			while (resultSet.next()) {
				resultMsg.add(resultSet.getString(1));
				resultMsg.add(resultSet.getString(2));
				logger.info("mail detail is inserted into DB or not ? ::--> "
						+ resultSet.getString(2));
			}
		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("Delete mail Detail into DB Ends");
		return resultMsg;
	}

	public Map<String, List<?>> getAAATable(String client) throws SQLException,
			NamingException {

		logger.info("SD Metrics AAA Table Detail from DB Starts");
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		String sdMtericsDetailquery = "";
		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> AAATableMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = datasourceBi.getConnection();
			sdMtericsDetailquery = QueryBuilder.getAAATable(client);
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sdMtericsDetailquery);
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			AAATableMap.put(DashboardConstants.SDMETRICSAAATABLECOLUMNNAME,
					reportDescriptionList);
			AAATableMap.put(DashboardConstants.SDMETRICSAAATABLECOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != statement)
					statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics AAA Table Detail from DB Ends");
		return AAATableMap;
	}

	public Map<String, List<?>> getNotSentReportsAndCount(String monthYear)
			throws SQLException, NamingException {

		logger.info("SD Metrics notSent Reports Table Detail from DB Starts");
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		String sdMetricsNotSentReports = "";

		List<Object> reportList = new ArrayList<Object>();
		List<String> reportDescriptionList = new ArrayList<String>();
		LinkedHashMap<String, List<?>> notSentReportAndCountMap = new LinkedHashMap<String, List<?>>();
		List<String> cellList = null;
		try {
			connection = dataSource.getConnection();
			sdMetricsNotSentReports = StoredProcedureConstants.sp_get_Not_Sent_Reports;
			callableStatement = connection.prepareCall(sdMetricsNotSentReports);
			callableStatement.setString(1, monthYear);
			resultSet = callableStatement.executeQuery();
			ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
			int columnCount = resultSetMetaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String name = resultSetMetaData.getColumnName(i);
				reportDescriptionList.add(name);
			}

			while (resultSet.next()) {
				cellList = new ArrayList<String>();
				for (int i = 0; i < columnCount; i++) {
					String getColumnVal = resultSet
							.getString(reportDescriptionList.get(i));
					if (null == getColumnVal) {
						getColumnVal = "-";
					}
					cellList.add(getColumnVal);
				}
				reportList.add(cellList);
			}
			notSentReportAndCountMap.put(
					DashboardConstants.SDMETRICSNOTSENTREPORTCOLUMNNAME,
					reportDescriptionList);
			notSentReportAndCountMap.put(
					DashboardConstants.SDMETRICSNOTSENTREPORTCOLUMNVALUE,
					reportList);

		} finally {
			try {
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}

			try {
				if (null != callableStatement)
					callableStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}

			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics notSent Reports Detail from DB Ends");
		return notSentReportAndCountMap;
	}

	public List<Object> getReportsCount(String monthYear) throws SQLException,
			NamingException {

		logger.info("SD Metrics notSent Reports Table Detail from DB Starts");
		Connection connection = null;
		String sdMetricsReportCountQuery = "";
		CallableStatement callableStatement1 = null;
		ResultSet resultSet1 = null;

		List<Object> reportCount = new ArrayList<Object>();
		List<String> reportDescriptionCountNames = new ArrayList<String>();
		try {
			connection = dataSource.getConnection();

			sdMetricsReportCountQuery = StoredProcedureConstants.sp_get_Report_Counts;
			callableStatement1 = connection
					.prepareCall(sdMetricsReportCountQuery);
			callableStatement1.setString(1, monthYear);
			resultSet1 = callableStatement1.executeQuery();
			ResultSetMetaData resultSetMetaData1 = resultSet1.getMetaData();
			int columnCount1 = resultSetMetaData1.getColumnCount();
			for (int i = 1; i <= columnCount1; i++) {
				String name = resultSetMetaData1.getColumnName(i);
				reportDescriptionCountNames.add(name);
			}

			while (resultSet1.next()) {
				for (int i = 0; i < columnCount1; i++) {
					String getColumnVal = resultSet1
							.getString(reportDescriptionCountNames.get(i));
					if (null == getColumnVal) {
						getColumnVal = "-";
					}
					reportCount.add(getColumnVal);
				}

			}

		} finally {

			try {
				if (null != resultSet1)
					resultSet1.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}

			try {
				if (null != callableStatement1)
					callableStatement1.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				if (null != connection)
					connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("SD Metrics notSent Reports Detail from DB Ends");
		return reportCount;
	}

}
