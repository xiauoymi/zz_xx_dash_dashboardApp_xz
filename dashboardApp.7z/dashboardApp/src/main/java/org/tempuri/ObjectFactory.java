
package org.tempuri;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.tempuri package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CancelOvertimeOvertimeEndTime_QNAME = new QName("http://tempuri.org/", "overtimeEndTime");
    private final static QName _CancelOvertimeOvertimeStartTime_QNAME = new QName("http://tempuri.org/", "overtimeStartTime");
    private final static QName _CancelOvertimePersonID_QNAME = new QName("http://tempuri.org/", "personID");
    private final static QName _AddActivityActivityEndTime_QNAME = new QName("http://tempuri.org/", "activityEndTime");
    private final static QName _AddActivityActivityID_QNAME = new QName("http://tempuri.org/", "activityID");
    private final static QName _AddActivityActivityStartTime_QNAME = new QName("http://tempuri.org/", "activityStartTime");
    private final static QName _CheckScheduleForPersonEndTime_QNAME = new QName("http://tempuri.org/", "endTime");
    private final static QName _CheckScheduleForPersonStartTime_QNAME = new QName("http://tempuri.org/", "startTime");
    private final static QName _AddAbsenceAbsenceID_QNAME = new QName("http://tempuri.org/", "absenceID");
    private final static QName _AddOvertimeOvertimeDefinition_QNAME = new QName("http://tempuri.org/", "overtimeDefinition");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.tempuri
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CancelOvertime }
     * 
     */
    public CancelOvertime createCancelOvertime() {
        return new CancelOvertime();
    }

    /**
     * Create an instance of {@link LoginResponse }
     * 
     */
    public LoginResponse createLoginResponse() {
        return new LoginResponse();
    }

    /**
     * Create an instance of {@link AddAbsence }
     * 
     */
    public AddAbsence createAddAbsence() {
        return new AddAbsence();
    }

    /**
     * Create an instance of {@link CheckScheduleForPersonResponse }
     * 
     */
    public CheckScheduleForPersonResponse createCheckScheduleForPersonResponse() {
        return new CheckScheduleForPersonResponse();
    }

    /**
     * Create an instance of {@link AddOvertime }
     * 
     */
    public AddOvertime createAddOvertime() {
        return new AddOvertime();
    }

    /**
     * Create an instance of {@link CancelOvertimeResponse }
     * 
     */
    public CancelOvertimeResponse createCancelOvertimeResponse() {
        return new CancelOvertimeResponse();
    }

    /**
     * Create an instance of {@link AddActivity }
     * 
     */
    public AddActivity createAddActivity() {
        return new AddActivity();
    }

    /**
     * Create an instance of {@link AddOvertimeResponse }
     * 
     */
    public AddOvertimeResponse createAddOvertimeResponse() {
        return new AddOvertimeResponse();
    }

    /**
     * Create an instance of {@link Login }
     * 
     */
    public Login createLogin() {
        return new Login();
    }

    /**
     * Create an instance of {@link CheckScheduleForPerson }
     * 
     */
    public CheckScheduleForPerson createCheckScheduleForPerson() {
        return new CheckScheduleForPerson();
    }

    /**
     * Create an instance of {@link AddAbsenceResponse }
     * 
     */
    public AddAbsenceResponse createAddAbsenceResponse() {
        return new AddAbsenceResponse();
    }

    /**
     * Create an instance of {@link AddActivityResponse }
     * 
     */
    public AddActivityResponse createAddActivityResponse() {
        return new AddActivityResponse();
    }

    /**
     * Create an instance of {@link CancelAbsenceResponse }
     * 
     */
    public CancelAbsenceResponse createCancelAbsenceResponse() {
        return new CancelAbsenceResponse();
    }

    /**
     * Create an instance of {@link CancelAbsence }
     * 
     */
    public CancelAbsence createCancelAbsence() {
        return new CancelAbsence();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "overtimeEndTime", scope = CancelOvertime.class)
    public JAXBElement<String> createCancelOvertimeOvertimeEndTime(String value) {
        return new JAXBElement<String>(_CancelOvertimeOvertimeEndTime_QNAME, String.class, CancelOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "overtimeStartTime", scope = CancelOvertime.class)
    public JAXBElement<String> createCancelOvertimeOvertimeStartTime(String value) {
        return new JAXBElement<String>(_CancelOvertimeOvertimeStartTime_QNAME, String.class, CancelOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = CancelOvertime.class)
    public JAXBElement<String> createCancelOvertimePersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, CancelOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityEndTime", scope = AddActivity.class)
    public JAXBElement<String> createAddActivityActivityEndTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityEndTime_QNAME, String.class, AddActivity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityID", scope = AddActivity.class)
    public JAXBElement<String> createAddActivityActivityID(String value) {
        return new JAXBElement<String>(_AddActivityActivityID_QNAME, String.class, AddActivity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = AddActivity.class)
    public JAXBElement<String> createAddActivityPersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, AddActivity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityStartTime", scope = AddActivity.class)
    public JAXBElement<String> createAddActivityActivityStartTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityStartTime_QNAME, String.class, AddActivity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityEndTime", scope = CancelAbsence.class)
    public JAXBElement<String> createCancelAbsenceActivityEndTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityEndTime_QNAME, String.class, CancelAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = CancelAbsence.class)
    public JAXBElement<String> createCancelAbsencePersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, CancelAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityStartTime", scope = CancelAbsence.class)
    public JAXBElement<String> createCancelAbsenceActivityStartTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityStartTime_QNAME, String.class, CancelAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "endTime", scope = CheckScheduleForPerson.class)
    public JAXBElement<String> createCheckScheduleForPersonEndTime(String value) {
        return new JAXBElement<String>(_CheckScheduleForPersonEndTime_QNAME, String.class, CheckScheduleForPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = CheckScheduleForPerson.class)
    public JAXBElement<String> createCheckScheduleForPersonPersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, CheckScheduleForPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "startTime", scope = CheckScheduleForPerson.class)
    public JAXBElement<String> createCheckScheduleForPersonStartTime(String value) {
        return new JAXBElement<String>(_CheckScheduleForPersonStartTime_QNAME, String.class, CheckScheduleForPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityEndTime", scope = AddAbsence.class)
    public JAXBElement<String> createAddAbsenceActivityEndTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityEndTime_QNAME, String.class, AddAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "absenceID", scope = AddAbsence.class)
    public JAXBElement<String> createAddAbsenceAbsenceID(String value) {
        return new JAXBElement<String>(_AddAbsenceAbsenceID_QNAME, String.class, AddAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = AddAbsence.class)
    public JAXBElement<String> createAddAbsencePersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, AddAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityStartTime", scope = AddAbsence.class)
    public JAXBElement<String> createAddAbsenceActivityStartTime(String value) {
        return new JAXBElement<String>(_AddActivityActivityStartTime_QNAME, String.class, AddAbsence.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "activityID", scope = AddOvertime.class)
    public JAXBElement<String> createAddOvertimeActivityID(String value) {
        return new JAXBElement<String>(_AddActivityActivityID_QNAME, String.class, AddOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "overtimeDefinition", scope = AddOvertime.class)
    public JAXBElement<String> createAddOvertimeOvertimeDefinition(String value) {
        return new JAXBElement<String>(_AddOvertimeOvertimeDefinition_QNAME, String.class, AddOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "overtimeEndTime", scope = AddOvertime.class)
    public JAXBElement<String> createAddOvertimeOvertimeEndTime(String value) {
        return new JAXBElement<String>(_CancelOvertimeOvertimeEndTime_QNAME, String.class, AddOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "overtimeStartTime", scope = AddOvertime.class)
    public JAXBElement<String> createAddOvertimeOvertimeStartTime(String value) {
        return new JAXBElement<String>(_CancelOvertimeOvertimeStartTime_QNAME, String.class, AddOvertime.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "personID", scope = AddOvertime.class)
    public JAXBElement<String> createAddOvertimePersonID(String value) {
        return new JAXBElement<String>(_CancelOvertimePersonID_QNAME, String.class, AddOvertime.class, value);
    }

}
